# 🔥 PYTORCH LSTM TEMPERATURE PREDICTION

Complete PyTorch implementation with manual and automated experimentation.

---

## 📦 Files

1. **`pytorch_lstm_manual.py`** - Manual experiments (run one at a time)
2. **`pytorch_lstm_automated.py`** - Automated experiments (run all at once)

---

## ✨ Features

✅ **PyTorch Implementation** - Clean, simple PyTorch code  
✅ **Model saved as `.pth`** - Standard PyTorch format  
✅ **Scalers saved as `.pkl`** - Easy to load  
✅ **Line Plots** - All outputs in single column  
✅ **No Station Reference** - Commented out for future use  
✅ **Simple & Clean** - Easy to modify  

---

## 🚀 Quick Start

### **Your Data Scenario:**

```
Train: s1 + s2 + s3 (3 sorties)
  - 12 input columns
  - 3 or 4 output columns

Test: 1 sortie
```

### **Step 1: Load Data**

```python
import pandas as pd

# Load sorties
s1 = pd.read_csv('sortie1.csv')
s2 = pd.read_csv('sortie2.csv')
s3 = pd.read_csv('sortie3.csv')
test = pd.read_csv('test_sortie.csv')

# Combine training data
train_data = pd.concat([s1, s2, s3], ignore_index=True)
test_data = test

# Track sortie lengths (important for sequence boundaries!)
train_sortie_lengths = [len(s1), len(s2), len(s3)]
test_sortie_lengths = [len(test)]
```

### **Step 2: Update Column Names**

In `pytorch_lstm_manual.py`, modify the `Config` class:

```python
class Config:
    INPUT_COLUMNS = [
        'altitude', 'speed', 'engine_power', 'grms',
        'feature5', 'feature6', 'feature7', 'feature8',
        'feature9', 'feature10', 'feature11', 'feature12'
    ]  # Your 12 inputs
    
    OUTPUT_COLUMNS = ['temp1', 'temp2', 'temp3']  # Your 3-4 outputs
```

### **Step 3A: Manual Experiments (One at a Time)**

```python
from pytorch_lstm_manual import Config, train_model

# Experiment 1: Small window
config = Config()
config.WINDOW_SIZE = 20
config.HIDDEN_SIZE = 16
config.NUM_LAYERS = 1
config.DROPOUT = 0.0
config.LEARNING_RATE = 0.0001
config.BATCH_SIZE = 64

model, scaler_X, scaler_y, metrics, history = train_model(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    config
)

# Check result
print(f"Test R²: {metrics['test']['r2_avg']:.4f}")

# If good, try another experiment
# Modify config and run again
```

### **Step 3B: Automated Experiments (All at Once)**

```python
from pytorch_lstm_automated import run_complete_pipeline

# Run complete pipeline (~21 experiments)
results = run_complete_pipeline(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths
)

# Best model will be automatically identified and saved
```

---

## 📁 Output Files

After training, check `./outputs/` folder:

```
outputs/
├── Exp_w50_h32_L1_lr0.0001_model.pth       # PyTorch model
├── Exp_w50_h32_L1_lr0.0001_scaler_X.pkl    # Input scaler
├── Exp_w50_h32_L1_lr0.0001_scaler_y.pkl    # Output scaler
├── Exp_w50_h32_L1_lr0.0001_metrics.json    # All metrics
├── Exp_w50_h32_L1_lr0.0001_results.png     # Plots
└── Phase1_QuickTests_summary.json          # (if using automated)
```

---

## 🔧 Manual Experiments - What to Try

### **Experiment 1: Find Working Baseline**

```python
# Try small window first
config = Config()
config.WINDOW_SIZE = 20      # Small!
config.HIDDEN_SIZE = 16      # Simple!
config.NUM_LAYERS = 1
config.DROPOUT = 0.0
config.LEARNING_RATE = 0.0001
config.BATCH_SIZE = 64
config.EXPERIMENT_NAME = 'Baseline_w20'
```

**Goal:** Get Test R² > 0.3

---

### **Experiment 2: Try Different Windows**

```python
# If baseline works, try larger windows
for window in [20, 50, 100]:
    config = Config()
    config.WINDOW_SIZE = window
    config.HIDDEN_SIZE = 32
    config.EXPERIMENT_NAME = f'Window_{window}'
    # ... run training
```

**Goal:** Find best window size

---

### **Experiment 3: Increase Complexity**

```python
# Once you have positive R², try more complex model
config = Config()
config.WINDOW_SIZE = 50  # Use best from above
config.HIDDEN_SIZE = 64
config.NUM_LAYERS = 2
config.DROPOUT = 0.3
config.EXPERIMENT_NAME = 'Complex_Model'
```

**Goal:** Improve Test R²

---

### **Experiment 4: Add Regularization (if overfitting)**

```python
# If Train R² >> Test R²
config = Config()
config.WINDOW_SIZE = 50
config.HIDDEN_SIZE = 32
config.DROPOUT = 0.5  # Higher dropout!
config.EXPERIMENT_NAME = 'HighDropout'
```

**Goal:** Reduce gap to < 0.15

---

## 🤖 Automated Experiments

### **Complete Pipeline**

Runs all experiments automatically:

```python
from pytorch_lstm_automated import run_complete_pipeline

results = run_complete_pipeline(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths
)
```

**What it does:**
1. **Phase 1:** Quick tests (3 experiments)
2. **Phase 2:** Window size search (5 experiments)
3. **Phase 3:** Architecture search (5 experiments)
4. **Phase 4:** Learning rate tuning (4 experiments)
5. **Phase 5:** Dropout tuning (4 experiments) - if needed

**Total:** ~21 experiments

**Time:** 2-4 hours depending on data size

---

### **Individual Experiment Sets**

Run specific phases only:

```python
from pytorch_lstm_automated import (
    get_quick_test_experiments,
    get_window_size_experiments,
    get_architecture_experiments,
    run_experiments
)

# Quick tests only
experiments = get_quick_test_experiments()
results, best = run_experiments(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    experiments, "QuickTests"
)

# Window size search only
experiments = get_window_size_experiments()
results, best = run_experiments(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    experiments, "WindowSearch"
)

# Architecture search (after finding best window)
experiments = get_architecture_experiments(best_window_size=50)
results, best = run_experiments(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    experiments, "ArchSearch"
)
```

---

## 💾 Loading Saved Models

```python
import torch
import pickle

# Load model
checkpoint = torch.load('outputs/Exp_w50_h32_L1_lr0.0001_model.pth')
model_config = checkpoint['config']

# Reconstruct model
from pytorch_lstm_manual import LSTMModel
model = LSTMModel(
    input_size=model_config['input_size'],
    hidden_size=model_config['hidden_size'],
    num_layers=model_config['num_layers'],
    output_size=model_config['output_size'],
    dropout=model_config['dropout'],
    bidirectional=model_config['bidirectional']
)
model.load_state_dict(checkpoint['model_state_dict'])
model.eval()

# Load scalers
with open('outputs/Exp_w50_h32_L1_lr0.0001_scaler_X.pkl', 'rb') as f:
    scaler_X = pickle.load(f)

with open('outputs/Exp_w50_h32_L1_lr0.0001_scaler_y.pkl', 'rb') as f:
    scaler_y = pickle.load(f)

# Use for prediction
X_new_scaled = scaler_X.transform(X_new)
# Create sequences...
with torch.no_grad():
    y_pred_scaled = model(torch.FloatTensor(X_new_seq)).numpy()
y_pred = scaler_y.inverse_transform(y_pred_scaled)
```

---

## 📊 Understanding Results

### **Good Results:**
```
Train R²: 0.80-0.90
Test R²:  0.70-0.85
Gap:      < 0.15
```
✅ Model working well!

### **Overfitting:**
```
Train R²: 0.95-0.99
Test R²:  0.30-0.60
Gap:      > 0.20
```
⚠️ Add dropout, reduce complexity

### **Underfitting:**
```
Train R²: 0.50-0.70
Test R²:  0.40-0.60
Gap:      < 0.15
```
⚠️ Increase capacity, larger window

### **Broken:**
```
Test R²: < 0 (negative)
```
❌ Check data, try window=10-20, simplify model

---

## 🎯 Recommended Strategy for Your Case

### **Start with Manual Experiments:**

1. **Baseline Test:**
   ```python
   config.WINDOW_SIZE = 20
   config.HIDDEN_SIZE = 16
   config.NUM_LAYERS = 1
   config.DROPOUT = 0.0
   ```
   **Goal:** Get Test R² > 0.3

2. **If Baseline Works, Scale Up:**
   ```python
   config.WINDOW_SIZE = 50
   config.HIDDEN_SIZE = 32
   ```
   **Goal:** Improve to R² > 0.6

3. **If Good, Add Complexity:**
   ```python
   config.NUM_LAYERS = 2
   config.DROPOUT = 0.3
   ```
   **Goal:** Maximize Test R²

### **Then Run Automated:**

Once you know what generally works, run automated pipeline to fine-tune.

---

## 🔑 Key Parameters

| Parameter | What It Does | Start With | When to Change |
|-----------|--------------|------------|----------------|
| `WINDOW_SIZE` | Past timesteps | 20-50 | **Most important!** |
| `HIDDEN_SIZE` | Model capacity | 32 | Increase if underfitting |
| `NUM_LAYERS` | Model depth | 1 | Add if model plateaus |
| `DROPOUT` | Regularization | 0.3 | Increase if overfitting |
| `LEARNING_RATE` | Training speed | 0.0001 | Decrease if unstable |
| `BATCH_SIZE` | Samples per update | 64 | Decrease if unstable |
| `BIDIRECTIONAL` | Look both ways | False | Try if not enough |

---

## ⚠️ Important Notes

### **Station Column:**

Station reference is **commented out** in the code:

```python
# STATION_COLUMN = 'station'
```

**To use station info:**
1. Uncomment the line
2. Add station column to your data
3. The code will automatically one-hot encode it

### **GPU Usage:**

Code automatically uses GPU if available:
```python
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
```

To force CPU:
```python
device = torch.device('cpu')
```

---

## 🆘 Common Issues

### **Issue: Negative Test R²**

**Try:**
1. Reduce `WINDOW_SIZE` to 10 or 20
2. Use simplest model (HIDDEN_SIZE=16, NUM_LAYERS=1)
3. Check data loading and scaling

### **Issue: Overfitting**

**Try:**
1. Increase `DROPOUT` (0.3 → 0.5)
2. Reduce `WINDOW_SIZE`
3. Reduce `HIDDEN_SIZE` or `NUM_LAYERS`

### **Issue: Out of Memory**

**Try:**
1. Reduce `BATCH_SIZE` (64 → 32)
2. Reduce `WINDOW_SIZE`
3. Reduce `HIDDEN_SIZE`
4. Use `device = torch.device('cpu')`

---

## ✅ Complete Workflow Example

```python
import pandas as pd
from pytorch_lstm_manual import Config, train_model

# 1. Load data
s1 = pd.read_csv('sortie1.csv')
s2 = pd.read_csv('sortie2.csv')
s3 = pd.read_csv('sortie3.csv')
test = pd.read_csv('test.csv')

train_data = pd.concat([s1, s2, s3], ignore_index=True)
test_data = test

train_sortie_lengths = [len(s1), len(s2), len(s3)]
test_sortie_lengths = [len(test)]

# 2. Update Config in pytorch_lstm_manual.py with your column names

# 3. Run baseline experiment
config = Config()
config.WINDOW_SIZE = 20
config.HIDDEN_SIZE = 16
config.NUM_LAYERS = 1
config.DROPOUT = 0.0
config.EXPERIMENT_NAME = 'Baseline'

model, scaler_X, scaler_y, metrics, history = train_model(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    config
)

# 4. Check results
print(f"Test R²: {metrics['test']['r2_avg']:.4f}")

# 5. If good (R² > 0.3), try automated pipeline
if metrics['test']['r2_avg'] > 0.3:
    from pytorch_lstm_automated import run_complete_pipeline
    results = run_complete_pipeline(
        train_data, test_data,
        train_sortie_lengths, test_sortie_lengths
    )
```

---

**Good luck with your experiments! 🚀**
