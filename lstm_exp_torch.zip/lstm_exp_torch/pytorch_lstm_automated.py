"""
PYTORCH LSTM TRAINER - AUTOMATED EXPERIMENTS
=============================================

Run multiple experiments automatically to find best hyperparameters.
All experiments run sequentially in one execution.

Author: Aircraft Temperature Prediction
"""

import numpy as np
import pandas as pd
import json
from datetime import datetime
from pytorch_lstm_manual import (
    Config, train_model, create_output_folder
)


# ============================================================================
# EXPERIMENT CONFIGURATIONS
# ============================================================================

def get_window_size_experiments():
    """
    Experiment 1: Try different window sizes
    MOST IMPORTANT parameter to tune!
    """
    experiments = []
    
    window_sizes = [10, 20, 50, 100, 200]
    
    for ws in window_sizes:
        config = Config()
        config.WINDOW_SIZE = ws
        config.HIDDEN_SIZE = 32
        config.NUM_LAYERS = 1
        config.DROPOUT = 0.3
        config.BIDIRECTIONAL = False
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = f'WindowSize_{ws}'
        experiments.append(config)
    
    return experiments


def get_architecture_experiments(best_window_size=50):
    """
    Experiment 2: Try different architectures
    Run after finding best window size
    """
    experiments = []
    
    architectures = [
        {'name': 'Simple_H16', 'hidden': 16, 'layers': 1, 'dropout': 0.0, 'bi': False},
        {'name': 'LSTM_H32', 'hidden': 32, 'layers': 1, 'dropout': 0.3, 'bi': False},
        {'name': 'LSTM_H64', 'hidden': 64, 'layers': 1, 'dropout': 0.3, 'bi': False},
        {'name': 'LSTM2Layer', 'hidden': 32, 'layers': 2, 'dropout': 0.3, 'bi': False},
        {'name': 'BiLSTM', 'hidden': 32, 'layers': 1, 'dropout': 0.3, 'bi': True},
    ]
    
    for arch in architectures:
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.HIDDEN_SIZE = arch['hidden']
        config.NUM_LAYERS = arch['layers']
        config.DROPOUT = arch['dropout']
        config.BIDIRECTIONAL = arch['bi']
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = arch['name']
        experiments.append(config)
    
    return experiments


def get_learning_rate_experiments(best_window_size=50, best_hidden_size=32):
    """
    Experiment 3: Try different learning rates
    """
    experiments = []
    
    learning_rates = [0.00005, 0.0001, 0.0005, 0.001]
    
    for lr in learning_rates:
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.HIDDEN_SIZE = best_hidden_size
        config.NUM_LAYERS = 1
        config.DROPOUT = 0.3
        config.BIDIRECTIONAL = False
        config.LEARNING_RATE = lr
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = f'LR_{lr}'
        experiments.append(config)
    
    return experiments


def get_dropout_experiments(best_window_size=50, best_hidden_size=32):
    """
    Experiment 4: Try different dropout rates
    Use if model is overfitting
    """
    experiments = []
    
    dropout_rates = [0.0, 0.2, 0.3, 0.5]
    
    for dropout in dropout_rates:
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.HIDDEN_SIZE = best_hidden_size
        config.NUM_LAYERS = 1
        config.DROPOUT = dropout
        config.BIDIRECTIONAL = False
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = f'Dropout_{dropout}'
        experiments.append(config)
    
    return experiments


def get_batch_size_experiments(best_window_size=50, best_hidden_size=32):
    """
    Experiment 5: Try different batch sizes
    """
    experiments = []
    
    batch_sizes = [32, 64, 128, 256]
    
    for bs in batch_sizes:
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.HIDDEN_SIZE = best_hidden_size
        config.NUM_LAYERS = 1
        config.DROPOUT = 0.3
        config.BIDIRECTIONAL = False
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = bs
        config.EXPERIMENT_NAME = f'BatchSize_{bs}'
        experiments.append(config)
    
    return experiments


def get_quick_test_experiments():
    """
    Quick tests with most likely good configurations
    Run this first to quickly find what works
    """
    experiments = []
    
    # Test 1: Small window, simple model
    config1 = Config()
    config1.WINDOW_SIZE = 20
    config1.HIDDEN_SIZE = 16
    config1.NUM_LAYERS = 1
    config1.DROPOUT = 0.0
    config1.BIDIRECTIONAL = False
    config1.LEARNING_RATE = 0.0001
    config1.BATCH_SIZE = 64
    config1.EXPERIMENT_NAME = 'QuickTest_Small'
    experiments.append(config1)
    
    # Test 2: Medium window, moderate model
    config2 = Config()
    config2.WINDOW_SIZE = 50
    config2.HIDDEN_SIZE = 32
    config2.NUM_LAYERS = 1
    config2.DROPOUT = 0.3
    config2.BIDIRECTIONAL = False
    config2.LEARNING_RATE = 0.0001
    config2.BATCH_SIZE = 64
    config2.EXPERIMENT_NAME = 'QuickTest_Medium'
    experiments.append(config2)
    
    # Test 3: Larger window
    config3 = Config()
    config3.WINDOW_SIZE = 100
    config3.HIDDEN_SIZE = 32
    config3.NUM_LAYERS = 1
    config3.DROPOUT = 0.3
    config3.BIDIRECTIONAL = False
    config3.LEARNING_RATE = 0.0001
    config3.BATCH_SIZE = 64
    config3.EXPERIMENT_NAME = 'QuickTest_Large'
    experiments.append(config3)
    
    return experiments


# ============================================================================
# EXPERIMENT RUNNER
# ============================================================================

def run_experiments(train_data, test_data, train_sortie_lengths, test_sortie_lengths,
                   experiments, experiment_set_name):
    """
    Run a set of experiments
    
    Parameters:
    -----------
    train_data : DataFrame
    test_data : DataFrame
    train_sortie_lengths : list of int
    test_sortie_lengths : list of int
    experiments : list of Config objects
    experiment_set_name : str
    """
    
    print("\n" + "╔" + "="*78 + "╗")
    print(f"║  {experiment_set_name:^74}  ║")
    print("╚" + "="*78 + "╝")
    
    results = []
    
    for i, config in enumerate(experiments, 1):
        print(f"\n{'='*80}")
        print(f"EXPERIMENT {i}/{len(experiments)}: {config.EXPERIMENT_NAME}")
        print(f"{'='*80}")
        
        try:
            # Train model
            model, scaler_X, scaler_y, metrics, history = train_model(
                train_data, test_data,
                train_sortie_lengths, test_sortie_lengths,
                config
            )
            
            # Save results
            result = {
                'experiment': config.EXPERIMENT_NAME,
                'window_size': config.WINDOW_SIZE,
                'hidden_size': config.HIDDEN_SIZE,
                'num_layers': config.NUM_LAYERS,
                'dropout': config.DROPOUT,
                'bidirectional': config.BIDIRECTIONAL,
                'learning_rate': config.LEARNING_RATE,
                'batch_size': config.BATCH_SIZE,
                'train_r2': metrics['train']['r2_avg'],
                'test_r2': metrics['test']['r2_avg'],
                'gap': metrics['gap'],
                'success': True
            }
            results.append(result)
            
        except Exception as e:
            print(f"\n❌ Error in {config.EXPERIMENT_NAME}: {str(e)}")
            result = {
                'experiment': config.EXPERIMENT_NAME,
                'window_size': config.WINDOW_SIZE,
                'hidden_size': config.HIDDEN_SIZE,
                'num_layers': config.NUM_LAYERS,
                'dropout': config.DROPOUT,
                'bidirectional': config.BIDIRECTIONAL,
                'learning_rate': config.LEARNING_RATE,
                'batch_size': config.BATCH_SIZE,
                'train_r2': None,
                'test_r2': None,
                'gap': None,
                'success': False,
                'error': str(e)
            }
            results.append(result)
    
    # Summary
    print("\n" + "="*80)
    print(f"SUMMARY: {experiment_set_name}")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    
    # Filter successful experiments
    successful = results_df[results_df['success'] == True]
    
    if len(successful) > 0:
        # Sort by test R²
        successful_sorted = successful.sort_values('test_r2', ascending=False)
        
        print("\n📊 Top 5 Results (by Test R²):")
        print(successful_sorted[['experiment', 'test_r2', 'train_r2', 'gap']].head().to_string(index=False))
        
        # Best model
        best = successful_sorted.iloc[0]
        print(f"\n🏆 BEST MODEL:")
        print(f"   Experiment: {best['experiment']}")
        print(f"   Test R²: {best['test_r2']:.4f}")
        print(f"   Train R²: {best['train_r2']:.4f}")
        print(f"   Gap: {best['gap']:.4f}")
        print(f"   Window Size: {int(best['window_size'])}")
        print(f"   Hidden Size: {int(best['hidden_size'])}")
        print(f"   Num Layers: {int(best['num_layers'])}")
        
        # Save summary
        summary_path = f"{Config.OUTPUT_FOLDER}/{experiment_set_name}_summary.json"
        summary = {
            'experiment_set': experiment_set_name,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_experiments': len(experiments),
            'successful': len(successful),
            'failed': len(results_df) - len(successful),
            'best_experiment': {
                'name': best['experiment'],
                'test_r2': float(best['test_r2']),
                'train_r2': float(best['train_r2']),
                'gap': float(best['gap']),
                'window_size': int(best['window_size']),
                'hidden_size': int(best['hidden_size']),
                'num_layers': int(best['num_layers']),
                'dropout': float(best['dropout']),
                'learning_rate': float(best['learning_rate']),
                'batch_size': int(best['batch_size'])
            },
            'all_results': results
        }
        
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=4)
        print(f"\n✓ Summary saved: {summary_path}")
        
        return results_df, best
    
    else:
        print("\n❌ All experiments failed!")
        return results_df, None


# ============================================================================
# COMPLETE PIPELINE
# ============================================================================

def run_complete_pipeline(train_data, test_data, train_sortie_lengths, test_sortie_lengths):
    """
    Run complete experimentation pipeline
    
    This runs all experiments in recommended order:
    1. Quick tests (3 experiments)
    2. Window size search (5 experiments)
    3. Architecture search (5 experiments)
    4. Learning rate tuning (4 experiments)
    5. Dropout tuning (4 experiments)
    
    Total: ~21 experiments
    """
    
    print("\n" + "╔" + "="*78 + "╗")
    print("║" + " "*78 + "║")
    print("║" + "  COMPLETE AUTOMATED EXPERIMENTATION PIPELINE".center(78) + "║")
    print("║" + " "*78 + "║")
    print("╚" + "="*78 + "╝")
    
    create_output_folder(Config.OUTPUT_FOLDER)
    
    all_results = {}
    
    # ========================================================================
    # PHASE 1: QUICK TESTS
    # ========================================================================
    
    print("\n\n" + "█"*80)
    print("PHASE 1: QUICK TESTS")
    print("█"*80)
    print("Running 3 quick tests to find what works...")
    
    quick_experiments = get_quick_test_experiments()
    quick_results, quick_best = run_experiments(
        train_data, test_data, train_sortie_lengths, test_sortie_lengths,
        quick_experiments, "Phase1_QuickTests"
    )
    all_results['quick_tests'] = quick_results
    
    if quick_best is None or quick_best['test_r2'] < 0:
        print("\n❌ CRITICAL: Quick tests failed!")
        print("   Something is fundamentally wrong with data/preprocessing")
        print("   Check data loading, scaling, and sequence creation")
        return all_results
    
    # ========================================================================
    # PHASE 2: WINDOW SIZE SEARCH
    # ========================================================================
    
    print("\n\n" + "█"*80)
    print("PHASE 2: WINDOW SIZE SEARCH")
    print("█"*80)
    print("Finding optimal window size...")
    
    window_experiments = get_window_size_experiments()
    window_results, window_best = run_experiments(
        train_data, test_data, train_sortie_lengths, test_sortie_lengths,
        window_experiments, "Phase2_WindowSize"
    )
    all_results['window_size'] = window_results
    
    if window_best is not None:
        best_window = int(window_best['window_size'])
        print(f"\n✓ Best window size: {best_window}")
    else:
        best_window = 50  # Default
        print(f"\n⚠️  Using default window size: {best_window}")
    
    # ========================================================================
    # PHASE 3: ARCHITECTURE SEARCH
    # ========================================================================
    
    print("\n\n" + "█"*80)
    print("PHASE 3: ARCHITECTURE SEARCH")
    print("█"*80)
    print(f"Testing different architectures with window_size={best_window}...")
    
    arch_experiments = get_architecture_experiments(best_window)
    arch_results, arch_best = run_experiments(
        train_data, test_data, train_sortie_lengths, test_sortie_lengths,
        arch_experiments, "Phase3_Architecture"
    )
    all_results['architecture'] = arch_results
    
    if arch_best is not None:
        best_hidden = int(arch_best['hidden_size'])
        print(f"\n✓ Best hidden size: {best_hidden}")
    else:
        best_hidden = 32  # Default
        print(f"\n⚠️  Using default hidden size: {best_hidden}")
    
    # ========================================================================
    # PHASE 4: LEARNING RATE TUNING
    # ========================================================================
    
    print("\n\n" + "█"*80)
    print("PHASE 4: LEARNING RATE TUNING")
    print("█"*80)
    print(f"Fine-tuning learning rate...")
    
    lr_experiments = get_learning_rate_experiments(best_window, best_hidden)
    lr_results, lr_best = run_experiments(
        train_data, test_data, train_sortie_lengths, test_sortie_lengths,
        lr_experiments, "Phase4_LearningRate"
    )
    all_results['learning_rate'] = lr_results
    
    # ========================================================================
    # PHASE 5: DROPOUT TUNING (if overfitting)
    # ========================================================================
    
    # Check if best model so far is overfitting
    current_best = lr_best if lr_best is not None else arch_best
    
    if current_best is not None and current_best['gap'] > 0.15:
        print("\n\n" + "█"*80)
        print("PHASE 5: DROPOUT TUNING (Overfitting detected)")
        print("█"*80)
        print(f"Testing different dropout rates to reduce overfitting...")
        
        dropout_experiments = get_dropout_experiments(best_window, best_hidden)
        dropout_results, dropout_best = run_experiments(
            train_data, test_data, train_sortie_lengths, test_sortie_lengths,
            dropout_experiments, "Phase5_Dropout"
        )
        all_results['dropout'] = dropout_results
    
    # ========================================================================
    # FINAL SUMMARY
    # ========================================================================
    
    print("\n\n" + "╔" + "="*78 + "╗")
    print("║" + "  FINAL SUMMARY".center(78) + "║")
    print("╚" + "="*78 + "╝")
    
    # Find overall best model
    all_experiments = []
    for phase_results in all_results.values():
        if isinstance(phase_results, pd.DataFrame):
            all_experiments.extend(phase_results.to_dict('records'))
    
    all_df = pd.DataFrame(all_experiments)
    successful = all_df[all_df['success'] == True]
    
    if len(successful) > 0:
        overall_best = successful.sort_values('test_r2', ascending=False).iloc[0]
        
        print(f"\n🏆 OVERALL BEST MODEL:")
        print(f"   Experiment: {overall_best['experiment']}")
        print(f"   Test R²: {overall_best['test_r2']:.4f}")
        print(f"   Train R²: {overall_best['train_r2']:.4f}")
        print(f"   Gap: {overall_best['gap']:.4f}")
        print(f"\n   Configuration:")
        print(f"     Window Size: {int(overall_best['window_size'])}")
        print(f"     Hidden Size: {int(overall_best['hidden_size'])}")
        print(f"     Num Layers: {int(overall_best['num_layers'])}")
        print(f"     Dropout: {overall_best['dropout']:.2f}")
        print(f"     Learning Rate: {overall_best['learning_rate']}")
        print(f"     Batch Size: {int(overall_best['batch_size'])}")
        print(f"     Bidirectional: {overall_best['bidirectional']}")
        
        # Save final summary
        final_summary = {
            'pipeline_run': 'complete',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_experiments': len(all_df),
            'successful_experiments': len(successful),
            'overall_best': {
                'experiment': overall_best['experiment'],
                'test_r2': float(overall_best['test_r2']),
                'train_r2': float(overall_best['train_r2']),
                'gap': float(overall_best['gap']),
                'config': {
                    'window_size': int(overall_best['window_size']),
                    'hidden_size': int(overall_best['hidden_size']),
                    'num_layers': int(overall_best['num_layers']),
                    'dropout': float(overall_best['dropout']),
                    'learning_rate': float(overall_best['learning_rate']),
                    'batch_size': int(overall_best['batch_size']),
                    'bidirectional': bool(overall_best['bidirectional'])
                }
            }
        }
        
        final_path = f"{Config.OUTPUT_FOLDER}/FINAL_SUMMARY.json"
        with open(final_path, 'w') as f:
            json.dump(final_summary, f, indent=4)
        print(f"\n✓ Final summary saved: {final_path}")
    
    print("\n" + "="*80)
    print("✅ COMPLETE PIPELINE FINISHED!")
    print("="*80)
    print(f"\nCheck {Config.OUTPUT_FOLDER}/ for all results, models, and plots")
    
    return all_results


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    
    print("""
    ╔════════════════════════════════════════════════════════════════════════╗
    ║            PYTORCH LSTM TRAINER - AUTOMATED EXPERIMENTS                ║
    ╚════════════════════════════════════════════════════════════════════════╝
    
    HOW TO USE:
    
    1. Load your data:
       s1 = pd.read_csv('sortie1.csv')
       s2 = pd.read_csv('sortie2.csv')
       s3 = pd.read_csv('sortie3.csv')
       test = pd.read_csv('test_sortie.csv')
       
       train_data = pd.concat([s1, s2, s3], ignore_index=True)
       test_data = test
       
       train_sortie_lengths = [len(s1), len(s2), len(s3)]
       test_sortie_lengths = [len(test)]
    
    2. Modify Config class in pytorch_lstm_manual.py to match your columns
    
    3. Choose experimentation mode:
    
       A) COMPLETE PIPELINE (recommended - runs ~21 experiments):
          results = run_complete_pipeline(
              train_data, test_data,
              train_sortie_lengths, test_sortie_lengths
          )
       
       B) SPECIFIC EXPERIMENT SET:
          # Quick tests only
          experiments = get_quick_test_experiments()
          results, best = run_experiments(
              train_data, test_data,
              train_sortie_lengths, test_sortie_lengths,
              experiments, "QuickTests"
          )
          
          # Or window size search
          experiments = get_window_size_experiments()
          results, best = run_experiments(...)
          
          # Or architecture search
          experiments = get_architecture_experiments(best_window_size=50)
          results, best = run_experiments(...)
    
    4. Check ./outputs/ folder for all results
    
    The pipeline will automatically:
    - Try different configurations
    - Save all models and results
    - Generate plots for each experiment
    - Create summary reports
    - Find the best model
    """)
