# 📊 COMPLETE DATA ANALYSIS PIPELINE

**Comprehensive end-to-end data analysis for LSTM temperature prediction modeling**

---

## 🎯 Purpose

This pipeline analyzes your time series data from **every angle** and generates detailed reports to help you:

1. **Understand your data** - distributions, patterns, relationships
2. **Choose optimal model architecture** - window size, hidden units, layers
3. **Set hyperparameters** - learning rate, batch size, dropout
4. **Identify potential issues** - outliers, missing values, distribution shifts
5. **Make informed decisions** - backed by statistical analysis

**Everything is recorded and saved** for future reference.

---

## 📦 What You Get

After running the pipeline, you'll have a complete analysis in `./data_analysis/` folder:

```
data_analysis/
├── EXECUTIVE_SUMMARY.txt              # Quick overview & recommendations
├── reports/
│   ├── 01_data_exploration.txt        # Dataset basics
│   ├── 02_distribution_analysis.txt   # Statistical distributions
│   ├── 03_timeseries_analysis.txt     # Temporal patterns
│   ├── 04_feature_relationships.txt   # Correlations & importance
│   ├── 05_window_size_analysis.txt    # Optimal window sizes
│   ├── 06_data_quality.txt            # Outliers & quality checks
│   ├── 07_model_recommendations.txt   # Architecture recommendations
│   └── recommendations.json           # Machine-readable config
└── plots/
    ├── 02_input_distributions.png     # Feature distributions
    ├── 02_output_distributions.png    # Output distributions
    ├── 03_autocorrelation.png         # Temporal dependencies
    ├── 03_timeseries_trend.png        # Time series patterns
    ├── 04_correlation_heatmap.png     # Feature-output correlations
    ├── 04_feature_importance.png      # Most important features
    ├── 05_window_size_analysis.png    # Window size comparisons
    └── 06_outliers.png                # Outlier detection
```

---

## 🚀 Quick Start

### **Step 1: Prepare Your Data**

```python
import pandas as pd

# Load your 3 training sorties
s1 = pd.read_csv('sortie1.csv')
s2 = pd.read_csv('sortie2.csv')
s3 = pd.read_csv('sortie3.csv')

# Load test sortie
test = pd.read_csv('test_sortie.csv')

# Combine training data
train_data = pd.concat([s1, s2, s3], ignore_index=True)
test_data = test

# Track sortie lengths (IMPORTANT!)
train_sortie_lengths = [len(s1), len(s2), len(s3)]
```

### **Step 2: Update Configuration**

In `data_analysis_pipeline.py`, modify the `AnalysisConfig` class:

```python
class AnalysisConfig:
    OUTPUT_FOLDER = './data_analysis'
    
    # MODIFY THESE to match your columns
    INPUT_COLUMNS = [
        'altitude', 'speed', 'engine_power', 'grms',
        'feature5', 'feature6', 'feature7', 'feature8',
        'feature9', 'feature10', 'feature11', 'feature12'
    ]
    
    OUTPUT_COLUMNS = ['temp1', 'temp2', 'temp3']  # Your 3-4 outputs
    
    MAX_LAG = 100  # For autocorrelation analysis
    WINDOW_SIZES_TO_TEST = [10, 20, 50, 100, 200]
```

### **Step 3: Run Analysis**

```python
from data_analysis_pipeline import AnalysisConfig, run_complete_analysis

config = AnalysisConfig()
results, recommendations = run_complete_analysis(
    train_data,
    test_data,
    train_sortie_lengths,
    config
)

# Results are automatically saved to ./data_analysis/
print("✓ Analysis complete! Check ./data_analysis/ folder")
```

### **Step 4: Review Reports**

1. **Start with:** `EXECUTIVE_SUMMARY.txt` - Overview and quick recommendations
2. **Read:** Individual phase reports in `reports/` folder
3. **View:** Plots in `plots/` folder
4. **Use:** `recommendations.json` for automated configuration

---

## 📋 Analysis Phases

### **Phase 1: Data Loading & Basic Exploration**

**What it analyzes:**
- Dataset sizes (train/test)
- Number of features and outputs
- Data types
- Missing values
- Basic statistics (mean, std, min, max)

**Output:**
- `01_data_exploration.txt`
- Console summary

**Key Questions Answered:**
- Is the data complete?
- Are there missing values?
- What's the scale of the data?
- Is train/test ratio reasonable?

---

### **Phase 2: Distribution Analysis**

**What it analyzes:**
- Normality tests (Shapiro-Wilk)
- Skewness and Kurtosis
- Distribution shapes
- Histogram visualizations

**Output:**
- `02_distribution_analysis.txt`
- `02_input_distributions.png`
- `02_output_distributions.png`

**Key Questions Answered:**
- Are features normally distributed?
- Are there heavy tails or skewness?
- Should we use StandardScaler or other preprocessing?

**Example Insights:**
```
feature1: p-value = 0.0001 (Non-normal)
feature2: p-value = 0.3452 (Normal)
Skewness: 2.3 (right-skewed)
Kurtosis: 8.5 (heavy-tailed)

→ Use StandardScaler (handles non-normal data)
```

---

### **Phase 3: Time Series Characteristics**

**What it analyzes:**
- Autocorrelation (how past values predict future)
- Significant lags
- Stationarity (rolling mean/std)
- Trend analysis

**Output:**
- `03_timeseries_analysis.txt`
- `03_autocorrelation.png`
- `03_timeseries_trend.png`

**Key Questions Answered:**
- How far back does temperature depend on past values?
- Is the data stationary or trending?
- What window size captures dependencies?

**Example Insights:**
```
temp1: Strong autocorrelation at lags: [1, 2, 3, 4, 5, 10, 15, 20]
→ Use window_size ≥ 20 to capture dependencies

Stationarity: Likely non-stationary (std variation: 0.45)
→ Model must learn temporal patterns
```

---

### **Phase 4: Feature Relationships**

**What it analyzes:**
- Pearson correlation (linear relationships)
- Mutual Information (non-linear relationships)
- Feature importance for each output
- Correlation heatmaps

**Output:**
- `04_feature_relationships.txt`
- `04_correlation_heatmap.png`
- `04_feature_importance.png`

**Key Questions Answered:**
- Which features are most important?
- Are relationships linear or non-linear?
- Can we remove any features?

**Example Insights:**
```
Top features for temp1:
1. engine_power (MI: 0.85, Corr: 0.78)
2. altitude (MI: 0.72, Corr: -0.65)
3. speed (MI: 0.68, Corr: 0.54)

→ Keep these features, consider removing low-importance ones
```

---

### **Phase 5: Window Size Analysis**

**What it analyzes:**
- Number of sequences created for each window
- Data usage percentage
- Optimal window sizes
- Trade-offs between window size and data efficiency

**Output:**
- `05_window_size_analysis.txt`
- `05_window_size_analysis.png`

**Key Questions Answered:**
- What window sizes preserve most training data?
- What's the optimal window size?
- How many sequences will I have?

**Example Insights:**
```
Window 10: 8,970 sequences (99% data usage)
Window 20: 8,940 sequences (98% data usage)
Window 50: 8,850 sequences (97% data usage)
Window 100: 8,700 sequences (95% data usage)
Window 200: 8,400 sequences (92% data usage)

Recommended: Start with 50
→ Good balance of context and data efficiency
```

---

### **Phase 6: Data Quality & Outliers**

**What it analyzes:**
- Outlier detection (IQR method)
- Train-test distribution shifts
- Data quality issues
- Boxplot visualizations

**Output:**
- `06_data_quality.txt`
- `06_outliers.png`

**Key Questions Answered:**
- Are there outliers?
- Is test data similar to train data?
- Are there distribution shifts?

**Example Insights:**
```
feature3: 245 outliers (2.7%)
feature7: 12 outliers (0.1%)

Train-test shift:
altitude: 0.3 std (✓ Similar)
speed: 2.1 std (⚠️ Large shift!)

→ Feature 'speed' behaves differently in test!
→ Model may struggle with this
```

---

### **Phase 7: Model Architecture Recommendations**

**What it analyzes:**
- Combines all previous analysis
- Generates specific recommendations
- Provides rationale for each choice
- Creates complete configuration

**Output:**
- `07_model_recommendations.txt`
- `recommendations.json`

**Key Questions Answered:**
- What window size should I use?
- How complex should the model be?
- What hyperparameters should I start with?
- What's my experimentation strategy?

**Example Output:**
```
RECOMMENDED STARTING CONFIGURATION:

MODEL ARCHITECTURE:
  Window Size: 50
  Hidden Size: 32
  Number of Layers: 1
  Dropout: 0.3
  Bidirectional: False

TRAINING HYPERPARAMETERS:
  Learning Rate: 0.0001
  Batch Size: 64
  Optimizer: Adam
  Early Stopping Patience: 20

RATIONALE:
  - Training samples: 9,000
  - Window 50 preserves 97% of data
  - Moderate complexity prevents overfitting
  - Autocorrelation strong up to lag 50

EXPERIMENTATION ORDER:
  1. Baseline with these settings
  2. Try windows: [20, 50, 100]
  3. Increase complexity if underfitting
  4. Add regularization if overfitting
```

---

## 📊 Using the Analysis Results

### **Scenario 1: Analysis shows strong autocorrelation**

**Finding:**
```
Autocorrelation significant up to lag 30
```

**Action:**
- Use window_size ≥ 30
- Start with window=50 to capture dependencies
- Don't use window=10 (too small)

---

### **Scenario 2: Analysis shows weak correlations**

**Finding:**
```
All features have MI < 0.3
Highest correlation: 0.25
```

**Action:**
- May need feature engineering
- Try interaction terms
- Consider domain transformations
- Expect moderate performance (~R² 0.5-0.6)

---

### **Scenario 3: Analysis shows distribution shift**

**Finding:**
```
feature5: Train mean=50, Test mean=80 (shift: 3.2 std)
```

**Action:**
- Model may struggle on test set
- This feature behaves differently in test
- Consider domain adaptation techniques
- Monitor this feature carefully

---

### **Scenario 4: Analysis shows many outliers**

**Finding:**
```
5 features have >5% outliers
```

**Action:**
- Use dropout=0.4-0.5 (high regularization)
- Consider robust scaling
- May need outlier removal or clipping
- Expect some instability in training

---

## 🔧 Integration with Training Pipeline

### **Step 1: Run Analysis**

```python
from data_analysis_pipeline import AnalysisConfig, run_complete_analysis

config = AnalysisConfig()
results, recommendations = run_complete_analysis(
    train_data, test_data, train_sortie_lengths, config
)
```

### **Step 2: Apply Recommendations to Training**

```python
from pytorch_lstm_manual import Config as TrainConfig, train_model

# Create training config from analysis recommendations
train_config = TrainConfig()
train_config.WINDOW_SIZE = recommendations['window_size']
train_config.HIDDEN_SIZE = recommendations['hidden_size']
train_config.NUM_LAYERS = recommendations['num_layers']
train_config.DROPOUT = recommendations['dropout']
train_config.LEARNING_RATE = recommendations['learning_rate']
train_config.BATCH_SIZE = recommendations['batch_size']

# Train model
model, scaler_X, scaler_y, metrics, history = train_model(
    train_data, test_data,
    train_sortie_lengths, test_sortie_lengths,
    train_config
)
```

### **Step 3: Iterate Based on Results**

```python
if metrics['test']['r2_avg'] < 0.3:
    print("Model struggling - try smaller window")
    train_config.WINDOW_SIZE = 20  # Reduce from 50
    
elif metrics['gap'] > 0.2:
    print("Overfitting - increase regularization")
    train_config.DROPOUT = 0.5  # Increase from 0.3
    
elif metrics['test']['r2_avg'] > 0.5 and metrics['gap'] < 0.15:
    print("Good baseline - try automated experiments")
    # Run pytorch_lstm_automated.py
```

---

## 📈 Reading the Reports

### **Executive Summary Format:**

```
╔════════════════════════════════════════════╗
║         EXECUTIVE SUMMARY                  ║
╚════════════════════════════════════════════╝

DATASET OVERVIEW:
  Training samples: 9,000
  Test samples: 3,000
  Input features: 12
  Output variables: 3
  Data quality: ✓ Good

KEY FINDINGS:
  1. Temporal Dependencies: ✓ Strong
  2. Feature Importance: Top 5 features crucial
  3. Data Distribution: Non-normal (use StandardScaler)
  4. Outliers: 3 features have outliers

RECOMMENDED STARTING CONFIGURATION:
  Window Size: 50
  Hidden Size: 32
  Layers: 1
  Dropout: 0.3
  Learning Rate: 0.0001
  Batch Size: 64

NEXT STEPS:
  1. Use recommended config in pytorch_lstm_manual.py
  2. Train baseline model
  3. Check if Test R² > 0.3
  4. Adjust based on results
```

### **Detailed Report Example:**

```
Phase 4: Feature Relationships

Pearson Correlation (temp1):
  engine_power:  0.78 (p < 0.001)  *** Strong positive
  altitude:     -0.65 (p < 0.001)  *** Strong negative
  speed:         0.54 (p < 0.001)  ** Moderate positive
  grms:          0.12 (p = 0.042)  * Weak positive

Mutual Information (temp1):
  engine_power:  0.85
  altitude:      0.72
  speed:         0.68
  grms:          0.15

Interpretation:
  - engine_power is THE most important feature
  - altitude has strong negative relationship
  - Non-linear effects present (MI > Correlation)
  - Keep top 8 features minimum
```

---

## 🎯 Common Analysis Outcomes

### **Outcome 1: Clean Data, Strong Dependencies**

```
✓ No missing values
✓ Few outliers (<1%)
✓ Strong autocorrelation
✓ High feature-output correlation (>0.6)
```

**Expected Model Performance:** R² > 0.8  
**Recommendation:** Start with moderate complexity  
**Risk:** Low

---

### **Outcome 2: Noisy Data, Weak Dependencies**

```
⚠️ Outliers in 5+ features
⚠️ Weak autocorrelation (<0.3)
⚠️ Low feature importance (MI < 0.4)
⚠️ Distribution shifts present
```

**Expected Model Performance:** R² 0.4-0.6  
**Recommendation:** High regularization, careful tuning  
**Risk:** High

---

### **Outcome 3: Strong Temporal, Weak Features**

```
✓ Strong autocorrelation (lag 50+)
⚠️ Low input-output correlation
✓ Clean data
```

**Expected Model Performance:** R² 0.6-0.7  
**Recommendation:** Focus on window size, consider autoregressive approach  
**Risk:** Moderate

---

## 🔍 Advanced Usage

### **Custom Window Sizes:**

```python
config = AnalysisConfig()
config.WINDOW_SIZES_TO_TEST = [5, 10, 15, 20, 30, 50, 75, 100, 150, 200]
# More granular analysis
```

### **More Lags:**

```python
config.MAX_LAG = 200  # Analyze longer dependencies
```

### **Save to Different Folder:**

```python
config.OUTPUT_FOLDER = './analysis_v2'
```

---

## ⚠️ Important Notes

### **Data Requirements:**

- **Minimum samples:** 1,000+ per sortie
- **Time series format:** Sequential samples
- **No missing values:** Or handle before analysis
- **Consistent sampling:** Same rate across sorties

### **Computational Considerations:**

- Analysis takes 2-10 minutes depending on data size
- Large datasets (>50k samples) may take longer
- All plots saved automatically (no interactive viewing)

### **Interpretation Tips:**

1. **Don't over-interpret single metrics** - Look at overall pattern
2. **Normality tests fail with large data** - This is normal
3. **Some outliers are OK** - <5% is acceptable
4. **Distribution shifts happen** - Real-world data varies
5. **Use recommendations as starting point** - Not absolute rules

---

## 📚 What Each Analysis Tells You

| Analysis | Tells You | Impacts |
|----------|-----------|---------|
| **Autocorrelation** | How much history matters | Window size |
| **Correlation** | Linear feature importance | Feature selection |
| **Mutual Info** | Non-linear importance | Model complexity |
| **Distribution** | Data preprocessing needs | Scaling method |
| **Outliers** | Data quality | Regularization strength |
| **Stationarity** | Temporal patterns | Model architecture |
| **Train-Test Shift** | Generalization risk | Expected performance |

---

## ✅ Checklist Before Training

After analysis, verify:

- [ ] Read EXECUTIVE_SUMMARY.txt
- [ ] Understand key findings
- [ ] Note recommended window size
- [ ] Note recommended architecture
- [ ] Check for any data quality warnings
- [ ] Review feature importance
- [ ] Understand train-test differences
- [ ] Ready to start training with informed choices

---

## 🆘 Troubleshooting

### **Issue: Analysis fails with KeyError**

**Cause:** Column names don't match  
**Fix:** Update `INPUT_COLUMNS` and `OUTPUT_COLUMNS` in config

### **Issue: No plots generated**

**Cause:** Matplotlib backend issue  
**Fix:** Reports still generated, plots just not saved

### **Issue: "Not enough data" warning**

**Cause:** Very small dataset (<1000 samples)  
**Fix:** Analysis may be unreliable, proceed with caution

### **Issue: All autocorrelations near zero**

**Cause:** Data may not be time series, or severely non-stationary  
**Fix:** Check data loading, verify temporal order

---

## 🎓 Learning from Analysis

The analysis pipeline teaches you:

1. **Your data's characteristics** - distributions, patterns, quality
2. **Temporal structure** - how past predicts future
3. **Feature importance** - which inputs matter most
4. **Modeling challenges** - outliers, shifts, complexity
5. **Starting point** - where to begin experimentation

**Use this knowledge to make intelligent modeling decisions, not blind trial-and-error.**

---

**Ready to analyze your data and build informed models! 🚀**
