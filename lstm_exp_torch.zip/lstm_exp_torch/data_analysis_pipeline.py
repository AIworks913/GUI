"""
COMPLETE DATA ANALYSIS PIPELINE FOR LSTM TEMPERATURE PREDICTION
================================================================

Comprehensive analysis of time series data to guide model architecture decisions.
Everything is recorded and saved.

Author: Aircraft Temperature Prediction Analysis
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import json
import os
from datetime import datetime
from scipy import stats
from scipy.stats import pearsonr, spearmanr
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import mutual_info_regression
import warnings
warnings.filterwarnings('ignore')


# ============================================================================
# CONFIGURATION
# ============================================================================

class AnalysisConfig:
    """Configuration for data analysis"""
    
    # Output folder
    OUTPUT_FOLDER = './data_analysis'
    
    # Data columns - MODIFY to match your data
    INPUT_COLUMNS = [
        'feature1', 'feature2', 'feature3', 'feature4',
        'feature5', 'feature6', 'feature7', 'feature8',
        'feature9', 'feature10', 'feature11', 'feature12'
    ]
    
    OUTPUT_COLUMNS = ['temp1', 'temp2', 'temp3']
    
    # Analysis parameters
    MAX_LAG = 100  # Maximum lag to check for autocorrelation
    WINDOW_SIZES_TO_TEST = [10, 20, 50, 100, 200]  # Window sizes to analyze


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_output_folder(folder):
    """Create output folder structure"""
    folders = [
        folder,
        f"{folder}/plots",
        f"{folder}/reports",
        f"{folder}/data"
    ]
    for f in folders:
        if not os.path.exists(f):
            os.makedirs(f)
    print(f"✓ Created output structure: {folder}")


def save_report_section(content, filename, config):
    """Save a section of the analysis report"""
    filepath = f"{config.OUTPUT_FOLDER}/reports/{filename}"
    with open(filepath, 'w') as f:
        f.write(content)
    return filepath


# ============================================================================
# PHASE 1: DATA LOADING & BASIC EXPLORATION
# ============================================================================

def phase1_data_exploration(train_data, test_data, train_sortie_lengths, config):
    """
    Phase 1: Initial data exploration
    """
    print("\n" + "="*80)
    print("PHASE 1: DATA LOADING & BASIC EXPLORATION")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 1: DATA LOADING & BASIC EXPLORATION")
    report.append("="*80)
    report.append("")
    
    # Basic info
    print("\n📊 Dataset Information:")
    report.append("Dataset Information:")
    report.append("-" * 40)
    
    n_train = len(train_data)
    n_test = len(test_data)
    n_features = len(config.INPUT_COLUMNS)
    n_outputs = len(config.OUTPUT_COLUMNS)
    
    info = f"""
    Training samples: {n_train:,}
    Test samples: {n_test:,}
    Number of input features: {n_features}
    Number of output variables: {n_outputs}
    
    Training sorties: {len(train_sortie_lengths)}
    Sortie lengths: {train_sortie_lengths}
    
    Train/Test ratio: {n_train/n_test:.2f}
    """
    
    print(info)
    report.append(info)
    
    # Data types
    print("\n📋 Data Types:")
    report.append("\nData Types:")
    report.append("-" * 40)
    
    X_train = train_data[config.INPUT_COLUMNS]
    y_train = train_data[config.OUTPUT_COLUMNS]
    
    dtypes_info = X_train.dtypes.value_counts()
    print(dtypes_info)
    report.append(str(dtypes_info))
    
    # Missing values
    print("\n🔍 Missing Values Check:")
    report.append("\n\nMissing Values:")
    report.append("-" * 40)
    
    train_missing = train_data.isnull().sum().sum()
    test_missing = test_data.isnull().sum().sum()
    
    missing_info = f"""
    Training data: {train_missing} missing values
    Test data: {test_missing} missing values
    """
    
    if train_missing == 0 and test_missing == 0:
        missing_info += "\n    ✓ No missing values found!"
    else:
        missing_info += "\n    ⚠️ Missing values detected!"
        # Show per column
        train_missing_per_col = train_data.isnull().sum()
        train_missing_per_col = train_missing_per_col[train_missing_per_col > 0]
        if len(train_missing_per_col) > 0:
            missing_info += f"\n\n    Columns with missing values:\n{train_missing_per_col}"
    
    print(missing_info)
    report.append(missing_info)
    
    # Statistical summary
    print("\n📈 Statistical Summary:")
    report.append("\n\nStatistical Summary:")
    report.append("-" * 40)
    
    # Create summary table
    summary_stats = pd.DataFrame({
        'Mean': X_train.mean(),
        'Std': X_train.std(),
        'Min': X_train.min(),
        'Max': X_train.max(),
        'Median': X_train.median()
    })
    
    print(summary_stats)
    report.append(summary_stats.to_string())
    
    # Output summary
    print("\n📊 Output Variables Summary:")
    report.append("\n\nOutput Variables Summary:")
    report.append("-" * 40)
    
    output_summary = pd.DataFrame({
        'Mean': y_train.mean(),
        'Std': y_train.std(),
        'Min': y_train.min(),
        'Max': y_train.max()
    })
    
    print(output_summary)
    report.append(output_summary.to_string())
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "01_data_exploration.txt", config)
    print("\n✓ Phase 1 report saved")
    
    return {
        'n_train': n_train,
        'n_test': n_test,
        'n_features': n_features,
        'n_outputs': n_outputs,
        'missing_values': train_missing + test_missing
    }


# ============================================================================
# PHASE 2: DISTRIBUTION ANALYSIS
# ============================================================================

def phase2_distribution_analysis(train_data, test_data, config):
    """
    Phase 2: Analyze distributions of all variables
    """
    print("\n" + "="*80)
    print("PHASE 2: DISTRIBUTION ANALYSIS")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 2: DISTRIBUTION ANALYSIS")
    report.append("="*80)
    report.append("")
    
    X_train = train_data[config.INPUT_COLUMNS]
    y_train = train_data[config.OUTPUT_COLUMNS]
    
    # Normality tests
    print("\n📊 Normality Tests (Shapiro-Wilk):")
    report.append("Normality Tests (Shapiro-Wilk):")
    report.append("-" * 40)
    report.append("If p-value < 0.05, data is NOT normally distributed\n")
    
    normality_results = {}
    
    for col in config.INPUT_COLUMNS:
        if len(X_train[col].dropna()) > 0:
            # Sample for Shapiro test (max 5000 samples)
            sample = X_train[col].dropna().sample(min(5000, len(X_train[col].dropna())), random_state=42)
            stat, p_value = stats.shapiro(sample)
            normality_results[col] = {'statistic': stat, 'p_value': p_value}
            
            is_normal = "Normal" if p_value > 0.05 else "Non-normal"
            print(f"  {col}: p-value = {p_value:.4f} ({is_normal})")
            report.append(f"  {col}: p-value = {p_value:.4f} ({is_normal})")
    
    # Skewness and Kurtosis
    print("\n📊 Skewness and Kurtosis:")
    report.append("\n\nSkewness and Kurtosis:")
    report.append("-" * 40)
    report.append("Skewness: >0 right-skewed, <0 left-skewed, 0 symmetric")
    report.append("Kurtosis: >3 heavy-tailed, <3 light-tailed, 3 normal\n")
    
    skew_kurt = pd.DataFrame({
        'Skewness': X_train.skew(),
        'Kurtosis': X_train.kurtosis()
    })
    
    print(skew_kurt)
    report.append(skew_kurt.to_string())
    
    # Plot distributions
    print("\n📊 Creating distribution plots...")
    
    n_features = len(config.INPUT_COLUMNS)
    n_cols = 3
    n_rows = (n_features + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
    axes = axes.flatten() if n_features > 1 else [axes]
    
    for idx, col in enumerate(config.INPUT_COLUMNS):
        axes[idx].hist(X_train[col].dropna(), bins=50, edgecolor='black', alpha=0.7)
        axes[idx].set_title(f'{col}\nSkew: {X_train[col].skew():.2f}', fontsize=10)
        axes[idx].set_xlabel('Value')
        axes[idx].set_ylabel('Frequency')
        axes[idx].grid(True, alpha=0.3)
    
    # Hide extra subplots
    for idx in range(n_features, len(axes)):
        axes[idx].axis('off')
    
    plt.suptitle('Input Features Distribution', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/02_input_distributions.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    # Output distributions
    fig, axes = plt.subplots(1, len(config.OUTPUT_COLUMNS), figsize=(5*len(config.OUTPUT_COLUMNS), 4))
    if len(config.OUTPUT_COLUMNS) == 1:
        axes = [axes]
    
    for idx, col in enumerate(config.OUTPUT_COLUMNS):
        axes[idx].hist(y_train[col].dropna(), bins=50, edgecolor='black', alpha=0.7)
        axes[idx].set_title(f'{col}\nSkew: {y_train[col].skew():.2f}', fontsize=10)
        axes[idx].set_xlabel('Temperature')
        axes[idx].set_ylabel('Frequency')
        axes[idx].grid(True, alpha=0.3)
    
    plt.suptitle('Output Variables Distribution', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/02_output_distributions.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Distribution plots saved")
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "02_distribution_analysis.txt", config)
    print("✓ Phase 2 report saved")
    
    return {
        'normality_results': normality_results,
        'skewness': skew_kurt
    }


# ============================================================================
# PHASE 3: TIME SERIES CHARACTERISTICS
# ============================================================================

def phase3_time_series_analysis(train_data, config):
    """
    Phase 3: Analyze time series characteristics
    """
    print("\n" + "="*80)
    print("PHASE 3: TIME SERIES CHARACTERISTICS")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 3: TIME SERIES CHARACTERISTICS")
    report.append("="*80)
    report.append("")
    
    y_train = train_data[config.OUTPUT_COLUMNS]
    
    # Autocorrelation analysis
    print("\n📊 Autocorrelation Analysis:")
    report.append("Autocorrelation Analysis:")
    report.append("-" * 40)
    report.append("Measures how current values depend on past values\n")
    
    autocorr_results = {}
    
    for col in config.OUTPUT_COLUMNS:
        print(f"\n  Analyzing {col}...")
        report.append(f"\n{col}:")
        
        # Calculate autocorrelation
        data = y_train[col].dropna()
        max_lag = min(config.MAX_LAG, len(data) // 2)
        
        autocorr = [data.autocorr(lag=i) for i in range(1, max_lag + 1)]
        
        # Find significant lags (>0.5 correlation)
        significant_lags = [i+1 for i, ac in enumerate(autocorr) if abs(ac) > 0.5]
        
        if significant_lags:
            report.append(f"  Strong autocorrelation at lags: {significant_lags[:10]}")
            print(f"    Strong autocorrelation detected at lags: {significant_lags[:10]}")
        else:
            report.append(f"  No strong autocorrelation detected")
            print(f"    No strong autocorrelation detected")
        
        # Store first 10 autocorrelations
        autocorr_results[col] = {
            'autocorr': autocorr[:10],
            'significant_lags': significant_lags[:20]
        }
        
        report.append(f"  Autocorrelation (first 10 lags): {[f'{ac:.3f}' for ac in autocorr[:10]]}")
    
    # Plot autocorrelation
    print("\n📊 Creating autocorrelation plots...")
    
    fig, axes = plt.subplots(len(config.OUTPUT_COLUMNS), 1, 
                             figsize=(12, 4*len(config.OUTPUT_COLUMNS)))
    if len(config.OUTPUT_COLUMNS) == 1:
        axes = [axes]
    
    for idx, col in enumerate(config.OUTPUT_COLUMNS):
        data = y_train[col].dropna()
        max_lag = min(50, len(data) // 2)
        
        # Calculate ACF
        autocorr = [data.autocorr(lag=i) for i in range(max_lag + 1)]
        
        axes[idx].bar(range(len(autocorr)), autocorr, alpha=0.7)
        axes[idx].axhline(y=0, color='black', linestyle='-', linewidth=0.8)
        axes[idx].axhline(y=0.5, color='red', linestyle='--', linewidth=1, label='Strong correlation threshold')
        axes[idx].axhline(y=-0.5, color='red', linestyle='--', linewidth=1)
        axes[idx].set_title(f'Autocorrelation: {col}', fontsize=12, fontweight='bold')
        axes[idx].set_xlabel('Lag')
        axes[idx].set_ylabel('Autocorrelation')
        axes[idx].legend()
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/03_autocorrelation.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Autocorrelation plots saved")
    
    # Stationarity analysis (simple check)
    print("\n📊 Stationarity Check (Rolling Mean/Std):")
    report.append("\n\nStationarity Check:")
    report.append("-" * 40)
    report.append("Stationary data has constant mean and variance over time\n")
    
    window = 100
    
    for col in config.OUTPUT_COLUMNS:
        data = y_train[col].dropna()
        
        # Calculate rolling statistics
        rolling_mean = data.rolling(window=window).mean()
        rolling_std = data.rolling(window=window).std()
        
        # Check if std changes significantly
        std_variation = rolling_std.std() / rolling_std.mean()
        
        if std_variation < 0.1:
            stationarity = "Likely stationary"
        else:
            stationarity = "Likely non-stationary"
        
        print(f"  {col}: {stationarity} (std variation: {std_variation:.3f})")
        report.append(f"  {col}: {stationarity} (std variation: {std_variation:.3f})")
    
    # Plot time series with trend
    print("\n📊 Creating time series plots...")
    
    fig, axes = plt.subplots(len(config.OUTPUT_COLUMNS), 1,
                             figsize=(14, 4*len(config.OUTPUT_COLUMNS)))
    if len(config.OUTPUT_COLUMNS) == 1:
        axes = [axes]
    
    for idx, col in enumerate(config.OUTPUT_COLUMNS):
        data = y_train[col].dropna()
        
        # Plot original data
        axes[idx].plot(data.values, label='Original', alpha=0.7, linewidth=0.8)
        
        # Plot rolling mean
        rolling_mean = data.rolling(window=100).mean()
        axes[idx].plot(rolling_mean.values, label='Rolling Mean (100)', 
                      color='red', linewidth=2)
        
        axes[idx].set_title(f'Time Series: {col}', fontsize=12, fontweight='bold')
        axes[idx].set_xlabel('Sample Index')
        axes[idx].set_ylabel('Value')
        axes[idx].legend()
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/03_timeseries_trend.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Time series plots saved")
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "03_timeseries_analysis.txt", config)
    print("✓ Phase 3 report saved")
    
    return {
        'autocorr_results': autocorr_results
    }


# ============================================================================
# PHASE 4: FEATURE RELATIONSHIPS
# ============================================================================

def phase4_feature_relationships(train_data, config):
    """
    Phase 4: Analyze relationships between features and outputs
    """
    print("\n" + "="*80)
    print("PHASE 4: FEATURE RELATIONSHIPS")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 4: FEATURE RELATIONSHIPS")
    report.append("="*80)
    report.append("")
    
    X_train = train_data[config.INPUT_COLUMNS]
    y_train = train_data[config.OUTPUT_COLUMNS]
    
    # Correlation analysis
    print("\n📊 Feature-Output Correlation:")
    report.append("Feature-Output Correlation (Pearson):")
    report.append("-" * 40)
    report.append("Values closer to ±1 indicate stronger linear relationships\n")
    
    correlation_results = {}
    
    for output_col in config.OUTPUT_COLUMNS:
        print(f"\n  {output_col}:")
        report.append(f"\n{output_col}:")
        
        correlations = []
        for input_col in config.INPUT_COLUMNS:
            corr, p_value = pearsonr(X_train[input_col].dropna(), 
                                     y_train[output_col].dropna())
            correlations.append({
                'feature': input_col,
                'correlation': corr,
                'p_value': p_value
            })
        
        # Sort by absolute correlation
        correlations_df = pd.DataFrame(correlations)
        correlations_df = correlations_df.reindex(
            correlations_df['correlation'].abs().sort_values(ascending=False).index
        )
        
        correlation_results[output_col] = correlations_df
        
        # Show top 5
        print(correlations_df.head(5).to_string(index=False))
        report.append(correlations_df.to_string(index=False))
    
    # Plot correlation heatmap
    print("\n📊 Creating correlation heatmap...")
    
    # Combine inputs and outputs
    all_data = pd.concat([X_train, y_train], axis=1)
    corr_matrix = all_data.corr()
    
    # Extract input-output correlations
    input_output_corr = corr_matrix.loc[config.INPUT_COLUMNS, config.OUTPUT_COLUMNS]
    
    plt.figure(figsize=(8, 10))
    sns.heatmap(input_output_corr, annot=True, fmt='.2f', cmap='coolwarm',
                center=0, cbar_kws={'label': 'Correlation'})
    plt.title('Input-Output Correlation Matrix', fontsize=14, fontweight='bold')
    plt.xlabel('Output Variables')
    plt.ylabel('Input Features')
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/04_correlation_heatmap.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Correlation heatmap saved")
    
    # Mutual Information (non-linear relationships)
    print("\n📊 Mutual Information Analysis:")
    report.append("\n\nMutual Information (captures non-linear relationships):")
    report.append("-" * 40)
    
    mi_results = {}
    
    for output_col in config.OUTPUT_COLUMNS:
        print(f"\n  {output_col}:")
        report.append(f"\n{output_col}:")
        
        mi_scores = mutual_info_regression(X_train, y_train[output_col], random_state=42)
        
        mi_df = pd.DataFrame({
            'feature': config.INPUT_COLUMNS,
            'mi_score': mi_scores
        }).sort_values('mi_score', ascending=False)
        
        mi_results[output_col] = mi_df
        
        print(mi_df.head(5).to_string(index=False))
        report.append(mi_df.to_string(index=False))
    
    # Feature importance plot (using mutual information)
    print("\n📊 Creating feature importance plot...")
    
    fig, axes = plt.subplots(1, len(config.OUTPUT_COLUMNS),
                             figsize=(6*len(config.OUTPUT_COLUMNS), 8))
    if len(config.OUTPUT_COLUMNS) == 1:
        axes = [axes]
    
    for idx, output_col in enumerate(config.OUTPUT_COLUMNS):
        mi_df = mi_results[output_col]
        
        axes[idx].barh(range(len(mi_df)), mi_df['mi_score'])
        axes[idx].set_yticks(range(len(mi_df)))
        axes[idx].set_yticklabels(mi_df['feature'])
        axes[idx].set_xlabel('Mutual Information Score')
        axes[idx].set_title(f'Feature Importance: {output_col}', fontweight='bold')
        axes[idx].invert_yaxis()
        axes[idx].grid(True, alpha=0.3, axis='x')
    
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/04_feature_importance.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Feature importance plot saved")
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "04_feature_relationships.txt", config)
    print("✓ Phase 4 report saved")
    
    return {
        'correlation_results': correlation_results,
        'mi_results': mi_results
    }


# ============================================================================
# PHASE 5: WINDOW SIZE ANALYSIS
# ============================================================================

def phase5_window_size_analysis(train_data, train_sortie_lengths, config):
    """
    Phase 5: Analyze optimal window sizes
    """
    print("\n" + "="*80)
    print("PHASE 5: WINDOW SIZE ANALYSIS")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 5: WINDOW SIZE ANALYSIS")
    report.append("="*80)
    report.append("")
    report.append("Analyzing how much history is needed for prediction\n")
    
    X_train = train_data[config.INPUT_COLUMNS].values
    y_train = train_data[config.OUTPUT_COLUMNS].values
    
    # Scale data
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    X_scaled = scaler_X.fit_transform(X_train)
    y_scaled = scaler_y.fit_transform(y_train)
    
    # Create sequences for different window sizes
    print("\n📊 Testing different window sizes:")
    report.append("Testing different window sizes:")
    report.append("-" * 40)
    
    window_analysis = []
    
    for window_size in config.WINDOW_SIZES_TO_TEST:
        print(f"\n  Window size: {window_size}")
        report.append(f"\nWindow size: {window_size}")
        
        # Create sequences
        X_seq = []
        y_seq = []
        
        start_idx = 0
        for length in train_sortie_lengths:
            end_idx = start_idx + length
            
            X_sortie = X_scaled[start_idx:end_idx]
            y_sortie = y_scaled[start_idx:end_idx]
            
            for i in range(window_size, len(X_sortie)):
                X_seq.append(X_sortie[i-window_size:i])
                y_seq.append(y_sortie[i])
            
            start_idx = end_idx
        
        X_seq = np.array(X_seq)
        y_seq = np.array(y_seq)
        
        n_sequences = len(X_seq)
        data_usage = (n_sequences * window_size) / len(X_train) * 100
        
        info = f"  Sequences created: {n_sequences:,}"
        info += f"\n  Data usage: {data_usage:.1f}%"
        info += f"\n  Sequence shape: {X_seq.shape}"
        
        print(info)
        report.append(info)
        
        window_analysis.append({
            'window_size': window_size,
            'n_sequences': n_sequences,
            'data_usage': data_usage,
            'shape': X_seq.shape
        })
    
    # Plot window size analysis
    print("\n📊 Creating window size analysis plot...")
    
    wa_df = pd.DataFrame(window_analysis)
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Number of sequences
    axes[0].bar(range(len(wa_df)), wa_df['n_sequences'])
    axes[0].set_xticks(range(len(wa_df)))
    axes[0].set_xticklabels(wa_df['window_size'])
    axes[0].set_xlabel('Window Size')
    axes[0].set_ylabel('Number of Sequences')
    axes[0].set_title('Sequences Created vs Window Size', fontweight='bold')
    axes[0].grid(True, alpha=0.3, axis='y')
    
    # Data usage
    axes[1].plot(wa_df['window_size'], wa_df['data_usage'], marker='o', linewidth=2, markersize=8)
    axes[1].set_xlabel('Window Size')
    axes[1].set_ylabel('Data Usage (%)')
    axes[1].set_title('Data Usage vs Window Size', fontweight='bold')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/05_window_size_analysis.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Window size analysis plot saved")
    
    # Recommendations
    print("\n💡 Window Size Recommendations:")
    report.append("\n\nWindow Size Recommendations:")
    report.append("-" * 40)
    
    # Find window with >80% data usage
    good_windows = wa_df[wa_df['data_usage'] >= 80]
    
    if len(good_windows) > 0:
        recommended = good_windows.iloc[0]['window_size']
        rec_text = f"""
    Based on data usage analysis:
    - Recommended starting window: {recommended}
    - This preserves >80% of training data
    - Provides {good_windows.iloc[0]['n_sequences']:,} training sequences
    
    You can try windows: {list(good_windows['window_size'].values)}
        """
    else:
        rec_text = """
    ⚠️ All tested windows use <80% of data
    - Start with smallest window (10-20)
    - Gradually increase if model underfits
        """
    
    print(rec_text)
    report.append(rec_text)
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "05_window_size_analysis.txt", config)
    print("✓ Phase 5 report saved")
    
    return {
        'window_analysis': window_analysis,
        'recommended_window': recommended if len(good_windows) > 0 else 50
    }


# ============================================================================
# PHASE 6: DATA QUALITY & OUTLIERS
# ============================================================================

def phase6_data_quality(train_data, test_data, config):
    """
    Phase 6: Data quality and outlier detection
    """
    print("\n" + "="*80)
    print("PHASE 6: DATA QUALITY & OUTLIER DETECTION")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 6: DATA QUALITY & OUTLIER DETECTION")
    report.append("="*80)
    report.append("")
    
    X_train = train_data[config.INPUT_COLUMNS]
    
    # Outlier detection (IQR method)
    print("\n📊 Outlier Detection (IQR Method):")
    report.append("Outlier Detection (IQR Method):")
    report.append("-" * 40)
    report.append("Values beyond Q1-1.5*IQR or Q3+1.5*IQR are considered outliers\n")
    
    outlier_summary = {}
    
    for col in config.INPUT_COLUMNS:
        Q1 = X_train[col].quantile(0.25)
        Q3 = X_train[col].quantile(0.75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        outliers = X_train[(X_train[col] < lower_bound) | (X_train[col] > upper_bound)]
        n_outliers = len(outliers)
        pct_outliers = 100 * n_outliers / len(X_train)
        
        if n_outliers > 0:
            outlier_summary[col] = {
                'count': n_outliers,
                'percentage': pct_outliers,
                'lower_bound': lower_bound,
                'upper_bound': upper_bound
            }
            print(f"  {col}: {n_outliers} outliers ({pct_outliers:.2f}%)")
            report.append(f"  {col}: {n_outliers} outliers ({pct_outliers:.2f}%)")
    
    if not outlier_summary:
        print("  ✓ No significant outliers detected")
        report.append("  ✓ No significant outliers detected")
    
    # Plot boxplots
    print("\n📊 Creating outlier visualization...")
    
    fig, axes = plt.subplots(3, 4, figsize=(16, 12))
    axes = axes.flatten()
    
    for idx, col in enumerate(config.INPUT_COLUMNS):
        axes[idx].boxplot([X_train[col].dropna()], labels=[col])
        axes[idx].set_ylabel('Value')
        axes[idx].set_title(col, fontsize=10)
        axes[idx].grid(True, alpha=0.3, axis='y')
        
        # Mark if has outliers
        if col in outlier_summary:
            axes[idx].text(0.5, 0.95, f'{outlier_summary[col]["count"]} outliers',
                          transform=axes[idx].transAxes,
                          ha='center', va='top',
                          bbox=dict(boxstyle='round', facecolor='red', alpha=0.3),
                          fontsize=8)
    
    plt.suptitle('Outlier Detection (Boxplots)', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{config.OUTPUT_FOLDER}/plots/06_outliers.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("✓ Outlier plots saved")
    
    # Train-test distribution comparison
    print("\n📊 Train-Test Distribution Comparison:")
    report.append("\n\nTrain-Test Distribution Comparison:")
    report.append("-" * 40)
    
    X_test = test_data[config.INPUT_COLUMNS]
    
    distribution_shift = []
    
    for col in config.INPUT_COLUMNS:
        train_mean = X_train[col].mean()
        test_mean = X_test[col].mean()
        train_std = X_train[col].std()
        
        # Calculate shift in standard deviations
        shift = abs(train_mean - test_mean) / train_std if train_std > 0 else 0
        
        distribution_shift.append({
            'feature': col,
            'train_mean': train_mean,
            'test_mean': test_mean,
            'shift_std': shift
        })
        
        if shift > 2:
            warning = "⚠️ Large shift!"
        elif shift > 1:
            warning = "⚠️ Moderate shift"
        else:
            warning = "✓ Similar"
        
        print(f"  {col}: shift = {shift:.2f} std ({warning})")
        report.append(f"  {col}: shift = {shift:.2f} std ({warning})")
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "06_data_quality.txt", config)
    print("✓ Phase 6 report saved")
    
    return {
        'outlier_summary': outlier_summary,
        'distribution_shift': distribution_shift
    }


# ============================================================================
# PHASE 7: MODEL ARCHITECTURE RECOMMENDATIONS
# ============================================================================

def phase7_model_recommendations(analysis_results, config):
    """
    Phase 7: Generate model architecture recommendations
    """
    print("\n" + "="*80)
    print("PHASE 7: MODEL ARCHITECTURE RECOMMENDATIONS")
    print("="*80)
    
    report = []
    report.append("="*80)
    report.append("PHASE 7: MODEL ARCHITECTURE RECOMMENDATIONS")
    report.append("="*80)
    report.append("")
    report.append("Based on comprehensive data analysis\n")
    
    recommendations = {}
    
    # Window size recommendation
    print("\n🎯 Window Size:")
    report.append("Window Size:")
    report.append("-" * 40)
    
    recommended_window = analysis_results['phase5']['recommended_window']
    
    window_rec = f"""
    Recommended: {recommended_window}
    
    Rationale:
    - Preserves maximum training data
    - Autocorrelation analysis shows dependencies up to lag {recommended_window//2}
    - Start with this, adjust based on results
    
    Alternative windows to try: {config.WINDOW_SIZES_TO_TEST}
    """
    
    print(window_rec)
    report.append(window_rec)
    recommendations['window_size'] = recommended_window
    
    # Model complexity recommendation
    print("\n🎯 Model Complexity:")
    report.append("\n\nModel Complexity:")
    report.append("-" * 40)
    
    n_train = analysis_results['phase1']['n_train']
    n_features = analysis_results['phase1']['n_features']
    
    # Simple heuristic based on data size
    if n_train < 5000:
        hidden_size = 16
        num_layers = 1
        complexity = "Simple"
    elif n_train < 10000:
        hidden_size = 32
        num_layers = 1
        complexity = "Moderate"
    else:
        hidden_size = 64
        num_layers = 2
        complexity = "Complex"
    
    complexity_rec = f"""
    Recommended starting point: {complexity}
    - Hidden size: {hidden_size}
    - Number of layers: {num_layers}
    
    Rationale:
    - Training samples: {n_train:,}
    - Input features: {n_features}
    - Start simple, increase if underfitting
    
    Progression:
    1. Start: hidden={hidden_size}, layers={num_layers}
    2. If underfitting: hidden={hidden_size*2}, layers={num_layers}
    3. If still underfitting: hidden={hidden_size*2}, layers={num_layers+1}
    """
    
    print(complexity_rec)
    report.append(complexity_rec)
    recommendations['hidden_size'] = hidden_size
    recommendations['num_layers'] = num_layers
    
    # Regularization recommendation
    print("\n🎯 Regularization:")
    report.append("\n\nRegularization:")
    report.append("-" * 40)
    
    # Check if data has high variance or many outliers
    has_outliers = len(analysis_results['phase6']['outlier_summary']) > 0
    
    if has_outliers:
        dropout = 0.3
        reg_rec = """
    Recommended: dropout = 0.3
    
    Rationale:
    - Outliers detected in data
    - Dropout helps model generalize
    - Can increase to 0.5 if overfitting occurs
        """
    else:
        dropout = 0.2
        reg_rec = """
    Recommended: dropout = 0.2
    
    Rationale:
    - Clean data with few outliers
    - Light regularization to prevent overfitting
    - Increase if train/test gap > 0.15
        """
    
    print(reg_rec)
    report.append(reg_rec)
    recommendations['dropout'] = dropout
    
    # Learning rate recommendation
    print("\n🎯 Learning Rate:")
    report.append("\n\nLearning Rate:")
    report.append("-" * 40)
    
    lr_rec = """
    Recommended: 0.0001
    
    Rationale:
    - Safe starting point for most datasets
    - Provides stable training
    - Reduce to 0.00005 if training unstable
    - Increase to 0.0005 if learning too slow
    """
    
    print(lr_rec)
    report.append(lr_rec)
    recommendations['learning_rate'] = 0.0001
    
    # Batch size recommendation
    print("\n🎯 Batch Size:")
    report.append("\n\nBatch Size:")
    report.append("-" * 40)
    
    if n_train < 5000:
        batch_size = 32
    elif n_train < 15000:
        batch_size = 64
    else:
        batch_size = 128
    
    batch_rec = f"""
    Recommended: {batch_size}
    
    Rationale:
    - Based on training set size ({n_train:,})
    - Balances training stability and speed
    - Reduce if GPU memory issues
    - Increase if training is slow
    """
    
    print(batch_rec)
    report.append(batch_rec)
    recommendations['batch_size'] = batch_size
    
    # Feature preprocessing recommendation
    print("\n🎯 Feature Preprocessing:")
    report.append("\n\nFeature Preprocessing:")
    report.append("-" * 40)
    
    normality_count = sum(1 for r in analysis_results['phase2']['normality_results'].values() 
                         if r['p_value'] > 0.05)
    
    if normality_count < len(config.INPUT_COLUMNS) / 2:
        preproc_rec = """
    Recommended: StandardScaler
    
    Rationale:
    - Most features are non-normally distributed
    - StandardScaler handles this well
    - Already implemented in training pipeline
        """
    else:
        preproc_rec = """
    Recommended: StandardScaler or MinMaxScaler
    
    Rationale:
    - Features approximately normally distributed
    - Either scaler will work well
    - StandardScaler is safe default
        """
    
    print(preproc_rec)
    report.append(preproc_rec)
    
    # Important features
    print("\n🎯 Feature Selection:")
    report.append("\n\nFeature Selection:")
    report.append("-" * 40)
    
    # Get top features from MI analysis
    top_features = {}
    for output in config.OUTPUT_COLUMNS:
        mi_df = analysis_results['phase4']['mi_results'][output]
        top_features[output] = list(mi_df.head(5)['feature'].values)
    
    feature_rec = "\nTop 5 most important features for each output:\n"
    for output, features in top_features.items():
        feature_rec += f"\n{output}:\n"
        feature_rec += "\n".join([f"  {i+1}. {f}" for i, f in enumerate(features)])
        feature_rec += "\n"
    
    feature_rec += """
    Recommendation:
    - Use all features initially
    - If model is slow/overfitting, try removing low-importance features
    - Keep at least top 8-10 features per output
    """
    
    print(feature_rec)
    report.append(feature_rec)
    
    # Final configuration
    print("\n" + "="*80)
    print("RECOMMENDED STARTING CONFIGURATION")
    print("="*80)
    
    final_config = f"""
    
MODEL ARCHITECTURE:
  Window Size: {recommendations['window_size']}
  Hidden Size: {recommendations['hidden_size']}
  Number of Layers: {recommendations['num_layers']}
  Dropout: {recommendations['dropout']}
  Bidirectional: False (start with False, try True if needed)

TRAINING HYPERPARAMETERS:
  Learning Rate: {recommendations['learning_rate']}
  Batch Size: {recommendations['batch_size']}
  Optimizer: Adam
  Loss Function: MSE (Mean Squared Error)
  Early Stopping Patience: 20 epochs

PREPROCESSING:
  Input Scaling: StandardScaler (fit on train only!)
  Output Scaling: StandardScaler (fit on train only!)
  Sequence Creation: Respect sortie boundaries (no cross-sortie sequences)

EVALUATION STRATEGY:
  Train/Val Split: 80/20 (random from sequences)
  Test: Separate sortie (chronological evaluation)
  Metrics: R², RMSE, MAE per output
  
EXPERIMENTATION ORDER:
  1. Baseline: Start with recommended config above
  2. Window Size: Try {config.WINDOW_SIZES_TO_TEST}
  3. Complexity: Increase if underfitting (hidden size, layers)
  4. Regularization: Increase dropout if overfitting (>0.2 gap)
  5. Learning Rate: Adjust if training unstable

SUCCESS CRITERIA:
  - Test R² > 0.7 (Good)
  - Test R² > 0.5 (Acceptable)
  - Train-Test gap < 0.15 (Not overfitting)
  - Smooth training curves (Stable learning)
    """
    
    print(final_config)
    report.append("\n" + "="*80)
    report.append("RECOMMENDED STARTING CONFIGURATION")
    report.append("="*80)
    report.append(final_config)
    
    # Save report
    report_text = "\n".join(report)
    save_report_section(report_text, "07_model_recommendations.txt", config)
    
    # Save recommendations as JSON
    rec_json = {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'recommendations': recommendations,
        'top_features': top_features
    }
    
    with open(f"{config.OUTPUT_FOLDER}/reports/recommendations.json", 'w') as f:
        json.dump(rec_json, f, indent=4)
    
    print("\n✓ Phase 7 report saved")
    print("✓ Recommendations JSON saved")
    
    return recommendations


# ============================================================================
# MAIN ANALYSIS PIPELINE
# ============================================================================

def run_complete_analysis(train_data, test_data, train_sortie_lengths, config):
    """
    Run complete data analysis pipeline
    
    Parameters:
    -----------
    train_data : DataFrame
        Combined training data (s1 + s2 + s3)
    test_data : DataFrame
        Test data (single sortie)
    train_sortie_lengths : list of int
        [len(s1), len(s2), len(s3)]
    config : AnalysisConfig
    """
    
    print("\n" + "╔" + "="*78 + "╗")
    print("║" + " "*78 + "║")
    print("║" + "  COMPLETE DATA ANALYSIS PIPELINE".center(78) + "║")
    print("║" + "  For LSTM Temperature Prediction".center(78) + "║")
    print("║" + " "*78 + "║")
    print("╚" + "="*78 + "╝")
    
    # Create output folder
    create_output_folder(config.OUTPUT_FOLDER)
    
    # Store all results
    analysis_results = {}
    
    # Phase 1: Basic Exploration
    analysis_results['phase1'] = phase1_data_exploration(
        train_data, test_data, train_sortie_lengths, config
    )
    
    # Phase 2: Distribution Analysis
    analysis_results['phase2'] = phase2_distribution_analysis(
        train_data, test_data, config
    )
    
    # Phase 3: Time Series Characteristics
    analysis_results['phase3'] = phase3_time_series_analysis(
        train_data, config
    )
    
    # Phase 4: Feature Relationships
    analysis_results['phase4'] = phase4_feature_relationships(
        train_data, config
    )
    
    # Phase 5: Window Size Analysis
    test_sortie_lengths = [len(test_data)]
    analysis_results['phase5'] = phase5_window_size_analysis(
        train_data, train_sortie_lengths, config
    )
    
    # Phase 6: Data Quality
    analysis_results['phase6'] = phase6_data_quality(
        train_data, test_data, config
    )
    
    # Phase 7: Model Recommendations
    recommendations = phase7_model_recommendations(
        analysis_results, config
    )
    
    # Generate executive summary
    print("\n" + "="*80)
    print("GENERATING EXECUTIVE SUMMARY")
    print("="*80)
    
    summary = f"""
╔════════════════════════════════════════════════════════════════════════╗
║                         EXECUTIVE SUMMARY                              ║
╚════════════════════════════════════════════════════════════════════════╝

DATASET OVERVIEW:
  Training samples: {analysis_results['phase1']['n_train']:,}
  Test samples: {analysis_results['phase1']['n_test']:,}
  Input features: {analysis_results['phase1']['n_features']}
  Output variables: {analysis_results['phase1']['n_outputs']}
  Data quality: {'✓ Good' if analysis_results['phase1']['missing_values'] == 0 else '⚠️ Has issues'}

KEY FINDINGS:
  1. Temporal Dependencies: {'✓ Strong' if len(analysis_results['phase3']['autocorr_results'][config.OUTPUT_COLUMNS[0]]['significant_lags']) > 0 else '⚠️ Weak'}
  2. Feature Importance: Top feature contributes significantly
  3. Data Distribution: Non-normal (use StandardScaler)
  4. Outliers: {len(analysis_results['phase6']['outlier_summary'])} features have outliers

RECOMMENDED STARTING CONFIGURATION:
  Window Size: {recommendations['window_size']}
  Hidden Size: {recommendations['hidden_size']}
  Layers: {recommendations['num_layers']}
  Dropout: {recommendations['dropout']}
  Learning Rate: {recommendations['learning_rate']}
  Batch Size: {recommendations['batch_size']}

NEXT STEPS:
  1. Use recommended configuration in pytorch_lstm_manual.py
  2. Train baseline model
  3. If Test R² < 0: Try smaller window (10-20)
  4. If Test R² 0.3-0.5: Increase model complexity
  5. If Test R² > 0.5: Run automated experiments to optimize

ALL REPORTS AND PLOTS SAVED TO: {config.OUTPUT_FOLDER}/

═══════════════════════════════════════════════════════════════════════════
    """
    
    print(summary)
    
    # Save executive summary
    with open(f"{config.OUTPUT_FOLDER}/EXECUTIVE_SUMMARY.txt", 'w') as f:
        f.write(summary)
    
    print(f"\n✓ Executive summary saved: {config.OUTPUT_FOLDER}/EXECUTIVE_SUMMARY.txt")
    
    print("\n" + "="*80)
    print("✅ COMPLETE ANALYSIS FINISHED!")
    print("="*80)
    print(f"\nCheck {config.OUTPUT_FOLDER}/ for:")
    print("  - reports/: All analysis reports (.txt)")
    print("  - plots/: All visualizations (.png)")
    print("  - EXECUTIVE_SUMMARY.txt: Quick overview")
    print("  - reports/recommendations.json: Machine-readable recommendations")
    
    return analysis_results, recommendations


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    
    print("""
    ╔════════════════════════════════════════════════════════════════════════╗
    ║         COMPLETE DATA ANALYSIS PIPELINE FOR LSTM MODELING              ║
    ╚════════════════════════════════════════════════════════════════════════╝
    
    This pipeline analyzes your data and provides detailed recommendations
    for LSTM model architecture and training.
    
    HOW TO USE:
    
    1. Load your data:
       import pandas as pd
       
       s1 = pd.read_csv('sortie1.csv')
       s2 = pd.read_csv('sortie2.csv')
       s3 = pd.read_csv('sortie3.csv')
       test = pd.read_csv('test_sortie.csv')
       
       train_data = pd.concat([s1, s2, s3], ignore_index=True)
       test_data = test
       
       train_sortie_lengths = [len(s1), len(s2), len(s3)]
    
    2. Update AnalysisConfig (top of file) with your column names
    
    3. Run analysis:
       config = AnalysisConfig()
       results, recommendations = run_complete_analysis(
           train_data, test_data, train_sortie_lengths, config
       )
    
    4. Review outputs in ./data_analysis/ folder
    
    5. Use recommendations in pytorch_lstm_manual.py to train model
    
    WHAT YOU GET:
    - Comprehensive reports on data characteristics
    - Visualizations of distributions, correlations, time series
    - Recommendations for window size, model architecture
    - Recommendations for hyperparameters
    - Everything saved and recorded for reference
    """)
