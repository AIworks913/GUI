"""
PYTORCH LSTM TRAINER - MANUAL EXPERIMENTS
==========================================

Simple, clean PyTorch implementation for LSTM temperature prediction.
Run experiments one by one, manually changing hyperparameters.

Author: Aircraft Temperature Prediction
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import json
import os
from datetime import datetime

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Set random seeds
np.random.seed(42)
torch.manual_seed(42)

# Device configuration
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")


# ============================================================================
# CONFIGURATION
# ============================================================================

class Config:
    """
    Experiment Configuration
    Modify these parameters to run different experiments
    """
    
    # Paths
    OUTPUT_FOLDER = './outputs'
    
    # Data columns - MODIFY THESE to match your data
    INPUT_COLUMNS = [
        'feature1', 'feature2', 'feature3', 'feature4',
        'feature5', 'feature6', 'feature7', 'feature8',
        'feature9', 'feature10', 'feature11', 'feature12'
    ]  # Your 12 input features
    
    OUTPUT_COLUMNS = ['temp1', 'temp2', 'temp3']  # Your 3-4 outputs
    
    # Station column (commented out - uncomment if you want to use it)
    # STATION_COLUMN = 'station'
    
    # Model Architecture
    WINDOW_SIZE = 50        # Number of past timesteps (try: 10, 20, 50, 100, 200)
    HIDDEN_SIZE = 32        # LSTM hidden units (try: 16, 32, 64, 128)
    NUM_LAYERS = 1          # Number of LSTM layers (try: 1, 2, 3)
    DROPOUT = 0.3           # Dropout rate (try: 0.0, 0.2, 0.3, 0.5)
    BIDIRECTIONAL = False   # Use bidirectional LSTM (try: False, True)
    
    # Training Hyperparameters
    LEARNING_RATE = 0.0001  # Learning rate (try: 0.00005, 0.0001, 0.0005, 0.001)
    BATCH_SIZE = 64         # Batch size (try: 32, 64, 128, 256)
    EPOCHS = 200            # Maximum epochs
    PATIENCE = 20           # Early stopping patience
    
    # Experiment name
    EXPERIMENT_NAME = f'Exp_w{WINDOW_SIZE}_h{HIDDEN_SIZE}_L{NUM_LAYERS}_lr{LEARNING_RATE}'


# ============================================================================
# DATASET CLASS
# ============================================================================

class TimeSeriesDataset(Dataset):
    """PyTorch Dataset for time series data"""
    
    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ============================================================================
# LSTM MODEL
# ============================================================================

class LSTMModel(nn.Module):
    """
    LSTM Model for Temperature Prediction
    
    Simple and clean architecture
    """
    
    def __init__(self, input_size, hidden_size, num_layers, output_size, 
                 dropout=0.0, bidirectional=False):
        super(LSTMModel, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        
        # LSTM layer
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional
        )
        
        # Dropout (after LSTM, before output)
        self.dropout = nn.Dropout(dropout)
        
        # Output layer
        lstm_output_size = hidden_size * 2 if bidirectional else hidden_size
        self.fc = nn.Linear(lstm_output_size, output_size)
    
    def forward(self, x):
        # x shape: (batch, seq_len, input_size)
        
        # LSTM forward
        lstm_out, _ = self.lstm(x)
        
        # Take last time step
        out = lstm_out[:, -1, :]  # (batch, hidden_size * num_directions)
        
        # Dropout
        out = self.dropout(out)
        
        # Output layer
        out = self.fc(out)
        
        return out


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_output_folder(folder):
    """Create output folder if it doesn't exist"""
    if not os.path.exists(folder):
        os.makedirs(folder)
        print(f"✓ Created output folder: {folder}")


def create_sequences(X, y, sortie_lengths, window_size):
    """
    Create sequences without crossing sortie boundaries
    
    Parameters:
    -----------
    X : array, shape (n_samples, n_features)
    y : array, shape (n_samples, n_outputs)
    sortie_lengths : list of int
    window_size : int
    
    Returns:
    --------
    X_seq : array, shape (n_sequences, window_size, n_features)
    y_seq : array, shape (n_sequences, n_outputs)
    """
    X_seq = []
    y_seq = []
    
    start_idx = 0
    for length in sortie_lengths:
        end_idx = start_idx + length
        
        X_sortie = X[start_idx:end_idx]
        y_sortie = y[start_idx:end_idx]
        
        # Create sequences within this sortie
        for i in range(window_size, len(X_sortie)):
            X_seq.append(X_sortie[i-window_size:i])
            y_seq.append(y_sortie[i])
        
        start_idx = end_idx
    
    return np.array(X_seq), np.array(y_seq)


def train_epoch(model, dataloader, criterion, optimizer, device):
    """Train for one epoch"""
    model.train()
    total_loss = 0
    
    for X_batch, y_batch in dataloader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)
        
        # Forward pass
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
    
    return total_loss / len(dataloader)


def validate(model, dataloader, criterion, device):
    """Validate model"""
    model.eval()
    total_loss = 0
    
    with torch.no_grad():
        for X_batch, y_batch in dataloader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            
            total_loss += loss.item()
    
    return total_loss / len(dataloader)


def predict(model, dataloader, device):
    """Make predictions"""
    model.eval()
    predictions = []
    
    with torch.no_grad():
        for X_batch, _ in dataloader:
            X_batch = X_batch.to(device)
            outputs = model(X_batch)
            predictions.append(outputs.cpu().numpy())
    
    return np.concatenate(predictions, axis=0)


def evaluate_model(model, train_loader, test_loader, scaler_y, device):
    """
    Evaluate model and return metrics
    """
    # Get predictions
    y_train_pred_scaled = predict(model, train_loader, device)
    y_test_pred_scaled = predict(model, test_loader, device)
    
    # Get true values
    y_train_true_scaled = []
    y_test_true_scaled = []
    
    for _, y in train_loader:
        y_train_true_scaled.append(y.numpy())
    y_train_true_scaled = np.concatenate(y_train_true_scaled, axis=0)
    
    for _, y in test_loader:
        y_test_true_scaled.append(y.numpy())
    y_test_true_scaled = np.concatenate(y_test_true_scaled, axis=0)
    
    # Inverse transform
    y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled)
    y_train_true = scaler_y.inverse_transform(y_train_true_scaled)
    
    y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled)
    y_test_true = scaler_y.inverse_transform(y_test_true_scaled)
    
    # Calculate metrics
    metrics = {
        'train': {'r2': [], 'rmse': [], 'mae': []},
        'test': {'r2': [], 'rmse': [], 'mae': []}
    }
    
    for i in range(y_train_true.shape[1]):
        # Train
        train_r2 = r2_score(y_train_true[:, i], y_train_pred[:, i])
        train_rmse = np.sqrt(mean_squared_error(y_train_true[:, i], y_train_pred[:, i]))
        train_mae = mean_absolute_error(y_train_true[:, i], y_train_pred[:, i])
        
        metrics['train']['r2'].append(train_r2)
        metrics['train']['rmse'].append(train_rmse)
        metrics['train']['mae'].append(train_mae)
        
        # Test
        test_r2 = r2_score(y_test_true[:, i], y_test_pred[:, i])
        test_rmse = np.sqrt(mean_squared_error(y_test_true[:, i], y_test_pred[:, i]))
        test_mae = mean_absolute_error(y_test_true[:, i], y_test_pred[:, i])
        
        metrics['test']['r2'].append(test_r2)
        metrics['test']['rmse'].append(test_rmse)
        metrics['test']['mae'].append(test_mae)
    
    # Average metrics
    metrics['train']['r2_avg'] = np.mean(metrics['train']['r2'])
    metrics['test']['r2_avg'] = np.mean(metrics['test']['r2'])
    metrics['gap'] = metrics['train']['r2_avg'] - metrics['test']['r2_avg']
    
    return metrics, y_train_pred, y_test_pred, y_train_true, y_test_true


def plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred,
                 metrics, config):
    """
    Plot training history and predictions
    All 4 outputs in single column as LINE PLOTS
    """
    n_outputs = y_test_true.shape[1]
    
    # Create figure with 2 + n_outputs rows
    fig = plt.figure(figsize=(16, 4 * (2 + n_outputs)))
    
    # Row 1: Training Loss
    ax1 = plt.subplot(2 + n_outputs, 1, 1)
    ax1.plot(history['train_loss'], label='Train Loss', linewidth=2, color='blue')
    ax1.plot(history['val_loss'], label='Val Loss', linewidth=2, color='orange')
    ax1.set_xlabel('Epoch', fontsize=11)
    ax1.set_ylabel('Loss (MSE)', fontsize=11)
    ax1.set_title('Training History - Loss', fontsize=13, fontweight='bold')
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)
    
    # Row 2: Best epoch marker
    ax2 = plt.subplot(2 + n_outputs, 1, 2)
    ax2.plot(history['train_loss'], label='Train Loss', linewidth=2, color='blue', alpha=0.5)
    ax2.plot(history['val_loss'], label='Val Loss', linewidth=2, color='orange', alpha=0.5)
    best_epoch = np.argmin(history['val_loss'])
    ax2.axvline(x=best_epoch, color='red', linestyle='--', linewidth=2, label=f'Best Epoch ({best_epoch+1})')
    ax2.set_xlabel('Epoch', fontsize=11)
    ax2.set_ylabel('Loss', fontsize=11)
    ax2.set_title('Training History with Best Epoch', fontsize=13, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)
    
    # Remaining rows: Test predictions for each output (LINE PLOTS)
    n_samples = min(1000, len(y_test_true))
    
    for i in range(n_outputs):
        ax = plt.subplot(2 + n_outputs, 1, 3 + i)
        
        # LINE PLOTS
        ax.plot(y_test_true[:n_samples, i], 
                label='Actual', 
                linewidth=1.5, 
                alpha=0.8,
                color='blue')
        ax.plot(y_test_pred[:n_samples, i], 
                label='Predicted', 
                linewidth=1.5, 
                alpha=0.8,
                color='red')
        
        r2 = metrics['test']['r2'][i]
        rmse = metrics['test']['rmse'][i]
        
        ax.set_title(f'Output {i+1} - Test Predictions (R²={r2:.3f}, RMSE={rmse:.3f})',
                    fontsize=12, fontweight='bold')
        ax.set_xlabel('Sample Index', fontsize=10)
        ax.set_ylabel('Temperature', fontsize=10)
        ax.legend(fontsize=9, loc='upper right')
        ax.grid(True, alpha=0.3)
    
    # Overall title
    fig.suptitle(f'{config.EXPERIMENT_NAME}\n' +
                f'Train R²={metrics["train"]["r2_avg"]:.3f} | ' +
                f'Test R²={metrics["test"]["r2_avg"]:.3f} | ' +
                f'Gap={metrics["gap"]:.3f}',
                fontsize=14, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 1, 0.99])
    
    # Save
    plot_path = os.path.join(config.OUTPUT_FOLDER, f'{config.EXPERIMENT_NAME}_results.png')
    plt.savefig(plot_path, dpi=150, bbox_inches='tight')
    print(f"✓ Plot saved: {plot_path}")
    plt.close()


def save_model_and_scalers(model, scaler_X, scaler_y, config):
    """Save PyTorch model (.pth) and scalers (.pkl)"""
    # Save model
    model_path = os.path.join(config.OUTPUT_FOLDER, f'{config.EXPERIMENT_NAME}_model.pth')
    torch.save({
        'model_state_dict': model.state_dict(),
        'config': {
            'input_size': model.lstm.input_size,
            'hidden_size': model.hidden_size,
            'num_layers': model.num_layers,
            'output_size': model.fc.out_features,
            'dropout': config.DROPOUT,
            'bidirectional': config.BIDIRECTIONAL
        }
    }, model_path)
    print(f"✓ Model saved: {model_path}")
    
    # Save scalers
    scaler_X_path = os.path.join(config.OUTPUT_FOLDER, f'{config.EXPERIMENT_NAME}_scaler_X.pkl')
    scaler_y_path = os.path.join(config.OUTPUT_FOLDER, f'{config.EXPERIMENT_NAME}_scaler_y.pkl')
    
    with open(scaler_X_path, 'wb') as f:
        pickle.dump(scaler_X, f)
    print(f"✓ Input scaler saved: {scaler_X_path}")
    
    with open(scaler_y_path, 'wb') as f:
        pickle.dump(scaler_y, f)
    print(f"✓ Output scaler saved: {scaler_y_path}")


def save_metrics(metrics, config):
    """Save metrics to JSON"""
    results = {
        'experiment': config.EXPERIMENT_NAME,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'config': {
            'window_size': config.WINDOW_SIZE,
            'hidden_size': config.HIDDEN_SIZE,
            'num_layers': config.NUM_LAYERS,
            'dropout': config.DROPOUT,
            'bidirectional': config.BIDIRECTIONAL,
            'learning_rate': config.LEARNING_RATE,
            'batch_size': config.BATCH_SIZE,
        },
        'metrics': {
            'train_r2_avg': float(metrics['train']['r2_avg']),
            'test_r2_avg': float(metrics['test']['r2_avg']),
            'gap': float(metrics['gap']),
            'train_r2_per_output': [float(x) for x in metrics['train']['r2']],
            'test_r2_per_output': [float(x) for x in metrics['test']['r2']],
            'train_rmse': [float(x) for x in metrics['train']['rmse']],
            'test_rmse': [float(x) for x in metrics['test']['rmse']],
            'train_mae': [float(x) for x in metrics['train']['mae']],
            'test_mae': [float(x) for x in metrics['test']['mae']]
        }
    }
    
    metrics_path = os.path.join(config.OUTPUT_FOLDER, f'{config.EXPERIMENT_NAME}_metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(results, f, indent=4)
    print(f"✓ Metrics saved: {metrics_path}")


def print_results(metrics):
    """Print results to console"""
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    
    print(f"\n📊 Overall Metrics:")
    print(f"  Train R² (avg): {metrics['train']['r2_avg']:.4f}")
    print(f"  Test R² (avg):  {metrics['test']['r2_avg']:.4f}")
    print(f"  Gap:            {metrics['gap']:.4f}")
    
    print(f"\n📈 Per-Output Test Performance:")
    for i in range(len(metrics['test']['r2'])):
        print(f"  Output {i+1}: R²={metrics['test']['r2'][i]:.4f}, " +
              f"RMSE={metrics['test']['rmse'][i]:.4f}, " +
              f"MAE={metrics['test']['mae'][i]:.4f}")
    
    # Diagnosis
    print(f"\n🔍 Diagnosis:")
    if metrics['test']['r2_avg'] < 0:
        print("  ❌ CRITICAL: Negative test R²!")
        print("     → Try smaller window size (10, 20)")
        print("     → Use simpler model (hidden_size=16, num_layers=1)")
        print("     → Check data preprocessing")
    elif metrics['gap'] > 0.2:
        print("  ⚠️  WARNING: Overfitting (large train-test gap)")
        print("     → Increase dropout")
        print("     → Reduce model complexity")
    elif metrics['test']['r2_avg'] > 0.7:
        print("  ✅ EXCELLENT: Good test performance!")
    elif metrics['test']['r2_avg'] > 0.5:
        print("  ✓  GOOD: Reasonable performance")


# ============================================================================
# MAIN TRAINING FUNCTION
# ============================================================================

def train_model(train_data, test_data, train_sortie_lengths, test_sortie_lengths, config):
    """
    Main training function
    
    Parameters:
    -----------
    train_data : DataFrame
        Combined training data (s1 + s2 + s3)
    test_data : DataFrame
        Test data (single sortie)
    train_sortie_lengths : list of int
        [len(s1), len(s2), len(s3)]
    test_sortie_lengths : list of int
        [len(test_sortie)]
    config : Config object
    """
    
    print("\n" + "="*80)
    print(f"TRAINING: {config.EXPERIMENT_NAME}")
    print("="*80)
    
    create_output_folder(config.OUTPUT_FOLDER)
    
    # ========================================================================
    # STEP 1: PREPARE DATA
    # ========================================================================
    
    print("\n📊 Step 1: Preparing data...")
    
    X_train = train_data[config.INPUT_COLUMNS].values
    y_train = train_data[config.OUTPUT_COLUMNS].values
    
    X_test = test_data[config.INPUT_COLUMNS].values
    y_test = test_data[config.OUTPUT_COLUMNS].values
    
    print(f"  X_train shape: {X_train.shape}")
    print(f"  y_train shape: {y_train.shape}")
    print(f"  X_test shape: {X_test.shape}")
    print(f"  y_test shape: {y_test.shape}")
    
    # ========================================================================
    # STEP 2: SCALE DATA
    # ========================================================================
    
    print("\n📏 Step 2: Scaling data...")
    
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)
    
    X_test_scaled = scaler_X.transform(X_test)
    y_test_scaled = scaler_y.transform(y_test)
    
    print(f"  X_train_scaled mean: {X_train_scaled.mean():.4f} (should be ≈ 0)")
    print(f"  X_train_scaled std: {X_train_scaled.std():.4f} (should be ≈ 1)")
    
    # ========================================================================
    # STEP 3: CREATE SEQUENCES
    # ========================================================================
    
    print(f"\n🔢 Step 3: Creating sequences (window={config.WINDOW_SIZE})...")
    
    X_train_seq, y_train_seq = create_sequences(
        X_train_scaled, y_train_scaled, train_sortie_lengths, config.WINDOW_SIZE
    )
    
    X_test_seq, y_test_seq = create_sequences(
        X_test_scaled, y_test_scaled, test_sortie_lengths, config.WINDOW_SIZE
    )
    
    print(f"  X_train_seq shape: {X_train_seq.shape}")
    print(f"  X_test_seq shape: {X_test_seq.shape}")
    
    # ========================================================================
    # STEP 4: CREATE DATALOADERS
    # ========================================================================
    
    print(f"\n📦 Step 4: Creating dataloaders...")
    
    # Split train into train/val (80/20)
    val_size = int(0.2 * len(X_train_seq))
    train_size = len(X_train_seq) - val_size
    
    indices = np.random.permutation(len(X_train_seq))
    train_indices = indices[:train_size]
    val_indices = indices[train_size:]
    
    train_dataset = TimeSeriesDataset(X_train_seq[train_indices], y_train_seq[train_indices])
    val_dataset = TimeSeriesDataset(X_train_seq[val_indices], y_train_seq[val_indices])
    test_dataset = TimeSeriesDataset(X_test_seq, y_test_seq)
    
    # Full train dataset for final evaluation
    full_train_dataset = TimeSeriesDataset(X_train_seq, y_train_seq)
    
    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=config.BATCH_SIZE, shuffle=False)
    full_train_loader = DataLoader(full_train_dataset, batch_size=config.BATCH_SIZE, shuffle=False)
    
    print(f"  Train samples: {len(train_dataset)}")
    print(f"  Val samples: {len(val_dataset)}")
    print(f"  Test samples: {len(test_dataset)}")
    
    # ========================================================================
    # STEP 5: BUILD MODEL
    # ========================================================================
    
    print(f"\n🏗️  Step 5: Building model...")
    
    input_size = X_train_seq.shape[2]
    output_size = y_train_seq.shape[1]
    
    model = LSTMModel(
        input_size=input_size,
        hidden_size=config.HIDDEN_SIZE,
        num_layers=config.NUM_LAYERS,
        output_size=output_size,
        dropout=config.DROPOUT,
        bidirectional=config.BIDIRECTIONAL
    ).to(device)
    
    print(f"\n  Model Architecture:")
    print(f"    Input size: {input_size}")
    print(f"    Hidden size: {config.HIDDEN_SIZE}")
    print(f"    Num layers: {config.NUM_LAYERS}")
    print(f"    Output size: {output_size}")
    print(f"    Dropout: {config.DROPOUT}")
    print(f"    Bidirectional: {config.BIDIRECTIONAL}")
    print(f"    Total parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # ========================================================================
    # STEP 6: TRAIN MODEL
    # ========================================================================
    
    print(f"\n🚀 Step 6: Training model...")
    
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=config.LEARNING_RATE)
    
    history = {
        'train_loss': [],
        'val_loss': []
    }
    
    best_val_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(config.EPOCHS):
        # Train
        train_loss = train_epoch(model, train_loader, criterion, optimizer, device)
        
        # Validate
        val_loss = validate(model, val_loader, criterion, device)
        
        # Save history
        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        
        # Print progress
        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f"  Epoch [{epoch+1}/{config.EPOCHS}] - "
                  f"Train Loss: {train_loss:.6f}, Val Loss: {val_loss:.6f}")
        
        # Early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            # Save best model
            best_model_state = model.state_dict()
        else:
            patience_counter += 1
        
        if patience_counter >= config.PATIENCE:
            print(f"\n  Early stopping at epoch {epoch+1}")
            break
    
    # Load best model
    model.load_state_dict(best_model_state)
    print(f"\n  Training complete! Best val loss: {best_val_loss:.6f}")
    
    # ========================================================================
    # STEP 7: EVALUATE
    # ========================================================================
    
    print(f"\n📊 Step 7: Evaluating...")
    
    metrics, y_train_pred, y_test_pred, y_train_true, y_test_true = evaluate_model(
        model, full_train_loader, test_loader, scaler_y, device
    )
    
    print_results(metrics)
    
    # ========================================================================
    # STEP 8: SAVE EVERYTHING
    # ========================================================================
    
    print(f"\n💾 Step 8: Saving results...")
    
    save_model_and_scalers(model, scaler_X, scaler_y, config)
    save_metrics(metrics, config)
    plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred,
                 metrics, config)
    
    print("\n" + "="*80)
    print("✅ TRAINING COMPLETE!")
    print("="*80)
    
    return model, scaler_X, scaler_y, metrics, history


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    
    print("""
    ╔════════════════════════════════════════════════════════════════════════╗
    ║                PYTORCH LSTM TRAINER - MANUAL EXPERIMENTS               ║
    ╚════════════════════════════════════════════════════════════════════════╝
    
    HOW TO USE:
    
    1. Load your data:
       s1 = pd.read_csv('sortie1.csv')
       s2 = pd.read_csv('sortie2.csv')
       s3 = pd.read_csv('sortie3.csv')
       test = pd.read_csv('test_sortie.csv')
       
       train_data = pd.concat([s1, s2, s3], ignore_index=True)
       test_data = test
       
       train_sortie_lengths = [len(s1), len(s2), len(s3)]
       test_sortie_lengths = [len(test)]
    
    2. Modify Config class (top of file) to match your column names
    
    3. Run training:
       config = Config()
       model, scaler_X, scaler_y, metrics, history = train_model(
           train_data, test_data,
           train_sortie_lengths, test_sortie_lengths,
           config
       )
    
    4. Check ./outputs/ folder for results
    
    5. To run another experiment, modify Config and run again
    """)
