"""
Prediction Script

Make predictions on new aircraft data using the trained LSTM model.

Usage:
    python predict.py --input data/new_sortie.csv --output predictions.csv
"""

import argparse
import torch
import pickle
import numpy as np
import pandas as pd
from pathlib import Path
import sys

from config import *
from model import TemperatureLSTM
from data_preparation import create_sequences

def load_trained_model(model_path: str, device: str):
    """
    Load trained model weights.
    
    Parameters
    ----------
    model_path : str
        Path to saved model.pt file
    device : str
        Device to use
        
    Returns
    -------
    TemperatureLSTM
        Loaded model
    """
    # Load model state (we need to recreate model architecture first)
    model_state = torch.load(model_path, map_location=device)
    
    # The model state dict contains architecture info implicitly
    # We need to know the input size
    # For now, we'll infer it from the first weight matrix
    
    # Try to load from config
    try:
        model = TemperatureLSTM(
            input_size=HIDDEN_DIM_1,  # Will be overridden
            hidden_dim_1=HIDDEN_DIM_1,
            hidden_dim_2=HIDDEN_DIM_2,
            dense_dim_1=DENSE_DIM_1,
            dense_dim_2=DENSE_DIM_2,
            output_size=5,
            device=device
        )
    except:
        raise RuntimeError("Could not recreate model architecture. Check config.py")
    
    model.load_state_dict(model_state)
    model.eval()
    
    return model

def predict_on_data(
    model: torch.nn.Module,
    X: np.ndarray,
    scaler_X,
    scaler_y,
    lookback: int = 30,
    batch_size: int = 128,
    device: str = 'cpu'
) -> np.ndarray:
    """
    Make predictions on new data.
    
    Parameters
    ----------
    model : torch.nn.Module
        Trained LSTM model
    X : np.ndarray
        Input sensor data (n_samples, n_features)
    scaler_X : StandardScaler
        Input data scaler
    scaler_y : StandardScaler
        Output data scaler
    lookback : int
        Lookback window
    batch_size : int
        Batch size for inference
    device : str
        Device to use
        
    Returns
    -------
    np.ndarray
        Predictions in original scale (n_sequences, 5)
    """
    # Scale input
    X_scaled = scaler_X.transform(X)
    
    # Create sequences
    X_seq = []
    for i in range(len(X_scaled) - lookback + 1):
        X_seq.append(X_scaled[i:i+lookback])
    
    X_seq = np.array(X_seq)
    
    # Convert to tensor
    X_tensor = torch.from_numpy(X_seq).float().to(device)
    
    # Make predictions
    all_predictions = []
    
    with torch.no_grad():
        for i in range(0, len(X_tensor), batch_size):
            batch = X_tensor[i:i+batch_size]
            pred_batch = model(batch)
            all_predictions.append(pred_batch.cpu().numpy())
    
    predictions_scaled = np.concatenate(all_predictions, axis=0)
    
    # Inverse scale
    predictions = scaler_y.inverse_transform(predictions_scaled)
    
    return predictions

def main():
    """Main prediction pipeline."""
    
    parser = argparse.ArgumentParser(
        description='Make temperature predictions on new aircraft data'
    )
    parser.add_argument('--input', type=str, required=True,
                        help='Path to input CSV file with FDR sensor data')
    parser.add_argument('--output', type=str, default='predictions.csv',
                        help='Path to save predictions (default: predictions.csv)')
    parser.add_argument('--model', type=str, default=MODEL_PATH,
                        help=f'Path to trained model (default: {MODEL_PATH})')
    parser.add_argument('--scaler-x', type=str, default=SCALER_X_PATH,
                        help=f'Path to input scaler (default: {SCALER_X_PATH})')
    parser.add_argument('--scaler-y', type=str, default=SCALER_Y_PATH,
                        help=f'Path to output scaler (default: {SCALER_Y_PATH})')
    
    args = parser.parse_args()
    
    # ============================================================
    # STEP 1: VALIDATE INPUT FILES
    # ============================================================
    
    print("\n" + "=" * 70)
    print("AIRCRAFT TEMPERATURE PREDICTION - INFERENCE")
    print("=" * 70)
    
    print("\n[Step 1] Validating input files...")
    
    if not Path(args.input).exists():
        print(f"✗ Input file not found: {args.input}")
        sys.exit(1)
    print(f"✓ Input file: {args.input}")
    
    if not Path(args.model).exists():
        print(f"✗ Model file not found: {args.model}")
        sys.exit(1)
    print(f"✓ Model file: {args.model}")
    
    if not Path(args.scaler_x).exists():
        print(f"✗ Input scaler not found: {args.scaler_x}")
        sys.exit(1)
    print(f"✓ Input scaler: {args.scaler_x}")
    
    if not Path(args.scaler_y).exists():
        print(f"✗ Output scaler not found: {args.scaler_y}")
        sys.exit(1)
    print(f"✓ Output scaler: {args.scaler_y}")
    
    # ============================================================
    # STEP 2: LOAD DATA AND SCALERS
    # ============================================================
    
    print("\n[Step 2] Loading data and scalers...")
    
    # Load data
    df = pd.read_csv(args.input)
    print(f"✓ Loaded data: {df.shape[0]} samples, {df.shape[1]} columns")
    
    # Extract features (all except temps and timestamp)
    temp_columns = ['temperature_1', 'temperature_2', 'temperature_3',
                   'temperature_4', 'temperature_5']
    fdr_columns = [col for col in df.columns 
                   if col not in temp_columns + ['timestamp']]
    
    X = df[fdr_columns].values
    print(f"✓ Extracted {len(fdr_columns)} FDR sensor features")
    
    # Load scalers
    with open(args.scaler_x, 'rb') as f:
        scaler_X = pickle.load(f)
    print(f"✓ Loaded input scaler")
    
    with open(args.scaler_y, 'rb') as f:
        scaler_y = pickle.load(f)
    print(f"✓ Loaded output scaler")
    
    # ============================================================
    # STEP 3: LOAD MODEL
    # ============================================================
    
    print("\n[Step 3] Loading trained model...")
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"  Using device: {device}")
    
    model = TemperatureLSTM(
        input_size=len(fdr_columns),
        hidden_dim_1=HIDDEN_DIM_1,
        hidden_dim_2=HIDDEN_DIM_2,
        dense_dim_1=DENSE_DIM_1,
        dense_dim_2=DENSE_DIM_2,
        output_size=5,
        device=device
    )
    
    model.load_state_dict(torch.load(args.model, map_location=device))
    model.eval()
    print(f"✓ Model loaded: {args.model}")
    
    # ============================================================
    # STEP 4: MAKE PREDICTIONS
    # ============================================================
    
    print("\n[Step 4] Making predictions...")
    
    predictions = predict_on_data(
        model=model,
        X=X,
        scaler_X=scaler_X,
        scaler_y=scaler_y,
        lookback=LOOKBACK,
        batch_size=PREDICTION_BATCH_SIZE,
        device=device
    )
    
    print(f"✓ Predictions shape: {predictions.shape}")
    print(f"  ({predictions.shape[0]} sequences, {predictions.shape[1]} temperatures)")
    
    # ============================================================
    # STEP 5: SAVE PREDICTIONS
    # ============================================================
    
    print("\n[Step 5] Saving predictions...")
    
    # Create dataframe
    pred_df = pd.DataFrame(
        predictions,
        columns=['temperature_1', 'temperature_2', 'temperature_3',
                'temperature_4', 'temperature_5']
    )
    
    # Save
    pred_df.to_csv(args.output, index=False)
    print(f"✓ Predictions saved: {args.output}")
    
    # ============================================================
    # SUMMARY
    # ============================================================
    
    print("\n" + "=" * 70)
    print("PREDICTION SUMMARY")
    print("=" * 70)
    
    print(f"\nInput Information:")
    print(f"  File: {args.input}")
    print(f"  Total samples: {len(df)}")
    print(f"  FDR features: {len(fdr_columns)}")
    
    print(f"\nModel Information:")
    print(f"  Architecture: Bidirectional LSTM")
    print(f"  Device: {device}")
    
    print(f"\nPrediction Results:")
    print(f"  Total sequences: {len(predictions)}")
    print(f"  Predictions per sequence: 5 (temperatures)")
    print(f"  Output file: {args.output}")
    
    print(f"\nTemperature Ranges (Predictions):")
    for i in range(5):
        pred_min = predictions[:, i].min()
        pred_max = predictions[:, i].max()
        pred_mean = predictions[:, i].mean()
        print(f"  Temperature {i+1}: {pred_min:.2f}°C - {pred_max:.2f}°C (mean: {pred_mean:.2f}°C)")
    
    print("\n" + "=" * 70)
    print("✓ PREDICTION COMPLETE!")
    print("=" * 70)

if __name__ == '__main__':
    main()
