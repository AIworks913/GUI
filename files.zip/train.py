"""
Main Training Script for Aircraft Temperature Prediction

This is the main entry point. Run this script to train the LSTM model.

Usage:
    python train.py
"""

import os
import sys
import torch
import torch.nn as nn
import torch.utils.data as data
import numpy as np
import pickle
import json
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import datetime

# Import custom modules
from config import *
from data_preparation import prepare_data
from model import TemperatureLSTM
from trainer import Trainer, evaluate_model

def set_seed(seed: int = 42):
    """Set random seed for reproducibility."""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

def create_data_loaders(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    batch_size: int,
    validation_split: float = 0.1,
    verbose: bool = True
) -> tuple:
    """
    Create PyTorch data loaders.
    
    Parameters
    ----------
    X_train, y_train : np.ndarray
        Training data
    X_test, y_test : np.ndarray
        Test data
    batch_size : int
        Batch size for training
    validation_split : float
        Fraction of training data to use for validation
    verbose : bool
        Whether to print information
        
    Returns
    -------
    tuple
        (train_loader, val_loader, test_loader)
    """
    if verbose:
        print("\n" + "=" * 70)
        print("CREATING DATA LOADERS")
        print("=" * 70)
    
    # Convert to torch tensors
    X_train_tensor = torch.from_numpy(X_train).float()
    y_train_tensor = torch.from_numpy(y_train).float()
    X_test_tensor = torch.from_numpy(X_test).float()
    y_test_tensor = torch.from_numpy(y_test).float()
    
    # Split training into train and validation
    n_train = len(X_train_tensor)
    val_size = int(n_train * validation_split)
    train_size = n_train - val_size
    
    train_dataset, val_dataset = data.random_split(
        data.TensorDataset(X_train_tensor, y_train_tensor),
        [train_size, val_size]
    )
    
    test_dataset = data.TensorDataset(X_test_tensor, y_test_tensor)
    
    # Create loaders
    train_loader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    if verbose:
        print(f"\nTraining set: {train_size} samples")
        print(f"Validation set: {val_size} samples")
        print(f"Test set: {len(test_dataset)} samples")
        print(f"Batch size: {batch_size}")
        print(f"Training batches: {len(train_loader)}")
        print(f"Validation batches: {len(val_loader)}")
        print(f"Test batches: {len(test_loader)}")
    
    return train_loader, val_loader, test_loader

def plot_training_history(history: dict, save_path: str = None):
    """
    Plot training and validation losses.
    
    Parameters
    ----------
    history : dict
        Training history from trainer
    save_path : str
        Path to save the plot (optional)
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Loss plot
    axes[0].plot(history['epoch'], history['train_loss'], label='Training Loss', linewidth=2)
    axes[0].plot(history['epoch'], history['val_loss'], label='Validation Loss', linewidth=2)
    axes[0].set_xlabel('Epoch', fontsize=12)
    axes[0].set_ylabel('Loss (MSE)', fontsize=12)
    axes[0].set_title('Model Loss During Training', fontsize=14, fontweight='bold')
    axes[0].legend(fontsize=11)
    axes[0].grid(True, alpha=0.3)
    
    # MAE plot
    axes[1].plot(history['epoch'], history['train_mae'], label='Training MAE', linewidth=2)
    axes[1].plot(history['epoch'], history['val_mae'], label='Validation MAE', linewidth=2)
    axes[1].set_xlabel('Epoch', fontsize=12)
    axes[1].set_ylabel('MAE (°C)', fontsize=12)
    axes[1].set_title('Model MAE During Training', fontsize=14, fontweight='bold')
    axes[1].legend(fontsize=11)
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Training curves saved: {save_path}")
    
    plt.show()

def save_predictions(predictions: np.ndarray, targets: np.ndarray, 
                     save_path: str = None):
    """
    Save predictions and targets to CSV.
    
    Parameters
    ----------
    predictions : np.ndarray
        Model predictions
    targets : np.ndarray
        Actual targets
    save_path : str
        Path to save CSV
    """
    import pandas as pd
    
    # Calculate errors
    errors = np.abs(predictions - targets)
    mae_per_sample = np.mean(errors, axis=1)
    
    # Create dataframe
    data_dict = {}
    
    for i in range(targets.shape[1]):
        data_dict[f'actual_temp_{i+1}'] = targets[:, i]
        data_dict[f'pred_temp_{i+1}'] = predictions[:, i]
    
    data_dict['mae'] = mae_per_sample
    
    df = pd.DataFrame(data_dict)
    
    if save_path:
        df.to_csv(save_path, index=False)
        print(f"✓ Predictions saved: {save_path}")
    
    return df

def main():
    """Main training pipeline."""
    
    print("\n" + "=" * 70)
    print("AIRCRAFT TEMPERATURE PREDICTION - LSTM MODEL")
    print("=" * 70)
    
    # Set seed for reproducibility
    set_seed(RANDOM_SEED)
    
    # Create output directory
    Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
    
    # ============================================================
    # STEP 1: LOAD AND PREPARE DATA
    # ============================================================
    
    print("\n[Step 1] Loading and preparing data...")
    
    data_dict = prepare_data(
        training_files=TRAINING_SORTIES,
        testing_files=TESTING_SORTIES,
        temperature_columns=TEMPERATURE_COLUMNS,
        lookback=LOOKBACK,
        forecast_horizon=FORECAST_HORIZON,
        verbose=VERBOSE
    )
    
    X_train = data_dict['X_train']
    y_train = data_dict['y_train']
    X_test = data_dict['X_test']
    y_test = data_dict['y_test']
    scaler_X = data_dict['scaler_X']
    scaler_y = data_dict['scaler_y']
    n_features = data_dict['n_features']
    n_outputs = data_dict['n_outputs']
    
    # ============================================================
    # STEP 2: CREATE DATA LOADERS
    # ============================================================
    
    print("\n[Step 2] Creating data loaders...")
    
    train_loader, val_loader, test_loader = create_data_loaders(
        X_train, y_train, X_test, y_test,
        batch_size=BATCH_SIZE,
        validation_split=VALIDATION_SPLIT,
        verbose=VERBOSE
    )
    
    # ============================================================
    # STEP 3: BUILD MODEL
    # ============================================================
    
    print("\n[Step 3] Building LSTM model...")
    
    model = TemperatureLSTM(
        input_size=n_features,
        hidden_dim_1=HIDDEN_DIM_1,
        hidden_dim_2=HIDDEN_DIM_2,
        dense_dim_1=DENSE_DIM_1,
        dense_dim_2=DENSE_DIM_2,
        output_size=n_outputs,
        dropout_rate_1=DROPOUT_RATE_1,
        dropout_rate_2=DROPOUT_RATE_2,
        l2_lambda=L2_REGULARIZATION,
        device=DEVICE
    )
    
    param_count = model.count_parameters()
    model_size = model.get_model_size_mb()
    
    if VERBOSE:
        print(f"\nModel Statistics:")
        print(f"  Total Parameters: {param_count['total']:,}")
        print(f"  Trainable Parameters: {param_count['trainable']:,}")
        print(f"  Model Size: {model_size:.2f} MB")
        print(f"  Device: {DEVICE}")
    
    # ============================================================
    # STEP 4: SETUP TRAINING
    # ============================================================
    
    print("\n[Step 4] Setting up training...")
    
    # Optimizer with L2 regularization (weight decay)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=L2_REGULARIZATION
    )
    
    # Loss function
    criterion = nn.MSELoss()
    
    # Trainer
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        criterion=criterion,
        device=DEVICE,
        patience=PATIENCE,
        lr_factor=LR_FACTOR,
        min_lr=MIN_LR,
        verbose=VERBOSE
    )
    
    if VERBOSE:
        print(f"  Optimizer: Adam (lr={LEARNING_RATE})")
        print(f"  Loss Function: MSE")
        print(f"  Early Stopping Patience: {PATIENCE} epochs")
        print(f"  LR Scheduler: ReduceLROnPlateau (factor={LR_FACTOR}, patience={LR_PATIENCE})")
    
    # ============================================================
    # STEP 5: TRAIN MODEL
    # ============================================================
    
    print("\n[Step 5] Training model...")
    
    history = trainer.fit(
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=NUM_EPOCHS,
        print_every=PRINT_EVERY
    )
    
    # ============================================================
    # STEP 6: EVALUATE ON TEST SET
    # ============================================================
    
    print("\n[Step 6] Evaluating on test set...")
    
    eval_results = evaluate_model(
        model=model,
        test_loader=test_loader,
        device=DEVICE,
        scaler_y=scaler_y,
        verbose=VERBOSE
    )
    
    # ============================================================
    # STEP 7: SAVE MODEL AND RESULTS
    # ============================================================
    
    print("\n[Step 7] Saving model and results...")
    
    # Save model
    torch.save(model.state_dict(), MODEL_PATH)
    print(f"✓ Model saved: {MODEL_PATH}")
    
    # Save scalers
    with open(SCALER_X_PATH, 'wb') as f:
        pickle.dump(scaler_X, f)
    print(f"✓ Input scaler saved: {SCALER_X_PATH}")
    
    with open(SCALER_Y_PATH, 'wb') as f:
        pickle.dump(scaler_y, f)
    print(f"✓ Output scaler saved: {SCALER_Y_PATH}")
    
    # Save training history
    trainer.save_history(HISTORY_PATH)
    
    # Save predictions
    save_predictions(eval_results['predictions'], eval_results['targets'], 
                     save_path=PREDICTIONS_PATH)
    
    # ============================================================
    # STEP 8: VISUALIZATION
    # ============================================================
    
    if SAVE_PLOTS:
        print("\n[Step 8] Generating visualizations...")
        plot_training_history(history, save_path=PLOT_PATH)
    
    # ============================================================
    # SUMMARY
    # ============================================================
    
    print("\n" + "=" * 70)
    print("TRAINING SUMMARY")
    print("=" * 70)
    
    print(f"\nModel Information:")
    print(f"  Architecture: Bidirectional LSTM")
    print(f"  Total Parameters: {param_count['total']:,}")
    print(f"  Model Size: {model_size:.2f} MB")
    
    print(f"\nTraining Information:")
    print(f"  Training Epochs: {len(history['epoch'])}")
    print(f"  Best Epoch: {trainer.best_epoch}")
    print(f"  Best Validation Loss: {trainer.best_val_loss:.6f}")
    
    print(f"\nTest Set Performance:")
    print(f"  MSE: {eval_results['mse']:.6f}")
    print(f"  RMSE: {eval_results['rmse']:.6f}°C")
    print(f"  MAE: {eval_results['mae']:.6f}°C")
    
    print(f"\nOutput Files:")
    print(f"  Model: {MODEL_PATH}")
    print(f"  Input Scaler: {SCALER_X_PATH}")
    print(f"  Output Scaler: {SCALER_Y_PATH}")
    print(f"  Training History: {HISTORY_PATH}")
    if SAVE_PLOTS:
        print(f"  Training Plot: {PLOT_PATH}")
    print(f"  Predictions: {PREDICTIONS_PATH}")
    
    print("\n" + "=" * 70)
    print("✓ TRAINING COMPLETE!")
    print("=" * 70)
    
    # ============================================================
    # NEXT STEPS
    # ============================================================
    
    print(f"\nNext Steps:")
    print(f"  1. Check outputs/ directory for results")
    print(f"  2. Review training_curves.png for convergence")
    print(f"  3. Check predictions.csv for test predictions")
    print(f"  4. To make predictions on new data:")
    print(f"     python predict.py --input data/new_sortie.csv")

if __name__ == '__main__':
    main()
