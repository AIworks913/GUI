"""
Trainer Module

Handles training loop, validation, and utilities for model training.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Tuple, List
import json
from pathlib import Path
from datetime import datetime

class EarlyStopping:
    """Early stopping to prevent overfitting."""
    
    def __init__(self, patience: int = 25, min_delta: float = 1e-4, verbose: bool = True):
        """
        Parameters
        ----------
        patience : int
            Number of epochs to wait for improvement
        min_delta : float
            Minimum change in loss to qualify as improvement
        verbose : bool
            Whether to print messages
        """
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        self.verbose = verbose
    
    def __call__(self, val_loss: float) -> bool:
        """
        Check if should stop training.
        
        Returns
        -------
        bool
            True if should stop training
        """
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.verbose and self.counter == 1:
                print(f"    EarlyStopping counter: {self.counter}/{self.patience}")
            elif self.verbose and self.counter % 5 == 0:
                print(f"    EarlyStopping counter: {self.counter}/{self.patience}")
            
            if self.counter >= self.patience:
                self.early_stop = True
                if self.verbose:
                    print(f"    Early stopping triggered at counter {self.counter}")
                return True
        
        return False


class LearningRateScheduler:
    """Learning rate scheduler with plateau reduction."""
    
    def __init__(self, optimizer: torch.optim.Optimizer, factor: float = 0.5, 
                 patience: int = 10, min_lr: float = 1e-6, verbose: bool = True):
        """
        Parameters
        ----------
        optimizer : torch.optim.Optimizer
            PyTorch optimizer
        factor : float
            Factor to multiply learning rate by
        patience : int
            Number of epochs to wait before reducing LR
        min_lr : float
            Minimum learning rate
        verbose : bool
            Whether to print messages
        """
        self.optimizer = optimizer
        self.factor = factor
        self.patience = patience
        self.min_lr = min_lr
        self.counter = 0
        self.best_loss = None
        self.verbose = verbose
    
    def step(self, val_loss: float):
        """Update learning rate if needed."""
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self._reduce_lr()
                self.counter = 0
    
    def _reduce_lr(self):
        """Reduce learning rate."""
        for param_group in self.optimizer.param_groups:
            old_lr = param_group['lr']
            new_lr = max(old_lr * self.factor, self.min_lr)
            param_group['lr'] = new_lr
            if self.verbose:
                print(f"    Reducing learning rate: {old_lr:.6f} → {new_lr:.6f}")


class Trainer:
    """Main trainer class for model training."""
    
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        criterion: nn.Module,
        device: str,
        patience: int = 25,
        lr_factor: float = 0.5,
        min_lr: float = 1e-6,
        verbose: bool = True
    ):
        """
        Initialize trainer.
        
        Parameters
        ----------
        model : nn.Module
            PyTorch model to train
        optimizer : torch.optim.Optimizer
            Optimizer for gradient descent
        criterion : nn.Module
            Loss function
        device : str
            Device to use ('cpu' or 'cuda')
        patience : int
            Early stopping patience
        lr_factor : float
            LR reduction factor
        min_lr : float
            Minimum learning rate
        verbose : bool
            Whether to print progress
        """
        self.model = model
        self.optimizer = optimizer
        self.criterion = criterion
        self.device = device
        self.verbose = verbose
        
        self.early_stopping = EarlyStopping(patience=patience, verbose=verbose)
        self.lr_scheduler = LearningRateScheduler(
            optimizer, factor=lr_factor, patience=10, min_lr=min_lr, verbose=verbose)
        
        # Training history
        self.history = {
            'epoch': [],
            'train_loss': [],
            'val_loss': [],
            'train_mae': [],
            'val_mae': [],
            'learning_rate': []
        }
        
        self.best_val_loss = float('inf')
        self.best_epoch = 0
    
    def train_epoch(
        self,
        train_loader: torch.utils.data.DataLoader
    ) -> Tuple[float, float]:
        """
        Train for one epoch.
        
        Returns
        -------
        Tuple[float, float]
            (average_loss, average_mae)
        """
        self.model.train()
        
        total_loss = 0.0
        total_mae = 0.0
        num_batches = 0
        
        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(self.device)
            y_batch = y_batch.to(self.device)
            
            # Forward pass
            predictions = self.model(X_batch)
            loss = self.criterion(predictions, y_batch)
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            # Metrics
            mae = torch.mean(torch.abs(predictions - y_batch))
            
            total_loss += loss.item()
            total_mae += mae.item()
            num_batches += 1
        
        avg_loss = total_loss / num_batches
        avg_mae = total_mae / num_batches
        
        return avg_loss, avg_mae
    
    def validate(
        self,
        val_loader: torch.utils.data.DataLoader
    ) -> Tuple[float, float]:
        """
        Validate on validation set.
        
        Returns
        -------
        Tuple[float, float]
            (average_loss, average_mae)
        """
        self.model.eval()
        
        total_loss = 0.0
        total_mae = 0.0
        num_batches = 0
        
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch = X_batch.to(self.device)
                y_batch = y_batch.to(self.device)
                
                # Forward pass
                predictions = self.model(X_batch)
                loss = self.criterion(predictions, y_batch)
                
                # Metrics
                mae = torch.mean(torch.abs(predictions - y_batch))
                
                total_loss += loss.item()
                total_mae += mae.item()
                num_batches += 1
        
        avg_loss = total_loss / num_batches
        avg_mae = total_mae / num_batches
        
        return avg_loss, avg_mae
    
    def fit(
        self,
        train_loader: torch.utils.data.DataLoader,
        val_loader: torch.utils.data.DataLoader,
        num_epochs: int = 200,
        print_every: int = 1
    ) -> Dict:
        """
        Train model for multiple epochs.
        
        Parameters
        ----------
        train_loader : DataLoader
            Training data loader
        val_loader : DataLoader
            Validation data loader
        num_epochs : int
            Number of epochs to train
        print_every : int
            Print progress every N epochs
            
        Returns
        -------
        Dict
            Training history
        """
        print("\n" + "=" * 70)
        print("TRAINING MODEL")
        print("=" * 70)
        
        for epoch in range(1, num_epochs + 1):
            # Train
            train_loss, train_mae = self.train_epoch(train_loader)
            
            # Validate
            val_loss, val_mae = self.validate(val_loader)
            
            # Get current learning rate
            current_lr = self.optimizer.param_groups[0]['lr']
            
            # Store history
            self.history['epoch'].append(epoch)
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['train_mae'].append(train_mae)
            self.history['val_mae'].append(val_mae)
            self.history['learning_rate'].append(current_lr)
            
            # Print progress
            if epoch % print_every == 0:
                print(f"Epoch {epoch:3d}/{num_epochs} | "
                      f"Train Loss: {train_loss:.4f} | Train MAE: {train_mae:.4f} | "
                      f"Val Loss: {val_loss:.4f} | Val MAE: {val_mae:.4f} | "
                      f"LR: {current_lr:.6f}")
            
            # Update best model
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.best_epoch = epoch
            
            # Learning rate scheduler
            self.lr_scheduler.step(val_loss)
            
            # Early stopping
            if self.early_stopping(val_loss):
                print(f"\nEarly stopping at epoch {epoch}")
                break
        
        print(f"\n✓ Training complete!")
        print(f"  Best epoch: {self.best_epoch}")
        print(f"  Best validation loss: {self.best_val_loss:.6f}")
        
        return self.history
    
    def get_history(self) -> Dict:
        """Get training history."""
        return self.history
    
    def save_history(self, path: str):
        """Save training history to JSON file."""
        with open(path, 'w') as f:
            json.dump(self.history, f, indent=2)
        print(f"✓ Training history saved: {path}")


def evaluate_model(
    model: nn.Module,
    test_loader: torch.utils.data.DataLoader,
    device: str,
    scaler_y = None,
    verbose: bool = True
) -> Dict:
    """
    Evaluate model on test set.
    
    Parameters
    ----------
    model : nn.Module
        Trained model
    test_loader : DataLoader
        Test data loader
    device : str
        Device to use
    scaler_y : StandardScaler
        Output scaler for inverse transform
    verbose : bool
        Whether to print results
        
    Returns
    -------
    Dict
        Evaluation metrics
    """
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            
            predictions = model(X_batch)
            
            all_predictions.append(predictions.cpu().numpy())
            all_targets.append(y_batch.cpu().numpy())
    
    # Concatenate all batches
    predictions = np.concatenate(all_predictions, axis=0)
    targets = np.concatenate(all_targets, axis=0)
    
    # Inverse transform if scaler provided
    if scaler_y is not None:
        predictions = scaler_y.inverse_transform(predictions)
        targets = scaler_y.inverse_transform(targets)
    
    # Calculate metrics
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - targets))
    
    # Per-temperature metrics
    per_temp_metrics = {}
    for i in range(predictions.shape[1]):
        mse_i = np.mean((predictions[:, i] - targets[:, i]) ** 2)
        rmse_i = np.sqrt(mse_i)
        mae_i = np.mean(np.abs(predictions[:, i] - targets[:, i]))
        
        per_temp_metrics[f'temp_{i+1}'] = {
            'mse': mse_i,
            'rmse': rmse_i,
            'mae': mae_i
        }
    
    results = {
        'mse': mse,
        'rmse': rmse,
        'mae': mae,
        'per_temperature': per_temp_metrics,
        'predictions': predictions,
        'targets': targets
    }
    
    if verbose:
        print("\n" + "=" * 70)
        print("TEST SET EVALUATION")
        print("=" * 70)
        print(f"\nOverall Metrics:")
        print(f"  MSE (Mean Squared Error): {mse:.6f}")
        print(f"  RMSE (Root Mean Squared Error): {rmse:.6f}°C")
        print(f"  MAE (Mean Absolute Error): {mae:.6f}°C")
        
        print(f"\nPer-Temperature Metrics:")
        for i in range(predictions.shape[1]):
            metrics = per_temp_metrics[f'temp_{i+1}']
            print(f"  Temperature {i+1}:")
            print(f"    RMSE: {metrics['rmse']:.6f}°C")
            print(f"    MAE: {metrics['mae']:.6f}°C")
    
    return results


if __name__ == '__main__':
    """Test trainer utilities"""
    import torch.utils.data as data
    
    # Create dummy data
    batch_size = 32
    lookback = 30
    n_features = 15
    n_outputs = 5
    n_batches = 10
    
    X_train = torch.randn(batch_size * n_batches, lookback, n_features)
    y_train = torch.randn(batch_size * n_batches, n_outputs)
    
    X_val = torch.randn(batch_size * 2, lookback, n_features)
    y_val = torch.randn(batch_size * 2, n_outputs)
    
    train_dataset = data.TensorDataset(X_train, y_train)
    val_dataset = data.TensorDataset(X_val, y_val)
    
    train_loader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = data.DataLoader(val_dataset, batch_size=batch_size)
    
    # Create model and trainer
    from model import TemperatureLSTM
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = TemperatureLSTM(input_size=n_features, output_size=n_outputs, device=device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()
    
    trainer = Trainer(model, optimizer, criterion, device=device, patience=5)
    
    # Train
    history = trainer.fit(train_loader, val_loader, num_epochs=10, print_every=1)
    
    print("\n✓ Trainer test passed!")
