"""
Data Preparation Module

Handles loading CSV data, normalization, and sequence creation.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from typing import Tuple, List
import os

def load_sorties(sortie_files: List[str], verbose: bool = True) -> pd.DataFrame:
    """
    Load and combine multiple sortie CSV files.
    
    Parameters
    ----------
    sortie_files : List[str]
        List of paths to sortie CSV files
    verbose : bool
        Whether to print loading information
        
    Returns
    -------
    pd.DataFrame
        Combined dataframe from all sorties
    """
    if verbose:
        print("=" * 70)
        print("LOADING SORTIE DATA")
        print("=" * 70)
    
    data_list = []
    total_samples = 0
    
    for sortie_file in sortie_files:
        if not os.path.exists(sortie_file):
            raise FileNotFoundError(f"File not found: {sortie_file}")
        
        df = pd.read_csv(sortie_file)
        data_list.append(df)
        total_samples += len(df)
        
        if verbose:
            print(f"✓ {sortie_file:30} → {len(df):6} samples")
    
    combined_df = pd.concat(data_list, ignore_index=True)
    
    if verbose:
        print(f"\nTotal combined samples: {total_samples}")
        print(f"Columns: {list(combined_df.columns)}")
    
    return combined_df

def extract_features_and_targets(
    df: pd.DataFrame,
    temperature_columns: List[str],
    verbose: bool = True
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Extract FDR sensor features and temperature targets.
    
    Parameters
    ----------
    df : pd.DataFrame
        Combined dataframe with all data
    temperature_columns : List[str]
        Names of temperature output columns
    verbose : bool
        Whether to print extraction information
        
    Returns
    -------
    Tuple[np.ndarray, np.ndarray, List[str]]
        (X: sensor data, y: temperatures, sensor_columns: feature names)
    """
    if verbose:
        print("\n" + "=" * 70)
        print("EXTRACTING FEATURES AND TARGETS")
        print("=" * 70)
    
    # Extract FDR sensor columns (all except temps and timestamp)
    fdr_columns = [col for col in df.columns 
                   if col not in temperature_columns + ['timestamp']]
    
    # Extract data
    X = df[fdr_columns].values
    y = df[temperature_columns].values
    
    if verbose:
        print(f"\nFDR Sensor Features ({len(fdr_columns)}):")
        for i, col in enumerate(fdr_columns, 1):
            print(f"  {i:2}. {col}")
        
        print(f"\nTemperature Targets ({len(temperature_columns)}):")
        for i, col in enumerate(temperature_columns, 1):
            print(f"  {i}. {col}")
        
        print(f"\nData shapes:")
        print(f"  X (sensors): {X.shape}")
        print(f"  y (temperatures): {y.shape}")
    
    return X, y, fdr_columns

def normalize_data(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    verbose: bool = True
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, StandardScaler, StandardScaler]:
    """
    Normalize data using StandardScaler.
    
    Fit on training data, transform both training and test data.
    
    Parameters
    ----------
    X_train, y_train : np.ndarray
        Training input and output
    X_test, y_test : np.ndarray
        Test input and output
    verbose : bool
        Whether to print normalization info
        
    Returns
    -------
    Tuple
        (X_train_scaled, y_train_scaled, X_test_scaled, y_test_scaled, 
         scaler_X, scaler_y)
    """
    if verbose:
        print("\n" + "=" * 70)
        print("NORMALIZING DATA")
        print("=" * 70)
    
    # Create scalers
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    # Fit on training data only
    if verbose:
        print("\nFitting scalers on training data...")
    
    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)
    
    # Transform test data (using training scalers - no data leakage!)
    if verbose:
        print("Transforming test data with training scalers...")
    
    X_test_scaled = scaler_X.transform(X_test)
    y_test_scaled = scaler_y.transform(y_test)
    
    if verbose:
        print(f"\n✓ Normalization complete (no data leakage)")
        print(f"  X_train: mean={X_train_scaled.mean():.4f}, std={X_train_scaled.std():.4f}")
        print(f"  y_train: mean={y_train_scaled.mean():.4f}, std={y_train_scaled.std():.4f}")
        print(f"  X_test:  mean={X_test_scaled.mean():.4f}, std={X_test_scaled.std():.4f}")
        print(f"  y_test:  mean={y_test_scaled.mean():.4f}, std={y_test_scaled.std():.4f}")
    
    return X_train_scaled, y_train_scaled, X_test_scaled, y_test_scaled, scaler_X, scaler_y

def create_sequences(
    X: np.ndarray,
    y: np.ndarray,
    lookback: int = 30,
    forecast_horizon: int = 1,
    verbose: bool = True
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create overlapping sequences for LSTM training.
    
    Parameters
    ----------
    X : np.ndarray, shape (samples, features)
        Input sensor data
    y : np.ndarray, shape (samples, outputs)
        Output temperature data
    lookback : int
        Number of past timesteps to use as input variable
    forecast_horizon : int
        Number of steps ahead to predict
    verbose : bool
        Whether to print sequence creation info
        
    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (X_sequences, y_sequences)
        X_sequences: shape (num_sequences, lookback, features)
        y_sequences: shape (num_sequences, outputs)
    """
    if verbose:
        print("\n" + "=" * 70)
        print("CREATING LSTM SEQUENCES")
        print("=" * 70)
        print(f"\nParameters:")
        print(f"  Lookback window: {lookback} timesteps")
        print(f"  Forecast horizon: {forecast_horizon} step(s)")
    
    X_seq, y_seq = [], []
    
    for i in range(len(X) - lookback - forecast_horizon + 1):
        # Input: last 'lookback' timesteps
        X_seq.append(X[i:i+lookback])
        
        # Output: predict at lookback + forecast_horizon - 1
        y_seq.append(y[i+lookback+forecast_horizon-1])
    
    X_seq = np.array(X_seq)
    y_seq = np.array(y_seq)
    
    if verbose:
        print(f"\nSequences created:")
        print(f"  X_sequences shape: {X_seq.shape}")
        print(f"    └─ {X_seq.shape[0]} sequences")
        print(f"    └─ {X_seq.shape[1]} timesteps each")
        print(f"    └─ {X_seq.shape[2]} features each")
        print(f"  y_sequences shape: {y_seq.shape}")
        print(f"    └─ {y_seq.shape[0]} targets")
        print(f"    └─ {y_seq.shape[1]} temperatures each")
    
    return X_seq, y_seq

def prepare_data(
    training_files: List[str],
    testing_files: List[str],
    temperature_columns: List[str],
    lookback: int = 30,
    forecast_horizon: int = 1,
    verbose: bool = True
) -> dict:
    """
    Complete data preparation pipeline.
    
    Parameters
    ----------
    training_files : List[str]
        Paths to training sortie CSV files
    testing_files : List[str]
        Paths to testing sortie CSV files
    temperature_columns : List[str]
        Names of temperature output columns
    lookback : int
        Lookback window for sequences
    forecast_horizon : int
        Forecast horizon
    verbose : bool
        Whether to print progress
        
    Returns
    -------
    dict
        Dictionary with all prepared data and scalers:
        {
            'X_train': np.ndarray,
            'y_train': np.ndarray,
            'X_test': np.ndarray,
            'y_test': np.ndarray,
            'scaler_X': StandardScaler,
            'scaler_y': StandardScaler,
            'fdr_columns': List[str],
            'temperature_columns': List[str],
            'n_features': int,
            'n_outputs': int
        }
    """
    # Load data
    train_df = load_sorties(training_files, verbose=verbose)
    test_df = load_sorties(testing_files, verbose=verbose)
    
    # Extract features
    X_train_raw, y_train_raw, fdr_columns = extract_features_and_targets(
        train_df, temperature_columns, verbose=verbose)
    X_test_raw, y_test_raw, _ = extract_features_and_targets(
        test_df, temperature_columns, verbose=verbose)
    
    # Normalize
    X_train_scaled, y_train_scaled, X_test_scaled, y_test_scaled, scaler_X, scaler_y = \
        normalize_data(X_train_raw, y_train_raw, X_test_raw, y_test_raw, verbose=verbose)
    
    # Create sequences
    if verbose:
        print("\nCreating training sequences...")
    X_train_seq, y_train_seq = create_sequences(
        X_train_scaled, y_train_scaled, lookback, forecast_horizon, verbose=False)
    
    if verbose:
        print(f"  X_train_seq shape: {X_train_seq.shape}")
        print(f"  y_train_seq shape: {y_train_seq.shape}")
    
    if verbose:
        print("\nCreating testing sequences...")
    X_test_seq, y_test_seq = create_sequences(
        X_test_scaled, y_test_scaled, lookback, forecast_horizon, verbose=False)
    
    if verbose:
        print(f"  X_test_seq shape: {X_test_seq.shape}")
        print(f"  y_test_seq shape: {y_test_seq.shape}")
    
    if verbose:
        print("\n" + "=" * 70)
        print("DATA PREPARATION COMPLETE")
        print("=" * 70)
        print(f"\nSummary:")
        print(f"  Training sequences: {X_train_seq.shape[0]:,}")
        print(f"  Testing sequences: {X_test_seq.shape[0]:,}")
        print(f"  Input features (FDR sensors): {len(fdr_columns)}")
        print(f"  Output targets (Temperatures): {len(temperature_columns)}")
        print(f"  Sequence length (timesteps): {lookback}")
    
    return {
        'X_train': X_train_seq,
        'y_train': y_train_seq,
        'X_test': X_test_seq,
        'y_test': y_test_seq,
        'scaler_X': scaler_X,
        'scaler_y': scaler_y,
        'fdr_columns': fdr_columns,
        'temperature_columns': temperature_columns,
        'n_features': X_train_seq.shape[2],
        'n_outputs': y_train_seq.shape[1],
        'lookback': lookback
    }
