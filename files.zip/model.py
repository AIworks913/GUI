"""
LSTM Model Architecture for Temperature Prediction

Implements bidirectional LSTM with dense layers for temperature forecasting.
"""

import torch
import torch.nn as nn
from typing import Optional

class TemperatureLSTM(nn.Module):
    """
    Bidirectional LSTM model for aircraft temperature prediction.
    
    Architecture:
    ─────────────
    Input (30 timesteps × N features)
      ↓
    BiLSTM(64) + LayerNorm
      ↓
    BiLSTM(32) + LayerNorm
      ↓
    Dense(128) + Dropout(0.2)
      ↓
    Dense(64) + Dropout(0.15)
      ↓
    Dense(5) [Linear]
      ↓
    Output (5 temperature predictions)
    """
    
    def __init__(
        self,
        input_size: int,
        hidden_dim_1: int = 64,
        hidden_dim_2: int = 32,
        dense_dim_1: int = 128,
        dense_dim_2: int = 64,
        output_size: int = 5,
        dropout_rate_1: float = 0.2,
        dropout_rate_2: float = 0.15,
        l2_lambda: float = 0.001,
        device: str = 'cpu'
    ):
        """
        Initialize the LSTM model.
        
        Parameters
        ----------
        input_size : int
            Number of input features (FDR sensors)
        hidden_dim_1 : int
            Number of units in first LSTM layer (per direction)
        hidden_dim_2 : int
            Number of units in second LSTM layer (per direction)
        dense_dim_1 : int
            Number of units in first dense layer
        dense_dim_2 : int
            Number of units in second dense layer
        output_size : int
            Number of output predictions (temperatures)
        dropout_rate_1 : float
            Dropout rate after first dense layer
        dropout_rate_2 : float
            Dropout rate after second dense layer
        l2_lambda : float
            L2 regularization weight
        device : str
            Device to use ('cpu' or 'cuda')
        """
        super(TemperatureLSTM, self).__init__()
        
        self.input_size = input_size
        self.hidden_dim_1 = hidden_dim_1
        self.hidden_dim_2 = hidden_dim_2
        self.output_size = output_size
        self.l2_lambda = l2_lambda
        self.device = device
        
        # ============================================================
        # LSTM LAYERS
        # ============================================================
        
        # First Bidirectional LSTM
        # Input: (batch, seq_len, input_size)
        # Output: (batch, seq_len, 2*hidden_dim_1)
        self.lstm1 = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_dim_1,
            batch_first=True,
            bidirectional=True,  # Forward + Backward
            dropout=0.15  # Recurrent dropout
        )
        
        # Layer Normalization after LSTM1
        # Normalizes the 2*hidden_dim_1 dimensions
        self.layer_norm1 = nn.LayerNorm(2 * hidden_dim_1)
        
        # Second Bidirectional LSTM
        # Input: (batch, seq_len, 2*hidden_dim_1)
        # Output: (batch, seq_len, 2*hidden_dim_2) if return_sequences=True
        #         (batch, 2*hidden_dim_2) if return_sequences=False
        self.lstm2 = nn.LSTM(
            input_size=2 * hidden_dim_1,
            hidden_size=hidden_dim_2,
            batch_first=True,
            bidirectional=True,
            dropout=0.15
        )
        
        # Layer Normalization after LSTM2
        self.layer_norm2 = nn.LayerNorm(2 * hidden_dim_2)
        
        # ============================================================
        # DENSE LAYERS
        # ============================================================
        
        # First Dense Layer
        # Input: 2*hidden_dim_2
        # Output: dense_dim_1
        self.dense1 = nn.Linear(2 * hidden_dim_2, dense_dim_1)
        
        # Dropout after first dense layer
        self.dropout1 = nn.Dropout(dropout_rate_1)
        
        # Second Dense Layer
        # Input: dense_dim_1
        # Output: dense_dim_2
        self.dense2 = nn.Linear(dense_dim_1, dense_dim_2)
        
        # Dropout after second dense layer
        self.dropout2 = nn.Dropout(dropout_rate_2)
        
        # Output Layer
        # Input: dense_dim_2
        # Output: output_size (5 temperatures)
        self.output_layer = nn.Linear(dense_dim_2, output_size)
        
        # ============================================================
        # ACTIVATION FUNCTIONS
        # ============================================================
        
        self.relu = nn.ReLU()
        # Output activation is Linear (no activation)
        
        # ============================================================
        # MOVE TO DEVICE
        # ============================================================
        
        self.to(device)
        
        # Print model info
        self._print_model_info()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through the network.
        
        Parameters
        ----------
        x : torch.Tensor
            Input tensor of shape (batch_size, lookback, input_size)
            
        Returns
        -------
        torch.Tensor
            Output tensor of shape (batch_size, output_size)
        """
        # LSTM Layer 1
        # Input: (batch, seq_len, input_size)
        # Output: (batch, seq_len, 2*hidden_dim_1)
        lstm1_out, _ = self.lstm1(x)
        
        # Layer Normalization 1
        lstm1_norm = self.layer_norm1(lstm1_out)
        
        # LSTM Layer 2 - takes all timesteps from LSTM1
        # Input: (batch, seq_len, 2*hidden_dim_1)
        # Output: (batch, seq_len, 2*hidden_dim_2)
        # Then we take only the last timestep
        lstm2_out, _ = self.lstm2(lstm1_norm)
        
        # Layer Normalization 2
        lstm2_norm = self.layer_norm2(lstm2_out)
        
        # Take only the last timestep (final state)
        # From (batch, seq_len, 2*hidden_dim_2) to (batch, 2*hidden_dim_2)
        lstm_final = lstm2_norm[:, -1, :]
        
        # Dense Layer 1 + ReLU
        dense1_out = self.dense1(lstm_final)
        dense1_relu = self.relu(dense1_out)
        
        # Dropout 1
        dropout1_out = self.dropout1(dense1_relu)
        
        # Dense Layer 2 + ReLU
        dense2_out = self.dense2(dropout1_out)
        dense2_relu = self.relu(dense2_out)
        
        # Dropout 2
        dropout2_out = self.dropout2(dense2_relu)
        
        # Output Layer (Linear - no activation)
        output = self.output_layer(dropout2_out)
        
        return output
    
    def _print_model_info(self):
        """Print model architecture and parameter count."""
        print("\n" + "=" * 70)
        print("MODEL ARCHITECTURE")
        print("=" * 70)
        
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        
        print(f"\n{self.__class__.__name__}")
        print(f"  Total Parameters: {total_params:,}")
        print(f"  Trainable Parameters: {trainable_params:,}")
        print(f"  Device: {self.device}")
        
        print("\nLayers:")
        for name, module in self.named_children():
            print(f"  {name}: {module}")
    
    def count_parameters(self) -> dict:
        """
        Count model parameters.
        
        Returns
        -------
        dict
            Dictionary with parameter counts
        """
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        
        return {
            'total': total,
            'trainable': trainable,
            'non_trainable': total - trainable
        }
    
    def get_model_size_mb(self) -> float:
        """
        Estimate model size in MB.
        
        Returns
        -------
        float
            Model size in megabytes
        """
        param_size = 0
        for param in self.parameters():
            param_size += param.nelement() * 4  # 4 bytes per float32
        
        buffer_size = 0
        for buffer in self.buffers():
            buffer_size += buffer.nelement() * 4
        
        size_mb = (param_size + buffer_size) / 1024 / 1024
        return size_mb


if __name__ == '__main__':
    """Test the model"""
    import torch
    
    # Device
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    # Create model
    model = TemperatureLSTM(
        input_size=15,  # Example: 15 FDR sensors
        hidden_dim_1=64,
        hidden_dim_2=32,
        dense_dim_1=128,
        dense_dim_2=64,
        output_size=5,  # 5 temperatures
        device=device
    )
    
    # Test forward pass
    batch_size = 32
    lookback = 30
    input_size = 15
    
    x = torch.randn(batch_size, lookback, input_size, device=device)
    output = model(x)
    
    print(f"\nTest Forward Pass:")
    print(f"  Input shape: {x.shape}")
    print(f"  Output shape: {output.shape}")
    print(f"  Expected output shape: ({batch_size}, 5)")
    
    # Verify output shape
    assert output.shape == (batch_size, 5), "Output shape mismatch!"
    print(f"\n✓ Model test passed!")
