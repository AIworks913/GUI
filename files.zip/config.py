"""
Configuration file for Aircraft Temperature Prediction Model

Modify these parameters to tune the model performance.
"""

import torch

# ============================================================
# DATA CONFIGURATION
# ============================================================

# Sequence configuration
LOOKBACK = 30  # Number of past timesteps to use as input
FORECAST_HORIZON = 1  # Number of steps ahead to predict (usually 1)

# File paths
TRAINING_SORTIES = ['data/sortie_1.csv', 'data/sortie_2.csv', 
                    'data/sortie_3.csv', 'data/sortie_4.csv']
TESTING_SORTIES = ['data/sortie_5.csv', 'data/sortie_6.csv']

# Column names
TEMPERATURE_COLUMNS = ['temperature_1', 'temperature_2', 'temperature_3',
                       'temperature_4', 'temperature_5']
# FDR columns are auto-detected (all columns except temperatures and timestamp)

# ============================================================
# MODEL ARCHITECTURE CONFIGURATION
# ============================================================

# LSTM dimensions
HIDDEN_DIM_1 = 64  # First bidirectional LSTM: 64 forward + 64 backward = 128 output
HIDDEN_DIM_2 = 32  # Second bidirectional LSTM: 32 forward + 32 backward = 64 output

# Dense layer dimensions
DENSE_DIM_1 = 128  # First dense layer
DENSE_DIM_2 = 64   # Second dense layer

# Dropout rates
DROPOUT_RATE_1 = 0.2   # After first dense layer
DROPOUT_RATE_2 = 0.15  # After second dense layer

# Regularization
L2_REGULARIZATION = 0.001  # L2 weight decay

# LSTM specific
LSTM_ACTIVATION = 'tanh'  # LSTM activation (tanh is standard)
DENSE_ACTIVATION = 'relu'  # Dense layer activation
OUTPUT_ACTIVATION = None  # Output activation (None = linear)

# ============================================================
# TRAINING CONFIGURATION
# ============================================================

# Batch and learning
BATCH_SIZE = 64  # Samples per batch
LEARNING_RATE = 0.001  # Initial learning rate
NUM_EPOCHS = 200  # Maximum number of epochs
VALIDATION_SPLIT = 0.1  # 10% of training data for validation

# Early stopping
PATIENCE = 25  # Number of epochs to wait for improvement before stopping
MIN_IMPROVEMENT = 1e-4  # Minimum improvement in validation loss

# Learning rate scheduler
LR_FACTOR = 0.5  # Multiply learning rate by this factor
LR_PATIENCE = 10  # Wait this many epochs before reducing LR
MIN_LR = 1e-6  # Minimum learning rate

# ============================================================
# DEVICE CONFIGURATION
# ============================================================

# Automatically use GPU if available, otherwise CPU
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

# Set this to 'cpu' to force CPU usage
# DEVICE = 'cpu'

# For GPU: Set CUDA device if multiple GPUs available
GPU_DEVICE_ID = 0  # Which GPU to use (0 is first GPU)

# ============================================================
# OUTPUT CONFIGURATION
# ============================================================

# Output directory for models and results
OUTPUT_DIR = 'outputs'

# Save paths
MODEL_PATH = f'{OUTPUT_DIR}/model.pt'
SCALER_X_PATH = f'{OUTPUT_DIR}/scaler_X.pkl'
SCALER_Y_PATH = f'{OUTPUT_DIR}/scaler_y.pkl'
HISTORY_PATH = f'{OUTPUT_DIR}/training_history.json'
PLOT_PATH = f'{OUTPUT_DIR}/training_curves.png'
PREDICTIONS_PATH = f'{OUTPUT_DIR}/predictions.csv'

# ============================================================
# LOGGING CONFIGURATION
# ============================================================

# Print frequency
PRINT_EVERY = 1  # Print stats every N epochs
SAVE_EVERY = 10  # Save checkpoint every N epochs

# Verbosity
VERBOSE = True  # Print training progress
SAVE_PLOTS = True  # Save training visualization

# ============================================================
# NORMALIZATION CONFIGURATION
# ============================================================

# Normalization method
NORMALIZATION = 'standard'  # Options: 'standard', 'minmax'

# ============================================================
# RANDOM SEED (for reproducibility)
# ============================================================

RANDOM_SEED = 42

# ============================================================
# PREDICTION CONFIGURATION
# ============================================================

# For inference on new data
PREDICTION_BATCH_SIZE = 128  # Batch size for predictions
PREDICTION_DEVICE = DEVICE  # Device to use for predictions
