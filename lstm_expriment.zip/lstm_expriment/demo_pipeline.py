"""
DEMO: Complete Data Analysis Pipeline with Sample Aircraft Data
================================================================

This script demonstrates the complete pipeline using synthetic aircraft data
"""

import numpy as np
import pandas as pd
from complete_data_analysis_pipeline import DataAnalysisPipeline

def generate_sample_aircraft_data(n_samples=1000):
    """
    Generate realistic synthetic aircraft sensor data
    
    Simulates:
    - Temperature (target variable with temporal dependency)
    - Altitude (gradually changing)
    - Speed (gradually changing)
    - Engine Power (gradually changing)
    - Grms (vibration with spikes)
    """
    np.random.seed(42)
    
    # Time array
    time = pd.date_range(start='2024-01-01 00:00:00', periods=n_samples, freq='1s')
    
    # Altitude: gradually changing with some oscillation
    altitude = 5000 + 3000 * np.sin(np.arange(n_samples) / 100) + \
               500 * np.sin(np.arange(n_samples) / 20) + \
               np.random.normal(0, 50, n_samples)
    
    # Speed: correlated with altitude
    speed = 250 + 50 * np.sin(np.arange(n_samples) / 100) + \
            20 * np.sin(np.arange(n_samples) / 30) + \
            np.random.normal(0, 5, n_samples)
    
    # Engine Power
    engine_power = 60 + 20 * np.sin(np.arange(n_samples) / 80) + \
                   np.random.normal(0, 3, n_samples)
    
    # Temperature: depends on altitude, speed, engine_power AND past temperature (TIME SERIES!)
    temperature = np.zeros(n_samples)
    temperature[0] = 15.0
    
    for i in range(1, n_samples):
        # Base temperature from altitude (higher = colder)
        base_temp = 20 - (altitude[i] / 500)
        
        # Effect from speed (higher speed = slight cooling)
        speed_effect = -speed[i] / 100
        
        # Effect from engine power (higher power = slight warming)
        engine_effect = engine_power[i] / 30
        
        # TEMPORAL DEPENDENCY: 60% from previous temperature (inertia)
        # 40% from current conditions
        instant_temp = base_temp + speed_effect + engine_effect
        temperature[i] = 0.6 * temperature[i-1] + 0.4 * instant_temp
        
        # Add noise
        temperature[i] += np.random.normal(0, 0.3)
    
    # Grms: vibration with temporal dependency and occasional spikes
    grms = np.zeros(n_samples)
    grms[0] = 0.5
    
    # Add spike events at random times
    spike_times = np.random.choice(n_samples, size=20, replace=False)
    spike_magnitudes = np.random.uniform(1.5, 2.5, size=20)
    
    for i in range(1, n_samples):
        # Base vibration from engine power
        base_grms = 0.3 + engine_power[i] / 100 + speed[i] / 500
        
        # Temporal dependency (inertia/dampening)
        grms[i] = 0.7 * grms[i-1] + 0.3 * base_grms
        
        # Add spikes with decay
        for spike_time, magnitude in zip(spike_times, spike_magnitudes):
            if i >= spike_time:
                decay = magnitude * np.exp(-0.15 * (i - spike_time))
                grms[i] += decay
        
        # Add noise
        grms[i] += np.random.normal(0, 0.05)
    
    # Create DataFrame
    df = pd.DataFrame({
        'time': time,
        'altitude': altitude,
        'speed': speed,
        'engine_power': engine_power,
        'temperature': temperature,
        'grms': grms
    })
    
    return df


def main():
    """Run the complete pipeline demo"""
    
    print("="*80)
    print("DEMO: Complete Data Analysis Pipeline")
    print("="*80)
    
    # Generate sample data
    print("\n📊 Generating sample aircraft data...")
    df = generate_sample_aircraft_data(n_samples=1000)
    
    # Save to CSV
    df.to_csv('/home/claude/sample_aircraft_data.csv', index=False)
    print("✓ Sample data saved: sample_aircraft_data.csv")
    
    print(f"\nDataset preview:")
    print(df.head(10))
    
    # Run pipeline with Temperature as target
    print("\n" + "="*80)
    print("RUNNING PIPELINE: Temperature Prediction")
    print("="*80)
    
    pipeline_temp = DataAnalysisPipeline(
        data_path='/home/claude/sample_aircraft_data.csv',
        target_column='temperature'
    )
    
    pipeline_temp.run_complete_pipeline()
    
    print("\n" + "✅"*40)
    print("DEMO COMPLETED!")
    print("✅"*40)
    print("\nGenerated Files:")
    print("  - sample_aircraft_data.csv (sample data)")
    print("  - ANALYSIS_REPORT.txt (analysis report)")
    print("  - 01_distributions.png")
    print("  - 02_time_series_plots.png")
    print("  - 03_correlation_matrix.png")
    print("  - 04_scatter_matrix.png")
    print("  - 05_time_series_decomposition.png")
    print("  - 06_autocorrelation.png")
    print("  - 07_feature_importance.png")
    print("  - 08_model_evaluation.png")
    print("  - 09_model_comparison.png")
    

if __name__ == "__main__":
    main()
