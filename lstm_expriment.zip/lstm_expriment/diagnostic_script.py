"""
DIAGNOSTIC SCRIPT FOR LSTM PROBLEMS
====================================

Run this BEFORE doing any experiments to identify what's wrong
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error


def diagnostic_1_check_data_loading(train_data, test_data):
    """
    Diagnostic 1: Verify data is loaded correctly
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 1: DATA LOADING")
    print("="*80)
    
    print(f"\n✓ Train shape: {train_data.shape}")
    print(f"✓ Test shape: {test_data.shape}")
    
    print(f"\n✓ Train first 3 rows:")
    print(train_data.head(3))
    
    print(f"\n✓ Test first 3 rows:")
    print(test_data.head(3))
    
    # Check for NaN
    train_nan = train_data.isnull().sum().sum()
    test_nan = test_data.isnull().sum().sum()
    
    print(f"\n✓ Train NaN count: {train_nan}")
    print(f"✓ Test NaN count: {test_nan}")
    
    if train_nan > 0 or test_nan > 0:
        print("⚠️  WARNING: NaN values detected!")
        return False
    
    print("\n✅ Data loading looks OK")
    return True


def diagnostic_2_check_scaling(X_train, X_test, y_train, y_test, 
                               X_train_scaled, X_test_scaled, 
                               y_train_scaled, y_test_scaled,
                               scaler_X, scaler_y):
    """
    Diagnostic 2: Verify scaling is correct
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 2: SCALING")
    print("="*80)
    
    # Check if scaler was fitted on combined data (DATA LEAKAGE!)
    print("\n🔍 Checking for data leakage...")
    
    # Training data statistics after scaling
    print(f"\n✓ X_train_scaled mean: {X_train_scaled.mean(axis=0)[:3]}... (should be ≈ 0)")
    print(f"✓ X_train_scaled std: {X_train_scaled.std(axis=0)[:3]}... (should be ≈ 1)")
    
    print(f"\n✓ y_train_scaled mean: {y_train_scaled.mean(axis=0)} (should be ≈ 0)")
    print(f"✓ y_train_scaled std: {y_train_scaled.std(axis=0)} (should be ≈ 1)")
    
    # Test data statistics after scaling
    print(f"\n✓ X_test_scaled mean: {X_test_scaled.mean(axis=0)[:3]}...")
    print(f"✓ X_test_scaled std: {X_test_scaled.std(axis=0)[:3]}...")
    
    print(f"\n✓ y_test_scaled mean: {y_test_scaled.mean(axis=0)}")
    print(f"✓ y_test_scaled std: {y_test_scaled.std(axis=0)}")
    
    # Check if test statistics are reasonable
    # (Test won't have mean=0, std=1, but shouldn't be wildly different)
    test_mean_x = np.abs(X_test_scaled.mean(axis=0)).mean()
    test_mean_y = np.abs(y_test_scaled.mean(axis=0)).mean()
    
    if test_mean_x > 2 or test_mean_y > 2:
        print("\n⚠️  WARNING: Test data scaled values look unusual!")
        print("    This might indicate data leakage or distribution shift")
        return False
    
    # Verify inverse transform works
    print("\n🔍 Checking inverse transform...")
    y_original_recovered = scaler_y.inverse_transform(y_train_scaled[:5])
    difference = np.abs(y_train[:5] - y_original_recovered).max()
    print(f"✓ Max difference after inverse transform: {difference:.6f} (should be ≈ 0)")
    
    if difference > 0.01:
        print("⚠️  WARNING: Inverse transform not working correctly!")
        return False
    
    print("\n✅ Scaling looks OK")
    return True


def diagnostic_3_check_sequences(X_seq, y_seq, window_size, n_features, n_outputs):
    """
    Diagnostic 3: Verify sequence creation
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 3: SEQUENCE CREATION")
    print("="*80)
    
    print(f"\n✓ X_seq shape: {X_seq.shape}")
    print(f"  Expected: (num_sequences, {window_size}, {n_features})")
    
    print(f"\n✓ y_seq shape: {y_seq.shape}")
    print(f"  Expected: (num_sequences, {n_outputs})")
    
    # Check first sequence
    print(f"\n✓ First sequence (first 3 timesteps):")
    print(X_seq[0, :3, :])
    
    print(f"\n✓ Corresponding target:")
    print(y_seq[0])
    
    # Check if sequences are consecutive
    print(f"\n🔍 Checking if sequences are consecutive...")
    # The last timestep of seq[0] should be similar to first timestep of seq[1]
    # (unless there's a sortie boundary)
    
    if X_seq.shape[0] > 1:
        last_of_first = X_seq[0, -1, :]
        first_of_second = X_seq[1, 0, :]
        
        # They should be same or very close (scaled data)
        diff = np.abs(last_of_first - first_of_second).max()
        print(f"✓ Difference between seq[0][-1] and seq[1][0]: {diff:.4f}")
        
        if diff < 0.1:
            print("  → Sequences appear consecutive (good!)")
        else:
            print("  → Sequences might have boundary (sortie change?)")
    
    # Check for NaN
    nan_count = np.isnan(X_seq).sum()
    if nan_count > 0:
        print(f"\n⚠️  WARNING: {nan_count} NaN values in sequences!")
        return False
    
    print("\n✅ Sequences look OK")
    return True


def diagnostic_4_sanity_check_model(X_train_seq, y_train_seq, scaler_y):
    """
    Diagnostic 4: Train on small subset and test on SAME data
    Should get R² ≈ 0.99 (overfitting is OK here, we're testing model works)
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 4: SANITY CHECK - Train on 500 samples, test on SAME samples")
    print("="*80)
    
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense
    
    # Take small subset
    subset_size = min(500, len(X_train_seq))
    X_subset = X_train_seq[:subset_size]
    y_subset = y_train_seq[:subset_size]
    
    print(f"\n✓ Using {subset_size} samples")
    
    # Build simple model
    model = Sequential([
        LSTM(16, input_shape=(X_subset.shape[1], X_subset.shape[2])),
        Dense(y_subset.shape[1])
    ])
    
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    
    print("\n✓ Training...")
    history = model.fit(
        X_subset, y_subset,
        batch_size=32,
        epochs=50,
        verbose=0
    )
    
    # Predict on SAME data
    y_pred_scaled = model.predict(X_subset, verbose=0)
    
    # Inverse transform
    y_pred = scaler_y.inverse_transform(y_pred_scaled)
    y_true = scaler_y.inverse_transform(y_subset)
    
    # Calculate R²
    r2_per_output = []
    for i in range(y_true.shape[1]):
        r2 = r2_score(y_true[:, i], y_pred[:, i])
        r2_per_output.append(r2)
        print(f"✓ Output {i+1} R²: {r2:.4f}")
    
    avg_r2 = np.mean(r2_per_output)
    print(f"\n✓ Average R²: {avg_r2:.4f}")
    
    if avg_r2 < 0.7:
        print("\n❌ CRITICAL: Model cannot even overfit on training data!")
        print("   This indicates a fundamental problem:")
        print("   - Check data preprocessing")
        print("   - Check feature/target columns")
        print("   - Check scaling")
        print("   - Verify model architecture matches data shape")
        return False
    elif avg_r2 > 0.95:
        print("\n✅ GOOD: Model can learn (able to overfit)")
        print("   Problem is likely overfitting or generalization")
    else:
        print("\n⚠️  Model learns but not perfectly")
        print("   Might need longer training or better architecture")
    
    return True


def diagnostic_5_check_data_distribution(X_train, X_test, y_train, y_test):
    """
    Diagnostic 5: Check if train and test distributions are similar
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 5: DATA DISTRIBUTION ANALYSIS")
    print("="*80)
    
    print("\n✓ Input Features (X):")
    for i in range(min(3, X_train.shape[1])):
        train_mean = X_train[:, i].mean()
        train_std = X_train[:, i].std()
        test_mean = X_test[:, i].mean()
        test_std = X_test[:, i].std()
        
        print(f"  Feature {i}: Train μ={train_mean:.2f} σ={train_std:.2f}, "
              f"Test μ={test_mean:.2f} σ={test_std:.2f}")
        
        # Check if distributions are very different
        mean_diff = abs(train_mean - test_mean) / (train_std + 1e-8)
        if mean_diff > 3:
            print(f"    ⚠️  WARNING: Train/test means differ by {mean_diff:.1f} std devs!")
    
    print("\n✓ Output Targets (y):")
    for i in range(y_train.shape[1]):
        train_mean = y_train[:, i].mean()
        train_std = y_train[:, i].std()
        test_mean = y_test[:, i].mean()
        test_std = y_test[:, i].std()
        
        print(f"  Output {i+1}: Train μ={train_mean:.2f} σ={train_std:.2f}, "
              f"Test μ={test_mean:.2f} σ={test_std:.2f}")
        
        mean_diff = abs(train_mean - test_mean) / (train_std + 1e-8)
        if mean_diff > 3:
            print(f"    ⚠️  WARNING: Train/test means differ by {mean_diff:.1f} std devs!")
            print(f"    This is DISTRIBUTION SHIFT - test data is very different from train!")
    
    print("\n✅ Distribution check complete")


def diagnostic_6_check_station_effect(data, station_col, target_cols):
    """
    Diagnostic 6: Check if different stations have different characteristics
    """
    print("\n" + "="*80)
    print("DIAGNOSTIC 6: STATION EFFECT ANALYSIS")
    print("="*80)
    
    stations = data[station_col].unique()
    
    print(f"\n✓ Stations found: {stations}")
    
    for target_col in target_cols:
        print(f"\n✓ Target: {target_col}")
        for station in stations:
            station_data = data[data[station_col] == station][target_col]
            mean = station_data.mean()
            std = station_data.std()
            print(f"  Station {station}: μ={mean:.2f}, σ={std:.2f}, n={len(station_data)}")
    
    print("\n💡 If stations have very different means/stds:")
    print("   → Add station as a feature (one-hot encode)")
    print("   → Or train separate models per station")


def run_all_diagnostics(
    train_data, test_data,
    X_train, X_test, y_train, y_test,
    X_train_scaled, X_test_scaled, y_train_scaled, y_test_scaled,
    scaler_X, scaler_y,
    X_train_seq, y_train_seq,
    window_size, n_features, n_outputs,
    station_col=None, target_cols=None
):
    """
    Run all diagnostics
    """
    print("\n" + "🔍"*40)
    print("RUNNING COMPLETE DIAGNOSTICS")
    print("🔍"*40)
    
    results = {}
    
    # 1. Data loading
    results['data_loading'] = diagnostic_1_check_data_loading(train_data, test_data)
    
    # 2. Scaling
    results['scaling'] = diagnostic_2_check_scaling(
        X_train, X_test, y_train, y_test,
        X_train_scaled, X_test_scaled, y_train_scaled, y_test_scaled,
        scaler_X, scaler_y
    )
    
    # 3. Sequences
    results['sequences'] = diagnostic_3_check_sequences(
        X_train_seq, y_train_seq, window_size, n_features, n_outputs
    )
    
    # 4. Sanity check
    results['sanity_check'] = diagnostic_4_sanity_check_model(
        X_train_seq, y_train_seq, scaler_y
    )
    
    # 5. Distribution
    diagnostic_5_check_data_distribution(X_train, X_test, y_train, y_test)
    
    # 6. Station effect (if applicable)
    if station_col and target_cols:
        diagnostic_6_check_station_effect(train_data, station_col, target_cols)
    
    # Summary
    print("\n" + "="*80)
    print("DIAGNOSTIC SUMMARY")
    print("="*80)
    
    all_passed = all(results.values())
    
    for check, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {check}")
    
    if all_passed:
        print("\n✅ ALL DIAGNOSTICS PASSED!")
        print("   You can proceed with experiments")
    else:
        print("\n❌ SOME DIAGNOSTICS FAILED!")
        print("   Fix these issues before running experiments")
        print("\n   Common fixes:")
        print("   1. Data leakage: Fit scaler ONLY on train")
        print("   2. NaN values: Remove or impute before scaling")
        print("   3. Sequence boundaries: Don't mix different sorties")
        print("   4. Model architecture: Verify shapes match")
    
    return results


# ============================================================================
# TEMPLATE USAGE
# ============================================================================

"""
HOW TO USE THIS DIAGNOSTIC SCRIPT:

# After loading and preprocessing your data, run:

results = run_all_diagnostics(
    train_data=train_df,
    test_data=test_df,
    X_train=X_train,
    X_test=X_test,
    y_train=y_train,
    y_test=y_test,
    X_train_scaled=X_train_scaled,
    X_test_scaled=X_test_scaled,
    y_train_scaled=y_train_scaled,
    y_test_scaled=y_test_scaled,
    scaler_X=scaler_X,
    scaler_y=scaler_y,
    X_train_seq=X_train_seq,
    y_train_seq=y_train_seq,
    window_size=50,
    n_features=15,  # 12 inputs + 3 station
    n_outputs=4,
    station_col='station',
    target_cols=['temp1', 'temp2', 'temp3', 'temp4']
)

# Check results
if all(results.values()):
    print("Ready to run experiments!")
else:
    print("Fix issues first!")
"""


if __name__ == "__main__":
    print(__doc__)
    print("\nThis is a diagnostic tool. Import it in your main script.")
    print("See bottom of file for usage example.")
