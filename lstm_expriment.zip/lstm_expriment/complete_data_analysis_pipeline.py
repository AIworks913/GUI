"""
COMPLETE END-TO-END DATA ANALYSIS PIPELINE
==========================================
Author: Data Analysis Framework
Purpose: Comprehensive pipeline for time series and regular data analysis

This pipeline covers:
1. Data Loading & Initial Exploration
2. Data Quality Assessment
3. Exploratory Data Analysis (EDA)
4. Time Series Analysis (if applicable)
5. Feature Engineering
6. Model Building & Evaluation
7. Results Interpretation & Reporting
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, TimeSeriesSplit, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy import stats
from datetime import datetime

# For time series specific analysis
try:
    from statsmodels.tsa.stattools import adfuller, acf, pacf
    from statsmodels.tsa.seasonal import seasonal_decompose
    from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
    from statsmodels.tsa.arima.model import ARIMA
    HAS_STATSMODELS = True
except ImportError:
    HAS_STATSMODELS = False
    print("Warning: statsmodels not installed. Some time series features will be limited.")


class DataAnalysisPipeline:
    """
    Complete end-to-end data analysis pipeline
    """
    
    def __init__(self, data_path=None, df=None, target_column=None):
        """
        Initialize the pipeline
        
        Parameters:
        -----------
        data_path : str, optional
            Path to CSV file
        df : DataFrame, optional
            Pre-loaded DataFrame
        target_column : str, optional
            Name of target variable to predict
        """
        self.data_path = data_path
        self.df = df
        self.target_column = target_column
        self.is_time_series = False
        self.time_column = None
        self.report = {}
        
        # Set plot style
        plt.style.use('seaborn-v0_8-darkgrid')
        sns.set_palette("husl")
        
    # ========================================================================
    # PHASE 1: DATA LOADING & INITIAL EXPLORATION
    # ========================================================================
    
    def load_data(self):
        """Load data from CSV file"""
        print("="*80)
        print("PHASE 1: DATA LOADING & INITIAL EXPLORATION")
        print("="*80)
        
        if self.df is None and self.data_path is not None:
            print(f"\n📂 Loading data from: {self.data_path}")
            self.df = pd.read_csv(self.data_path)
            print(f"✓ Data loaded successfully!")
        elif self.df is not None:
            print("\n📂 Using provided DataFrame")
        else:
            raise ValueError("Must provide either data_path or df")
        
        # Basic info
        print(f"\n📊 Dataset Shape: {self.df.shape[0]} rows × {self.df.shape[1]} columns")
        print(f"\n📋 Column Names:\n{list(self.df.columns)}")
        
        # Display first few rows
        print(f"\n🔍 First 5 rows:")
        print(self.df.head())
        
        # Data types
        print(f"\n📝 Data Types:")
        print(self.df.dtypes)
        
        return self
    
    def detect_time_column(self):
        """Automatically detect time/date column"""
        print(f"\n🕐 Detecting time column...")
        
        # Common time column names
        time_keywords = ['time', 'date', 'datetime', 'timestamp', 'period']
        
        for col in self.df.columns:
            col_lower = col.lower()
            
            # Check by name
            if any(keyword in col_lower for keyword in time_keywords):
                self.time_column = col
                print(f"✓ Time column detected: '{col}' (by name)")
                break
            
            # Check by data type
            if pd.api.types.is_datetime64_any_dtype(self.df[col]):
                self.time_column = col
                print(f"✓ Time column detected: '{col}' (by dtype)")
                break
        
        # Try to convert time column to datetime
        if self.time_column:
            try:
                if not pd.api.types.is_datetime64_any_dtype(self.df[self.time_column]):
                    self.df[self.time_column] = pd.to_datetime(self.df[self.time_column])
                    print(f"✓ Converted '{self.time_column}' to datetime")
            except:
                print(f"⚠ Could not convert '{self.time_column}' to datetime")
        else:
            print("ℹ No time column detected - treating as cross-sectional data")
        
        return self
    
    def detect_target_column(self):
        """Detect or validate target column"""
        print(f"\n🎯 Target Variable:")
        
        if self.target_column is None:
            # Suggest numeric columns as potential targets
            numeric_cols = self.df.select_dtypes(include=[np.number]).columns
            print(f"⚠ No target column specified.")
            print(f"Numeric columns available: {list(numeric_cols)}")
            print("Please specify target_column when initializing the pipeline")
        else:
            if self.target_column in self.df.columns:
                print(f"✓ Target column: '{self.target_column}'")
            else:
                raise ValueError(f"Target column '{self.target_column}' not found in data")
        
        return self
    
    # ========================================================================
    # PHASE 2: DATA QUALITY ASSESSMENT
    # ========================================================================
    
    def assess_data_quality(self):
        """Comprehensive data quality check"""
        print("\n" + "="*80)
        print("PHASE 2: DATA QUALITY ASSESSMENT")
        print("="*80)
        
        # Missing values
        print("\n📊 Missing Values:")
        missing = self.df.isnull().sum()
        missing_pct = 100 * missing / len(self.df)
        missing_df = pd.DataFrame({
            'Missing_Count': missing,
            'Percentage': missing_pct
        }).sort_values('Percentage', ascending=False)
        
        print(missing_df[missing_df['Missing_Count'] > 0])
        
        if missing_df['Missing_Count'].sum() == 0:
            print("✓ No missing values found!")
        
        self.report['missing_values'] = missing_df
        
        # Duplicates
        print("\n🔁 Duplicate Rows:")
        duplicates = self.df.duplicated().sum()
        print(f"Number of duplicate rows: {duplicates}")
        
        if duplicates > 0:
            print(f"⚠ Warning: {duplicates} duplicate rows found")
        else:
            print("✓ No duplicates found!")
        
        # Data types summary
        print("\n📝 Data Types Summary:")
        print(self.df.dtypes.value_counts())
        
        # Basic statistics
        print("\n📈 Statistical Summary:")
        print(self.df.describe())
        
        return self
    
    def detect_outliers(self):
        """Detect outliers using IQR method"""
        print("\n🔍 Outlier Detection (IQR Method):")
        
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        outlier_summary = {}
        
        for col in numeric_cols:
            Q1 = self.df[col].quantile(0.25)
            Q3 = self.df[col].quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outliers = self.df[(self.df[col] < lower_bound) | (self.df[col] > upper_bound)]
            outlier_count = len(outliers)
            outlier_pct = 100 * outlier_count / len(self.df)
            
            if outlier_count > 0:
                outlier_summary[col] = {
                    'count': outlier_count,
                    'percentage': outlier_pct,
                    'lower_bound': lower_bound,
                    'upper_bound': upper_bound
                }
                print(f"  {col}: {outlier_count} outliers ({outlier_pct:.2f}%)")
        
        if not outlier_summary:
            print("  ✓ No significant outliers detected")
        
        self.report['outliers'] = outlier_summary
        
        return self
    
    # ========================================================================
    # PHASE 3: EXPLORATORY DATA ANALYSIS (EDA)
    # ========================================================================
    
    def visualize_distributions(self, save_plots=True):
        """Visualize distributions of all numeric variables"""
        print("\n" + "="*80)
        print("PHASE 3: EXPLORATORY DATA ANALYSIS (EDA)")
        print("="*80)
        
        print("\n📊 Visualizing Distributions...")
        
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        n_cols = len(numeric_cols)
        
        if n_cols == 0:
            print("No numeric columns to plot")
            return self
        
        n_rows = (n_cols + 2) // 3
        fig, axes = plt.subplots(n_rows, 3, figsize=(15, 4*n_rows))
        axes = axes.flatten() if n_cols > 1 else [axes]
        
        for idx, col in enumerate(numeric_cols):
            axes[idx].hist(self.df[col].dropna(), bins=50, edgecolor='black', alpha=0.7)
            axes[idx].set_title(f'Distribution of {col}')
            axes[idx].set_xlabel(col)
            axes[idx].set_ylabel('Frequency')
            axes[idx].grid(True, alpha=0.3)
        
        # Hide extra subplots
        for idx in range(n_cols, len(axes)):
            axes[idx].axis('off')
        
        plt.tight_layout()
        if save_plots:
            plt.savefig('/home/claude/01_distributions.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 01_distributions.png")
        plt.close()
        
        return self
    
    def visualize_time_series(self, save_plots=True):
        """Visualize all variables over time"""
        if self.time_column is None:
            print("\nℹ Skipping time series visualization (no time column)")
            return self
        
        print("\n📈 Visualizing Time Series...")
        
        numeric_cols = [col for col in self.df.select_dtypes(include=[np.number]).columns 
                       if col != self.time_column]
        
        if not numeric_cols:
            return self
        
        fig, axes = plt.subplots(len(numeric_cols), 1, figsize=(14, 3*len(numeric_cols)))
        if len(numeric_cols) == 1:
            axes = [axes]
        
        for idx, col in enumerate(numeric_cols):
            axes[idx].plot(self.df[self.time_column], self.df[col], linewidth=1.5)
            axes[idx].set_title(f'{col} Over Time', fontsize=12, fontweight='bold')
            axes[idx].set_xlabel('Time')
            axes[idx].set_ylabel(col)
            axes[idx].grid(True, alpha=0.3)
        
        plt.tight_layout()
        if save_plots:
            plt.savefig('/home/claude/02_time_series_plots.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 02_time_series_plots.png")
        plt.close()
        
        return self
    
    def correlation_analysis(self, save_plots=True):
        """Analyze correlations between variables"""
        print("\n🔗 Correlation Analysis...")
        
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) < 2:
            print("Not enough numeric columns for correlation analysis")
            return self
        
        correlation_matrix = self.df[numeric_cols].corr()
        
        # Plot correlation heatmap
        plt.figure(figsize=(12, 10))
        sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
                   center=0, square=True, linewidths=1, cbar_kws={"shrink": 0.8})
        plt.title('Correlation Matrix', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_plots:
            plt.savefig('/home/claude/03_correlation_matrix.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 03_correlation_matrix.png")
        plt.close()
        
        # If target column is specified, show correlations with target
        if self.target_column and self.target_column in numeric_cols:
            print(f"\n📊 Correlation with target '{self.target_column}':")
            target_corr = correlation_matrix[self.target_column].sort_values(ascending=False)
            print(target_corr)
            self.report['target_correlations'] = target_corr
        
        self.report['correlation_matrix'] = correlation_matrix
        
        return self
    
    def scatter_matrix(self, save_plots=True):
        """Create scatter plot matrix"""
        print("\n🔍 Creating Scatter Matrix...")
        
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        
        # Limit to first 5 columns if too many
        if len(numeric_cols) > 5:
            cols_to_plot = numeric_cols[:5]
            print(f"ℹ Limiting to first 5 columns: {list(cols_to_plot)}")
        else:
            cols_to_plot = numeric_cols
        
        if len(cols_to_plot) < 2:
            print("Not enough columns for scatter matrix")
            return self
        
        from pandas.plotting import scatter_matrix as pd_scatter_matrix
        
        fig = plt.figure(figsize=(15, 15))
        pd_scatter_matrix(self.df[cols_to_plot], alpha=0.5, figsize=(15, 15), diagonal='hist')
        plt.suptitle('Scatter Matrix', y=0.995, fontsize=14, fontweight='bold')
        
        if save_plots:
            plt.savefig('/home/claude/04_scatter_matrix.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 04_scatter_matrix.png")
        plt.close()
        
        return self
    
    # ========================================================================
    # PHASE 4: TIME SERIES SPECIFIC ANALYSIS
    # ========================================================================
    
    def check_stationarity(self):
        """Test for stationarity using Augmented Dickey-Fuller test"""
        if not HAS_STATSMODELS or self.time_column is None or self.target_column is None:
            print("\nℹ Skipping stationarity test")
            return self
        
        print("\n" + "="*80)
        print("PHASE 4: TIME SERIES SPECIFIC ANALYSIS")
        print("="*80)
        
        print("\n📊 Stationarity Test (Augmented Dickey-Fuller):")
        
        data = self.df[self.target_column].dropna()
        
        result = adfuller(data)
        
        print(f"  ADF Statistic: {result[0]:.6f}")
        print(f"  p-value: {result[1]:.6f}")
        print(f"  Critical Values:")
        for key, value in result[4].items():
            print(f"    {key}: {value:.3f}")
        
        if result[1] < 0.05:
            print(f"\n  ✓ Data is STATIONARY (p-value < 0.05)")
            self.is_time_series = True
            self.report['stationarity'] = 'Stationary'
        else:
            print(f"\n  ⚠ Data is NON-STATIONARY (p-value >= 0.05)")
            print(f"     Consider differencing or detrending")
            self.is_time_series = True
            self.report['stationarity'] = 'Non-stationary'
        
        return self
    
    def decompose_time_series(self, save_plots=True):
        """Decompose time series into trend, seasonal, and residual components"""
        if not HAS_STATSMODELS or self.time_column is None or self.target_column is None:
            return self
        
        print("\n📊 Time Series Decomposition...")
        
        # Need at least 2 periods for decomposition
        if len(self.df) < 20:
            print("  Not enough data points for decomposition")
            return self
        
        try:
            # Estimate period (simplified)
            period = min(50, len(self.df) // 4)
            
            decomposition = seasonal_decompose(
                self.df[self.target_column].dropna(), 
                model='additive', 
                period=period,
                extrapolate_trend='freq'
            )
            
            fig, axes = plt.subplots(4, 1, figsize=(14, 10))
            
            decomposition.observed.plot(ax=axes[0], title='Original', color='blue')
            decomposition.trend.plot(ax=axes[1], title='Trend', color='green')
            decomposition.seasonal.plot(ax=axes[2], title='Seasonal', color='orange')
            decomposition.resid.plot(ax=axes[3], title='Residual', color='red')
            
            for ax in axes:
                ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            if save_plots:
                plt.savefig('/home/claude/05_time_series_decomposition.png', dpi=150, bbox_inches='tight')
                print("✓ Saved: 05_time_series_decomposition.png")
            plt.close()
            
        except Exception as e:
            print(f"  Could not decompose time series: {str(e)}")
        
        return self
    
    def autocorrelation_analysis(self, save_plots=True):
        """Analyze autocorrelation and partial autocorrelation"""
        if not HAS_STATSMODELS or self.target_column is None:
            return self
        
        print("\n📊 Autocorrelation Analysis...")
        
        data = self.df[self.target_column].dropna()
        
        if len(data) < 30:
            print("  Not enough data points for ACF/PACF")
            return self
        
        fig, axes = plt.subplots(2, 1, figsize=(14, 8))
        
        # ACF
        plot_acf(data, lags=min(50, len(data)//2), ax=axes[0])
        axes[0].set_title('Autocorrelation Function (ACF)', fontweight='bold')
        
        # PACF
        plot_pacf(data, lags=min(50, len(data)//2), ax=axes[1])
        axes[1].set_title('Partial Autocorrelation Function (PACF)', fontweight='bold')
        
        plt.tight_layout()
        if save_plots:
            plt.savefig('/home/claude/06_autocorrelation.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 06_autocorrelation.png")
        plt.close()
        
        return self
    
    # ========================================================================
    # PHASE 5: FEATURE ENGINEERING
    # ========================================================================
    
    def create_lag_features(self, lags=[1, 2, 3, 5, 10]):
        """Create lagged features for time series"""
        if self.target_column is None:
            return self
        
        print("\n" + "="*80)
        print("PHASE 5: FEATURE ENGINEERING")
        print("="*80)
        
        print(f"\n🔧 Creating Lag Features for '{self.target_column}'...")
        
        for lag in lags:
            col_name = f'{self.target_column}_lag_{lag}'
            self.df[col_name] = self.df[self.target_column].shift(lag)
            print(f"  ✓ Created: {col_name}")
        
        # Create rolling features
        windows = [5, 10, 20]
        for window in windows:
            self.df[f'{self.target_column}_rolling_mean_{window}'] = \
                self.df[self.target_column].rolling(window=window).mean()
            self.df[f'{self.target_column}_rolling_std_{window}'] = \
                self.df[self.target_column].rolling(window=window).std()
            print(f"  ✓ Created rolling features (window={window})")
        
        # Create difference features
        self.df[f'{self.target_column}_diff_1'] = self.df[self.target_column].diff(1)
        print(f"  ✓ Created difference feature")
        
        print(f"\n  Total features created: {len(lags) + 2*len(windows) + 1}")
        
        return self
    
    def create_time_features(self):
        """Create time-based features from time column"""
        if self.time_column is None:
            return self
        
        print("\n🕐 Creating Time Features...")
        
        try:
            time_col = pd.to_datetime(self.df[self.time_column])
            
            self.df['hour'] = time_col.dt.hour
            self.df['day_of_week'] = time_col.dt.dayofweek
            self.df['day_of_month'] = time_col.dt.day
            self.df['month'] = time_col.dt.month
            self.df['quarter'] = time_col.dt.quarter
            self.df['year'] = time_col.dt.year
            
            print("  ✓ Created: hour, day_of_week, day_of_month, month, quarter, year")
            
        except Exception as e:
            print(f"  Could not create time features: {str(e)}")
        
        return self
    
    # ========================================================================
    # PHASE 6: MODEL BUILDING & EVALUATION
    # ========================================================================
    
    def prepare_data_for_modeling(self):
        """Prepare features and target for modeling"""
        print("\n" + "="*80)
        print("PHASE 6: MODEL BUILDING & EVALUATION")
        print("="*80)
        
        if self.target_column is None:
            print("\n⚠ No target column specified. Skipping modeling.")
            return self
        
        print("\n🔧 Preparing Data for Modeling...")
        
        # Remove rows with NaN (created by lag features)
        df_clean = self.df.dropna()
        
        # Separate features and target
        exclude_cols = [self.target_column]
        if self.time_column:
            exclude_cols.append(self.time_column)
        
        # Get numeric columns only
        numeric_cols = df_clean.select_dtypes(include=[np.number]).columns
        feature_cols = [col for col in numeric_cols if col not in exclude_cols]
        
        self.X = df_clean[feature_cols]
        self.y = df_clean[self.target_column]
        
        print(f"  Features shape: {self.X.shape}")
        print(f"  Target shape: {self.y.shape}")
        print(f"  Feature columns: {list(feature_cols)}")
        
        return self
    
    def split_data(self, test_size=0.2, time_series=None):
        """Split data into train and test sets"""
        if not hasattr(self, 'X') or not hasattr(self, 'y'):
            print("\n⚠ Data not prepared. Call prepare_data_for_modeling() first.")
            return self
        
        print(f"\n✂️ Splitting Data (test_size={test_size})...")
        
        # Determine if time series split should be used
        if time_series is None:
            time_series = self.is_time_series or self.time_column is not None
        
        if time_series:
            # Time series split (chronological)
            split_idx = int(len(self.X) * (1 - test_size))
            self.X_train = self.X.iloc[:split_idx]
            self.X_test = self.X.iloc[split_idx:]
            self.y_train = self.y.iloc[:split_idx]
            self.y_test = self.y.iloc[split_idx:]
            print(f"  Split type: CHRONOLOGICAL (time series)")
        else:
            # Random split
            self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
                self.X, self.y, test_size=test_size, random_state=42
            )
            print(f"  Split type: RANDOM (cross-sectional)")
        
        print(f"  Train set: {len(self.X_train)} samples")
        print(f"  Test set: {len(self.X_test)} samples")
        
        return self
    
    def train_models(self):
        """Train multiple models and compare"""
        if not hasattr(self, 'X_train'):
            print("\n⚠ Data not split. Call split_data() first.")
            return self
        
        print("\n🤖 Training Models...")
        
        models = {
            'Linear Regression': LinearRegression(),
            'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42)
        }
        
        self.trained_models = {}
        self.model_results = {}
        
        for name, model in models.items():
            print(f"\n  Training {name}...")
            
            try:
                # Train
                model.fit(self.X_train, self.y_train)
                
                # Predict
                y_pred_train = model.predict(self.X_train)
                y_pred_test = model.predict(self.X_test)
                
                # Evaluate
                train_rmse = np.sqrt(mean_squared_error(self.y_train, y_pred_train))
                test_rmse = np.sqrt(mean_squared_error(self.y_test, y_pred_test))
                train_r2 = r2_score(self.y_train, y_pred_train)
                test_r2 = r2_score(self.y_test, y_pred_test)
                test_mae = mean_absolute_error(self.y_test, y_pred_test)
                
                self.trained_models[name] = model
                self.model_results[name] = {
                    'train_rmse': train_rmse,
                    'test_rmse': test_rmse,
                    'train_r2': train_r2,
                    'test_r2': test_r2,
                    'test_mae': test_mae,
                    'predictions': y_pred_test
                }
                
                print(f"    Train RMSE: {train_rmse:.4f}")
                print(f"    Test RMSE: {test_rmse:.4f}")
                print(f"    Test R²: {test_r2:.4f}")
                print(f"    Test MAE: {test_mae:.4f}")
                
            except Exception as e:
                print(f"    ⚠ Error training {name}: {str(e)}")
        
        return self
    
    def evaluate_best_model(self, save_plots=True):
        """Evaluate the best performing model in detail"""
        if not hasattr(self, 'model_results') or not self.model_results:
            return self
        
        print("\n📊 Evaluating Best Model...")
        
        # Find best model (by test R²)
        best_model_name = max(self.model_results, key=lambda k: self.model_results[k]['test_r2'])
        best_model = self.trained_models[best_model_name]
        results = self.model_results[best_model_name]
        
        print(f"\n🏆 Best Model: {best_model_name}")
        print(f"  Test R²: {results['test_r2']:.4f}")
        print(f"  Test RMSE: {results['test_rmse']:.4f}")
        print(f"  Test MAE: {results['test_mae']:.4f}")
        
        # Feature importance (if available)
        if hasattr(best_model, 'feature_importances_'):
            print(f"\n📊 Top 10 Important Features:")
            feature_importance = pd.DataFrame({
                'feature': self.X.columns,
                'importance': best_model.feature_importances_
            }).sort_values('importance', ascending=False)
            
            print(feature_importance.head(10))
            self.report['feature_importance'] = feature_importance
            
            # Plot feature importance
            plt.figure(figsize=(10, 6))
            top_features = feature_importance.head(15)
            plt.barh(range(len(top_features)), top_features['importance'])
            plt.yticks(range(len(top_features)), top_features['feature'])
            plt.xlabel('Importance')
            plt.title(f'Top 15 Feature Importances - {best_model_name}')
            plt.gca().invert_yaxis()
            plt.tight_layout()
            
            if save_plots:
                plt.savefig('/home/claude/07_feature_importance.png', dpi=150, bbox_inches='tight')
                print("\n✓ Saved: 07_feature_importance.png")
            plt.close()
        
        # Residual analysis
        predictions = results['predictions']
        residuals = self.y_test - predictions
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # Predictions vs Actual
        axes[0, 0].scatter(self.y_test, predictions, alpha=0.5)
        axes[0, 0].plot([self.y_test.min(), self.y_test.max()], 
                       [self.y_test.min(), self.y_test.max()], 'r--', lw=2)
        axes[0, 0].set_xlabel('Actual')
        axes[0, 0].set_ylabel('Predicted')
        axes[0, 0].set_title('Predictions vs Actual')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Residuals over index
        axes[0, 1].scatter(range(len(residuals)), residuals, alpha=0.5)
        axes[0, 1].axhline(y=0, color='r', linestyle='--', lw=2)
        axes[0, 1].set_xlabel('Index')
        axes[0, 1].set_ylabel('Residual')
        axes[0, 1].set_title('Residuals Over Index')
        axes[0, 1].grid(True, alpha=0.3)
        
        # Residual distribution
        axes[1, 0].hist(residuals, bins=50, edgecolor='black', alpha=0.7)
        axes[1, 0].set_xlabel('Residual')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].set_title('Residual Distribution')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Q-Q plot
        stats.probplot(residuals, dist="norm", plot=axes[1, 1])
        axes[1, 1].set_title('Q-Q Plot')
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.suptitle(f'Model Evaluation: {best_model_name}', fontsize=14, fontweight='bold', y=1.00)
        plt.tight_layout()
        
        if save_plots:
            plt.savefig('/home/claude/08_model_evaluation.png', dpi=150, bbox_inches='tight')
            print("✓ Saved: 08_model_evaluation.png")
        plt.close()
        
        self.report['best_model'] = best_model_name
        self.report['best_model_metrics'] = results
        
        return self
    
    def compare_models(self, save_plots=True):
        """Compare performance of all models"""
        if not hasattr(self, 'model_results') or not self.model_results:
            return self
        
        print("\n📊 Model Comparison:")
        
        comparison_df = pd.DataFrame({
            name: {
                'Test RMSE': results['test_rmse'],
                'Test R²': results['test_r2'],
                'Test MAE': results['test_mae']
            }
            for name, results in self.model_results.items()
        }).T
        
        print(comparison_df)
        
        # Plot comparison
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        
        # RMSE comparison
        comparison_df['Test RMSE'].plot(kind='bar', ax=axes[0], color='steelblue')
        axes[0].set_title('Test RMSE Comparison')
        axes[0].set_ylabel('RMSE')
        axes[0].tick_params(axis='x', rotation=45)
        axes[0].grid(True, alpha=0.3)
        
        # R² comparison
        comparison_df['Test R²'].plot(kind='bar', ax=axes[1], color='green')
        axes[1].set_title('Test R² Comparison')
        axes[1].set_ylabel('R²')
        axes[1].tick_params(axis='x', rotation=45)
        axes[1].grid(True, alpha=0.3)
        
        # MAE comparison
        comparison_df['Test MAE'].plot(kind='bar', ax=axes[2], color='orange')
        axes[2].set_title('Test MAE Comparison')
        axes[2].set_ylabel('MAE')
        axes[2].tick_params(axis='x', rotation=45)
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_plots:
            plt.savefig('/home/claude/09_model_comparison.png', dpi=150, bbox_inches='tight')
            print("\n✓ Saved: 09_model_comparison.png")
        plt.close()
        
        return self
    
    # ========================================================================
    # PHASE 7: REPORTING
    # ========================================================================
    
    def generate_report(self):
        """Generate comprehensive analysis report"""
        print("\n" + "="*80)
        print("PHASE 7: FINAL REPORT")
        print("="*80)
        
        report_text = f"""
{'='*80}
DATA ANALYSIS REPORT
{'='*80}

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

DATASET INFORMATION
-------------------
Shape: {self.df.shape[0]} rows × {self.df.shape[1]} columns
Time Column: {self.time_column if self.time_column else 'Not detected'}
Target Column: {self.target_column if self.target_column else 'Not specified'}
Data Type: {'Time Series' if self.is_time_series else 'Cross-Sectional'}

DATA QUALITY
------------
Missing Values: {self.df.isnull().sum().sum()} total
Duplicate Rows: {self.df.duplicated().sum()}
"""
        
        if 'outliers' in self.report and self.report['outliers']:
            report_text += f"\nOutliers Detected:\n"
            for col, info in self.report['outliers'].items():
                report_text += f"  {col}: {info['count']} ({info['percentage']:.2f}%)\n"
        
        if 'stationarity' in self.report:
            report_text += f"\nTime Series Analysis:\n"
            report_text += f"  Stationarity: {self.report['stationarity']}\n"
        
        if 'best_model' in self.report:
            report_text += f"\n{'='*80}\n"
            report_text += f"MODEL PERFORMANCE\n"
            report_text += f"{'='*80}\n"
            report_text += f"\nBest Model: {self.report['best_model']}\n"
            metrics = self.report['best_model_metrics']
            report_text += f"  Test R²: {metrics['test_r2']:.4f}\n"
            report_text += f"  Test RMSE: {metrics['test_rmse']:.4f}\n"
            report_text += f"  Test MAE: {metrics['test_mae']:.4f}\n"
        
        if 'feature_importance' in self.report:
            report_text += f"\nTop 5 Important Features:\n"
            top_features = self.report['feature_importance'].head(5)
            for idx, row in top_features.iterrows():
                report_text += f"  {idx+1}. {row['feature']}: {row['importance']:.4f}\n"
        
        report_text += f"\n{'='*80}\n"
        report_text += f"PLOTS GENERATED\n"
        report_text += f"{'='*80}\n"
        report_text += """
  01_distributions.png - Distribution of all numeric variables
  02_time_series_plots.png - Time series plots (if applicable)
  03_correlation_matrix.png - Correlation heatmap
  04_scatter_matrix.png - Scatter plot matrix
  05_time_series_decomposition.png - Trend/Seasonal decomposition (if applicable)
  06_autocorrelation.png - ACF/PACF plots (if applicable)
  07_feature_importance.png - Feature importance (if applicable)
  08_model_evaluation.png - Model evaluation plots
  09_model_comparison.png - Model comparison
"""
        
        report_text += f"\n{'='*80}\n"
        report_text += f"END OF REPORT\n"
        report_text += f"{'='*80}\n"
        
        # Save report
        with open('/home/claude/ANALYSIS_REPORT.txt', 'w') as f:
            f.write(report_text)
        
        print(report_text)
        print("\n✓ Report saved: ANALYSIS_REPORT.txt")
        
        return self
    
    # ========================================================================
    # MASTER PIPELINE
    # ========================================================================
    
    def run_complete_pipeline(self, create_features=True, train_models_flag=True):
        """
        Run the complete end-to-end analysis pipeline
        
        Parameters:
        -----------
        create_features : bool
            Whether to create lag and time features
        train_models_flag : bool
            Whether to train and evaluate models
        """
        print("\n" + "🚀"*40)
        print("STARTING COMPLETE DATA ANALYSIS PIPELINE")
        print("🚀"*40 + "\n")
        
        # Phase 1: Load and explore
        self.load_data()
        self.detect_time_column()
        self.detect_target_column()
        
        # Phase 2: Data quality
        self.assess_data_quality()
        self.detect_outliers()
        
        # Phase 3: EDA
        self.visualize_distributions()
        self.visualize_time_series()
        self.correlation_analysis()
        self.scatter_matrix()
        
        # Phase 4: Time series analysis
        if self.time_column and self.target_column:
            self.check_stationarity()
            self.decompose_time_series()
            self.autocorrelation_analysis()
        
        # Phase 5: Feature engineering
        if create_features and self.target_column:
            self.create_lag_features()
            self.create_time_features()
        
        # Phase 6: Modeling
        if train_models_flag and self.target_column:
            self.prepare_data_for_modeling()
            self.split_data()
            self.train_models()
            self.evaluate_best_model()
            self.compare_models()
        
        # Phase 7: Report
        self.generate_report()
        
        print("\n" + "✅"*40)
        print("PIPELINE COMPLETED SUCCESSFULLY!")
        print("✅"*40 + "\n")
        
        return self


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

def example_usage():
    """
    Example usage of the pipeline
    """
    
    # Example 1: With CSV file
    pipeline = DataAnalysisPipeline(
        data_path='your_data.csv',
        target_column='temperature'  # or 'grms', or whatever your target is
    )
    pipeline.run_complete_pipeline()
    
    # Example 2: With DataFrame
    # df = pd.read_csv('your_data.csv')
    # pipeline = DataAnalysisPipeline(
    #     df=df,
    #     target_column='temperature'
    # )
    # pipeline.run_complete_pipeline()
    
    # Example 3: Step-by-step (more control)
    # pipeline = DataAnalysisPipeline(data_path='your_data.csv', target_column='temperature')
    # pipeline.load_data()
    # pipeline.detect_time_column()
    # pipeline.assess_data_quality()
    # pipeline.visualize_distributions()
    # ... etc


if __name__ == "__main__":
    print(__doc__)
    print("\nTo use this pipeline, create an instance and call run_complete_pipeline():")
    print("\nExample:")
    print("  pipeline = DataAnalysisPipeline(data_path='data.csv', target_column='temperature')")
    print("  pipeline.run_complete_pipeline()")
