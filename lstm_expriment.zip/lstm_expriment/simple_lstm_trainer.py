"""
SIMPLIFIED LSTM TRAINING SCRIPT
================================

Easy to use script for LSTM temperature prediction.
Just modify the data loading section and run!

Author: Aircraft Temperature Prediction
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import json
import os
from datetime import datetime

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Bidirectional, GRU
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

# Disable GPU if causing issues
# os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

# Set random seeds
np.random.seed(42)
tf.random.set_seed(42)


# ============================================================================
# CONFIGURATION - MODIFY THIS SECTION
# ============================================================================

class Config:
    """
    Configuration for the experiment
    Modify these parameters to experiment
    """
    
    # Data paths
    OUTPUT_FOLDER = './outputs'  # Where to save models, scalers, plots
    
    # Data columns (MODIFY THESE to match your data)
    INPUT_COLUMNS = [
        'feature1', 'feature2', 'feature3', 'feature4', 
        'feature5', 'feature6', 'feature7', 'feature8',
        'feature9', 'feature10', 'feature11', 'feature12'
    ]  # Your 12 input features
    
    OUTPUT_COLUMNS = ['temp1', 'temp2', 'temp3', 'temp4']  # Your 4 outputs
    STATION_COLUMN = 'station'  # Column name for station info
    
    # Model hyperparameters - START WITH THESE
    WINDOW_SIZE = 50        # Number of past timesteps (try: 10, 20, 50, 100)
    LSTM_UNITS = 32         # Number of LSTM units (try: 16, 32, 64)
    NUM_LAYERS = 1          # Number of LSTM layers (try: 1, 2, 3)
    DROPOUT_RATE = 0.3      # Dropout rate (try: 0.0, 0.3, 0.5)
    USE_BIDIRECTIONAL = False  # Use bidirectional LSTM (try: False, True)
    USE_GRU = False         # Use GRU instead of LSTM (try: False, True)
    
    # Training hyperparameters
    LEARNING_RATE = 0.0001  # Learning rate (try: 0.00005, 0.0001, 0.0005)
    BATCH_SIZE = 64         # Batch size (try: 32, 64, 128)
    EPOCHS = 200            # Maximum epochs
    PATIENCE = 20           # Early stopping patience
    
    # Experiment name
    EXPERIMENT_NAME = f'Exp_w{WINDOW_SIZE}_u{LSTM_UNITS}_L{NUM_LAYERS}_lr{LEARNING_RATE}'


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_output_folder(folder):
    """Create output folder if it doesn't exist"""
    if not os.path.exists(folder):
        os.makedirs(folder)
        print(f"✓ Created output folder: {folder}")


def create_sequences_with_boundaries(X, y, sortie_lengths, window_size):
    """
    Create sequences without crossing sortie boundaries
    
    Parameters:
    -----------
    X : array, shape (n_samples, n_features)
    y : array, shape (n_samples, n_outputs)
    sortie_lengths : list of int
    window_size : int
    
    Returns:
    --------
    X_seq : array, shape (n_sequences, window_size, n_features)
    y_seq : array, shape (n_sequences, n_outputs)
    """
    X_seq = []
    y_seq = []
    
    start_idx = 0
    for length in sortie_lengths:
        end_idx = start_idx + length
        
        X_sortie = X[start_idx:end_idx]
        y_sortie = y[start_idx:end_idx]
        
        # Create sequences within this sortie
        for i in range(window_size, len(X_sortie)):
            X_seq.append(X_sortie[i-window_size:i])
            y_seq.append(y_sortie[i])
        
        start_idx = end_idx
    
    return np.array(X_seq), np.array(y_seq)


def build_model(window_size, n_features, n_outputs, config):
    """
    Build LSTM/GRU model based on config
    """
    model = Sequential()
    
    # Choose RNN type
    RNN_Layer = GRU if config.USE_GRU else LSTM
    rnn_name = "GRU" if config.USE_GRU else "LSTM"
    
    # Build layers
    for i in range(config.NUM_LAYERS):
        return_sequences = (i < config.NUM_LAYERS - 1)  # True for all except last
        
        if i == 0:
            # First layer
            if config.USE_BIDIRECTIONAL:
                model.add(Bidirectional(
                    RNN_Layer(config.LSTM_UNITS, return_sequences=return_sequences),
                    input_shape=(window_size, n_features)
                ))
            else:
                model.add(RNN_Layer(
                    config.LSTM_UNITS, 
                    return_sequences=return_sequences,
                    input_shape=(window_size, n_features)
                ))
        else:
            # Subsequent layers
            if config.USE_BIDIRECTIONAL:
                model.add(Bidirectional(
                    RNN_Layer(config.LSTM_UNITS, return_sequences=return_sequences)
                ))
            else:
                model.add(RNN_Layer(
                    config.LSTM_UNITS,
                    return_sequences=return_sequences
                ))
        
        # Add dropout after each RNN layer
        if config.DROPOUT_RATE > 0:
            model.add(Dropout(config.DROPOUT_RATE))
    
    # Output layer
    model.add(Dense(n_outputs))
    
    # Compile
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=config.LEARNING_RATE),
        loss='mse',
        metrics=['mae']
    )
    
    return model


def plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred, 
                 metrics, config, save_path):
    """
    Plot results: training history + all 4 outputs in single column
    """
    fig = plt.figure(figsize=(16, 18))
    
    # Create 6 rows: 2 for training history, 4 for outputs
    
    # Row 1: Loss
    ax1 = plt.subplot(6, 1, 1)
    ax1.plot(history.history['loss'], label='Train Loss', linewidth=2)
    ax1.plot(history.history['val_loss'], label='Val Loss', linewidth=2)
    ax1.set_xlabel('Epoch', fontsize=11)
    ax1.set_ylabel('Loss (MSE)', fontsize=11)
    ax1.set_title('Training History - Loss', fontsize=13, fontweight='bold')
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)
    
    # Row 2: MAE
    ax2 = plt.subplot(6, 1, 2)
    ax2.plot(history.history['mae'], label='Train MAE', linewidth=2)
    ax2.plot(history.history['val_mae'], label='Val MAE', linewidth=2)
    ax2.set_xlabel('Epoch', fontsize=11)
    ax2.set_ylabel('MAE', fontsize=11)
    ax2.set_title('Training History - MAE', fontsize=13, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)
    
    # Rows 3-6: Test predictions for each output (LINE PLOTS)
    n_samples = min(1000, len(y_test_true))  # Plot first 1000 samples
    
    for i in range(4):
        ax = plt.subplot(6, 1, 3 + i)
        
        # Plot as line plots (not scatter)
        ax.plot(y_test_true[:n_samples, i], 
                label='Actual', 
                linewidth=1.5, 
                alpha=0.8,
                color='blue')
        ax.plot(y_test_pred[:n_samples, i], 
                label='Predicted', 
                linewidth=1.5, 
                alpha=0.8,
                color='red')
        
        # Add R² to title
        r2 = metrics['test']['r2'][i]
        rmse = metrics['test']['rmse'][i]
        
        ax.set_title(f'Output {i+1} - Test Predictions (R²={r2:.3f}, RMSE={rmse:.3f})', 
                    fontsize=12, fontweight='bold')
        ax.set_xlabel('Sample Index', fontsize=10)
        ax.set_ylabel('Temperature', fontsize=10)
        ax.legend(fontsize=9, loc='upper right')
        ax.grid(True, alpha=0.3)
    
    # Overall title
    fig.suptitle(f'{config.EXPERIMENT_NAME}\n' + 
                f'Train R²={metrics["train"]["r2_avg"]:.3f} | ' +
                f'Test R²={metrics["test"]["r2_avg"]:.3f} | ' +
                f'Gap={metrics["gap"]:.3f}',
                fontsize=14, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 1, 0.99])
    
    # Save
    plot_path = os.path.join(save_path, f'{config.EXPERIMENT_NAME}_results.png')
    plt.savefig(plot_path, dpi=150, bbox_inches='tight')
    print(f"\n✓ Plot saved: {plot_path}")
    plt.close()


def evaluate_model(model, X_train, y_train, X_test, y_test, scaler_y):
    """
    Evaluate model and return metrics
    """
    # Predictions (scaled)
    y_train_pred_scaled = model.predict(X_train, verbose=0)
    y_test_pred_scaled = model.predict(X_test, verbose=0)
    
    # Inverse transform to original scale
    y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled)
    y_train_true = scaler_y.inverse_transform(y_train)
    
    y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled)
    y_test_true = scaler_y.inverse_transform(y_test)
    
    # Calculate metrics for each output
    metrics = {
        'train': {'r2': [], 'rmse': [], 'mae': []},
        'test': {'r2': [], 'rmse': [], 'mae': []}
    }
    
    for i in range(y_train.shape[1]):
        # Training
        train_r2 = r2_score(y_train_true[:, i], y_train_pred[:, i])
        train_rmse = np.sqrt(mean_squared_error(y_train_true[:, i], y_train_pred[:, i]))
        train_mae = mean_absolute_error(y_train_true[:, i], y_train_pred[:, i])
        
        metrics['train']['r2'].append(train_r2)
        metrics['train']['rmse'].append(train_rmse)
        metrics['train']['mae'].append(train_mae)
        
        # Test
        test_r2 = r2_score(y_test_true[:, i], y_test_pred[:, i])
        test_rmse = np.sqrt(mean_squared_error(y_test_true[:, i], y_test_pred[:, i]))
        test_mae = mean_absolute_error(y_test_true[:, i], y_test_pred[:, i])
        
        metrics['test']['r2'].append(test_r2)
        metrics['test']['rmse'].append(test_rmse)
        metrics['test']['mae'].append(test_mae)
    
    # Average metrics
    metrics['train']['r2_avg'] = np.mean(metrics['train']['r2'])
    metrics['test']['r2_avg'] = np.mean(metrics['test']['r2'])
    metrics['gap'] = metrics['train']['r2_avg'] - metrics['test']['r2_avg']
    
    return metrics, y_train_pred, y_test_pred, y_train_true, y_test_true


def save_model_and_scalers(model, scaler_X, scaler_y, config, save_path):
    """
    Save Keras model (.keras format) and scalers (pickle)
    """
    # Save model in Keras format
    model_path = os.path.join(save_path, f'{config.EXPERIMENT_NAME}_model.keras')
    model.save(model_path)
    print(f"✓ Model saved: {model_path}")
    
    # Save scalers
    scaler_X_path = os.path.join(save_path, f'{config.EXPERIMENT_NAME}_scaler_X.pkl')
    scaler_y_path = os.path.join(save_path, f'{config.EXPERIMENT_NAME}_scaler_y.pkl')
    
    with open(scaler_X_path, 'wb') as f:
        pickle.dump(scaler_X, f)
    print(f"✓ Input scaler saved: {scaler_X_path}")
    
    with open(scaler_y_path, 'wb') as f:
        pickle.dump(scaler_y, f)
    print(f"✓ Output scaler saved: {scaler_y_path}")


def save_metrics(metrics, config, save_path):
    """
    Save metrics to JSON
    """
    results = {
        'experiment': config.EXPERIMENT_NAME,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'config': {
            'window_size': config.WINDOW_SIZE,
            'lstm_units': config.LSTM_UNITS,
            'num_layers': config.NUM_LAYERS,
            'dropout_rate': config.DROPOUT_RATE,
            'use_bidirectional': config.USE_BIDIRECTIONAL,
            'use_gru': config.USE_GRU,
            'learning_rate': config.LEARNING_RATE,
            'batch_size': config.BATCH_SIZE,
        },
        'metrics': {
            'train_r2_avg': float(metrics['train']['r2_avg']),
            'test_r2_avg': float(metrics['test']['r2_avg']),
            'gap': float(metrics['gap']),
            'train_r2_per_output': [float(x) for x in metrics['train']['r2']],
            'test_r2_per_output': [float(x) for x in metrics['test']['r2']],
            'train_rmse': [float(x) for x in metrics['train']['rmse']],
            'test_rmse': [float(x) for x in metrics['test']['rmse']],
            'train_mae': [float(x) for x in metrics['train']['mae']],
            'test_mae': [float(x) for x in metrics['test']['mae']]
        }
    }
    
    metrics_path = os.path.join(save_path, f'{config.EXPERIMENT_NAME}_metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(results, f, indent=4)
    print(f"✓ Metrics saved: {metrics_path}")


def print_results(metrics):
    """
    Print results to console
    """
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    
    print(f"\n📊 Overall Metrics:")
    print(f"  Train R² (avg): {metrics['train']['r2_avg']:.4f}")
    print(f"  Test R² (avg):  {metrics['test']['r2_avg']:.4f}")
    print(f"  Gap:            {metrics['gap']:.4f}")
    
    print(f"\n📈 Per-Output Test Performance:")
    for i in range(len(metrics['test']['r2'])):
        print(f"  Output {i+1}: R²={metrics['test']['r2'][i]:.4f}, " +
              f"RMSE={metrics['test']['rmse'][i]:.4f}, " +
              f"MAE={metrics['test']['mae'][i]:.4f}")
    
    # Diagnosis
    print(f"\n🔍 Diagnosis:")
    if metrics['test']['r2_avg'] < 0:
        print("  ❌ CRITICAL: Negative test R²!")
        print("     → Check data loading and scaling")
        print("     → Try smaller window size (10, 20)")
        print("     → Use simpler model")
    elif metrics['gap'] > 0.2:
        print("  ⚠️  WARNING: Large train-test gap (overfitting)")
        print("     → Increase dropout")
        print("     → Reduce model complexity")
        print("     → Reduce window size")
    elif metrics['test']['r2_avg'] > 0.7:
        print("  ✅ EXCELLENT: Good test performance!")
    elif metrics['test']['r2_avg'] > 0.5:
        print("  ✓  GOOD: Reasonable performance")
        print("     → Can try more complex models")
    else:
        print("  ⚠️  MODERATE: Room for improvement")
        print("     → Try different window sizes")
        print("     → Adjust learning rate")


# ============================================================================
# MAIN TRAINING FUNCTION
# ============================================================================

def train_model(train_data, test_data, train_sortie_lengths, test_sortie_lengths, config):
    """
    Main training function
    
    Parameters:
    -----------
    train_data : DataFrame
        Combined training data from all sorties
    test_data : DataFrame
        Combined test data
    train_sortie_lengths : list of int
        Length of each training sortie
    test_sortie_lengths : list of int
        Length of each test sortie
    config : Config object
        Configuration parameters
    """
    
    print("\n" + "="*80)
    print(f"TRAINING: {config.EXPERIMENT_NAME}")
    print("="*80)
    
    # Create output folder
    create_output_folder(config.OUTPUT_FOLDER)
    
    # ========================================================================
    # STEP 1: PREPARE DATA
    # ========================================================================
    
    print("\n📊 Step 1: Preparing data...")
    
    # Extract features and targets
    X_train = train_data[config.INPUT_COLUMNS].values
    y_train = train_data[config.OUTPUT_COLUMNS].values
    
    X_test = test_data[config.INPUT_COLUMNS].values
    y_test = test_data[config.OUTPUT_COLUMNS].values
    
    print(f"  X_train shape: {X_train.shape}")
    print(f"  y_train shape: {y_train.shape}")
    print(f"  X_test shape: {X_test.shape}")
    print(f"  y_test shape: {y_test.shape}")
    
    # ========================================================================
    # STEP 2: SCALE DATA
    # ========================================================================
    
    print("\n📏 Step 2: Scaling data...")
    
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    # Fit on training data ONLY
    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)
    
    # Transform test data (no fitting!)
    X_test_scaled = scaler_X.transform(X_test)
    y_test_scaled = scaler_y.transform(y_test)
    
    print(f"  X_train_scaled mean: {X_train_scaled.mean(axis=0)[:3]}... (should be ≈ 0)")
    print(f"  X_train_scaled std: {X_train_scaled.std(axis=0)[:3]}... (should be ≈ 1)")
    
    # ========================================================================
    # STEP 3: ADD STATION INFORMATION (OPTIONAL)
    # ========================================================================
    
    if config.STATION_COLUMN in train_data.columns:
        print("\n🏢 Step 3: Adding station information...")
        
        from sklearn.preprocessing import OneHotEncoder
        
        # Get unique stations
        all_stations = pd.concat([
            train_data[config.STATION_COLUMN],
            test_data[config.STATION_COLUMN]
        ]).unique()
        
        encoder = OneHotEncoder(sparse=False)
        encoder.fit(all_stations.reshape(-1, 1))
        
        # Encode
        train_station = encoder.transform(train_data[config.STATION_COLUMN].values.reshape(-1, 1))
        test_station = encoder.transform(test_data[config.STATION_COLUMN].values.reshape(-1, 1))
        
        # Concatenate
        X_train_scaled = np.concatenate([X_train_scaled, train_station], axis=1)
        X_test_scaled = np.concatenate([X_test_scaled, test_station], axis=1)
        
        print(f"  Added {len(all_stations)} station features")
        print(f"  New X_train_scaled shape: {X_train_scaled.shape}")
    
    # ========================================================================
    # STEP 4: CREATE SEQUENCES
    # ========================================================================
    
    print(f"\n🔢 Step 4: Creating sequences (window={config.WINDOW_SIZE})...")
    
    X_train_seq, y_train_seq = create_sequences_with_boundaries(
        X_train_scaled, y_train_scaled, train_sortie_lengths, config.WINDOW_SIZE
    )
    
    X_test_seq, y_test_seq = create_sequences_with_boundaries(
        X_test_scaled, y_test_scaled, test_sortie_lengths, config.WINDOW_SIZE
    )
    
    print(f"  X_train_seq shape: {X_train_seq.shape}")
    print(f"  y_train_seq shape: {y_train_seq.shape}")
    print(f"  X_test_seq shape: {X_test_seq.shape}")
    print(f"  y_test_seq shape: {y_test_seq.shape}")
    
    n_features = X_train_seq.shape[2]
    n_outputs = y_train_seq.shape[1]
    
    # ========================================================================
    # STEP 5: BUILD MODEL
    # ========================================================================
    
    print(f"\n🏗️  Step 5: Building model...")
    
    model = build_model(config.WINDOW_SIZE, n_features, n_outputs, config)
    
    print("\nModel Architecture:")
    model.summary()
    
    # ========================================================================
    # STEP 6: TRAIN MODEL
    # ========================================================================
    
    print(f"\n🚀 Step 6: Training model...")
    print(f"  Learning rate: {config.LEARNING_RATE}")
    print(f"  Batch size: {config.BATCH_SIZE}")
    print(f"  Max epochs: {config.EPOCHS}")
    
    callbacks = [
        EarlyStopping(
            monitor='val_loss',
            patience=config.PATIENCE,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=config.PATIENCE // 2,
            min_lr=1e-7,
            verbose=1
        )
    ]
    
    history = model.fit(
        X_train_seq, y_train_seq,
        batch_size=config.BATCH_SIZE,
        epochs=config.EPOCHS,
        validation_split=0.2,
        callbacks=callbacks,
        verbose=1
    )
    
    # ========================================================================
    # STEP 7: EVALUATE
    # ========================================================================
    
    print(f"\n📊 Step 7: Evaluating...")
    
    metrics, y_train_pred, y_test_pred, y_train_true, y_test_true = evaluate_model(
        model, X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y
    )
    
    print_results(metrics)
    
    # ========================================================================
    # STEP 8: SAVE EVERYTHING
    # ========================================================================
    
    print(f"\n💾 Step 8: Saving results...")
    
    # Save model and scalers
    save_model_and_scalers(model, scaler_X, scaler_y, config, config.OUTPUT_FOLDER)
    
    # Save metrics
    save_metrics(metrics, config, config.OUTPUT_FOLDER)
    
    # Plot and save
    plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred,
                 metrics, config, config.OUTPUT_FOLDER)
    
    print("\n" + "="*80)
    print("✅ TRAINING COMPLETE!")
    print("="*80)
    
    return model, scaler_X, scaler_y, metrics


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

def example_usage():
    """
    Example of how to use this script
    Replace with your actual data loading
    """
    
    print("\n" + "="*80)
    print("EXAMPLE USAGE - REPLACE WITH YOUR DATA LOADING")
    print("="*80)
    
    # ========================================================================
    # LOAD YOUR DATA HERE
    # ========================================================================
    
    """
    # Example: Load from CSV files
    sortie1_stn5 = pd.read_csv('sortie1_stn5.csv')
    sortie2_stn5 = pd.read_csv('sortie2_stn5.csv')
    sortie3_stn1 = pd.read_csv('sortie3_stn1.csv')
    
    test_stn1 = pd.read_csv('test_stn1.csv')
    test_stn6 = pd.read_csv('test_stn6.csv')
    
    # Add station column if not already there
    sortie1_stn5['station'] = 5
    sortie2_stn5['station'] = 5
    sortie3_stn1['station'] = 1
    test_stn1['station'] = 1
    test_stn6['station'] = 6
    
    # Combine
    train_data = pd.concat([sortie1_stn5, sortie2_stn5, sortie3_stn1], ignore_index=True)
    test_data = pd.concat([test_stn1, test_stn6], ignore_index=True)
    
    # Track sortie lengths
    train_sortie_lengths = [len(sortie1_stn5), len(sortie2_stn5), len(sortie3_stn1)]
    test_sortie_lengths = [len(test_stn1), len(test_stn6)]
    
    # Update Config.INPUT_COLUMNS and Config.OUTPUT_COLUMNS to match your data!
    
    # Run training
    config = Config()
    model, scaler_X, scaler_y, metrics = train_model(
        train_data, 
        test_data, 
        train_sortie_lengths, 
        test_sortie_lengths, 
        config
    )
    """
    
    print("\nPlease replace the example code above with your actual data loading!")


if __name__ == "__main__":
    example_usage()
