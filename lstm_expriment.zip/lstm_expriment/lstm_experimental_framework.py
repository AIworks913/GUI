"""
COMPLETE LSTM EXPERIMENTAL FRAMEWORK
=====================================

This file contains all architectures and hyperparameters to experiment with
for aircraft temperature prediction using FDR data.

SYSTEMATIC EXPERIMENTATION GUIDE:
1. Start with Experiment 1 (Baseline)
2. If baseline works (Test R² > 0.5), proceed to next
3. If baseline fails, try diagnostics first
4. Document results for each experiment

Data Setup:
- Input: 12 features
- Output: 4 temperature values
- Training: 3 sorties (STN5, STN5, STN1)
- Test: 2 sorties (STN1, STN6)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (
    LSTM, Bidirectional, Dense, Dropout, 
    BatchNormalization, GRU, SimpleRNN
)
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
from tensorflow.keras.regularizers import l1, l2, l1_l2
import json
from datetime import datetime

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_sequences_with_boundaries(X, y, sortie_lengths, window_size):
    """
    Create sequences without crossing sortie boundaries
    
    Parameters:
    -----------
    X : array-like, shape (n_samples, n_features)
        Input features
    y : array-like, shape (n_samples, n_outputs)
        Target values
    sortie_lengths : list of int
        Length of each sortie
    window_size : int
        Number of past time steps to use
    
    Returns:
    --------
    X_seq : array, shape (n_sequences, window_size, n_features)
    y_seq : array, shape (n_sequences, n_outputs)
    """
    X_seq = []
    y_seq = []
    
    start_idx = 0
    for length in sortie_lengths:
        end_idx = start_idx + length
        
        X_sortie = X[start_idx:end_idx]
        y_sortie = y[start_idx:end_idx]
        
        # Create sequences within this sortie
        for i in range(window_size, len(X_sortie)):
            X_seq.append(X_sortie[i-window_size:i])
            y_seq.append(y_sortie[i])
        
        start_idx = end_idx
    
    return np.array(X_seq), np.array(y_seq)


def evaluate_model(model, X_train, y_train, X_test, y_test, scaler_y):
    """
    Evaluate model and return metrics
    """
    # Predictions (scaled)
    y_train_pred_scaled = model.predict(X_train, verbose=0)
    y_test_pred_scaled = model.predict(X_test, verbose=0)
    
    # Inverse transform
    y_train_pred = scaler_y.inverse_transform(y_train_pred_scaled)
    y_train_true = scaler_y.inverse_transform(y_train)
    
    y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled)
    y_test_true = scaler_y.inverse_transform(y_test)
    
    # Calculate metrics for each output
    metrics = {
        'train': {'r2': [], 'rmse': [], 'mae': []},
        'test': {'r2': [], 'rmse': [], 'mae': []}
    }
    
    for i in range(y_train.shape[1]):
        # Training metrics
        train_r2 = r2_score(y_train_true[:, i], y_train_pred[:, i])
        train_rmse = np.sqrt(mean_squared_error(y_train_true[:, i], y_train_pred[:, i]))
        train_mae = mean_absolute_error(y_train_true[:, i], y_train_pred[:, i])
        
        metrics['train']['r2'].append(train_r2)
        metrics['train']['rmse'].append(train_rmse)
        metrics['train']['mae'].append(train_mae)
        
        # Test metrics
        test_r2 = r2_score(y_test_true[:, i], y_test_pred[:, i])
        test_rmse = np.sqrt(mean_squared_error(y_test_true[:, i], y_test_pred[:, i]))
        test_mae = mean_absolute_error(y_test_true[:, i], y_test_pred[:, i])
        
        metrics['test']['r2'].append(test_r2)
        metrics['test']['rmse'].append(test_rmse)
        metrics['test']['mae'].append(test_mae)
    
    # Average metrics
    metrics['train']['r2_avg'] = np.mean(metrics['train']['r2'])
    metrics['test']['r2_avg'] = np.mean(metrics['test']['r2'])
    metrics['gap'] = metrics['train']['r2_avg'] - metrics['test']['r2_avg']
    
    return metrics, y_train_pred, y_test_pred, y_train_true, y_test_true


def plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred, 
                 metrics, experiment_name, save_path='./'):
    """
    Plot training history and predictions
    """
    fig = plt.figure(figsize=(20, 12))
    
    # Training history
    ax1 = plt.subplot(3, 3, 1)
    ax1.plot(history.history['loss'], label='Train Loss')
    ax1.plot(history.history['val_loss'], label='Val Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.set_title('Training History - Loss')
    ax1.legend()
    ax1.grid(True)
    
    ax2 = plt.subplot(3, 3, 2)
    ax2.plot(history.history['mae'], label='Train MAE')
    ax2.plot(history.history['val_mae'], label='Val MAE')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('MAE')
    ax2.set_title('Training History - MAE')
    ax2.legend()
    ax2.grid(True)
    
    # Metrics summary
    ax3 = plt.subplot(3, 3, 3)
    ax3.axis('off')
    metrics_text = f"""
    METRICS SUMMARY
    {'='*30}
    Train R² (avg): {metrics['train']['r2_avg']:.4f}
    Test R² (avg):  {metrics['test']['r2_avg']:.4f}
    Gap:            {metrics['gap']:.4f}
    
    Train RMSE: {np.mean(metrics['train']['rmse']):.4f}
    Test RMSE:  {np.mean(metrics['test']['rmse']):.4f}
    
    Train MAE: {np.mean(metrics['train']['mae']):.4f}
    Test MAE:  {np.mean(metrics['test']['mae']):.4f}
    """
    ax3.text(0.1, 0.5, metrics_text, fontsize=10, family='monospace',
             verticalalignment='center')
    
    # Test predictions for each output
    n_samples = min(500, len(y_test_true))
    
    for i in range(4):
        ax = plt.subplot(3, 3, 4 + i)
        ax.plot(y_test_true[:n_samples, i], label='Actual', linewidth=1.5, alpha=0.7)
        ax.plot(y_test_pred[:n_samples, i], label='Predicted', linewidth=1.5, alpha=0.7)
        ax.set_title(f'Output {i+1} - Test (R²={metrics["test"]["r2"][i]:.3f})')
        ax.set_xlabel('Sample')
        ax.set_ylabel('Temperature')
        ax.legend()
        ax.grid(True, alpha=0.3)
    
    # Scatter plots for last output
    ax8 = plt.subplot(3, 3, 8)
    ax8.scatter(y_train_true[:, 0], y_train_pred[:, 0], alpha=0.3, s=10)
    ax8.plot([y_train_true[:, 0].min(), y_train_true[:, 0].max()],
             [y_train_true[:, 0].min(), y_train_true[:, 0].max()], 'r--', lw=2)
    ax8.set_xlabel('Actual')
    ax8.set_ylabel('Predicted')
    ax8.set_title('Train: Predicted vs Actual (Output 1)')
    ax8.grid(True)
    
    ax9 = plt.subplot(3, 3, 9)
    ax9.scatter(y_test_true[:, 0], y_test_pred[:, 0], alpha=0.3, s=10)
    ax9.plot([y_test_true[:, 0].min(), y_test_true[:, 0].max()],
             [y_test_true[:, 0].min(), y_test_true[:, 0].max()], 'r--', lw=2)
    ax9.set_xlabel('Actual')
    ax9.set_ylabel('Predicted')
    ax9.set_title('Test: Predicted vs Actual (Output 1)')
    ax9.grid(True)
    
    plt.suptitle(f'{experiment_name}', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_path}{experiment_name.replace(" ", "_")}.png', dpi=150, bbox_inches='tight')
    plt.close()


def save_results(experiment_name, config, metrics, save_path='./'):
    """
    Save experiment results to JSON
    """
    results = {
        'experiment': experiment_name,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'config': config,
        'metrics': {
            'train_r2_avg': float(metrics['train']['r2_avg']),
            'test_r2_avg': float(metrics['test']['r2_avg']),
            'gap': float(metrics['gap']),
            'train_r2_per_output': [float(x) for x in metrics['train']['r2']],
            'test_r2_per_output': [float(x) for x in metrics['test']['r2']],
            'train_rmse': [float(x) for x in metrics['train']['rmse']],
            'test_rmse': [float(x) for x in metrics['test']['rmse']],
            'train_mae': [float(x) for x in metrics['train']['mae']],
            'test_mae': [float(x) for x in metrics['test']['mae']]
        }
    }
    
    filename = f'{save_path}results_{experiment_name.replace(" ", "_")}.json'
    with open(filename, 'w') as f:
        json.dump(results, f, indent=4)
    
    print(f"Results saved to: {filename}")


# ============================================================================
# ARCHITECTURE DEFINITIONS
# ============================================================================

def architecture_1_baseline(window_size, n_features, n_outputs):
    """
    EXPERIMENT 1: BASELINE - Simplest possible model
    
    Purpose: Establish baseline performance
    When to use: Always start here
    """
    model = Sequential([
        LSTM(16, input_shape=(window_size, n_features)),
        Dense(n_outputs)
    ], name='Baseline_LSTM16')
    
    return model


def architecture_2_dropout(window_size, n_features, n_outputs, dropout_rate=0.3):
    """
    EXPERIMENT 2: Add Dropout for regularization
    
    Purpose: Reduce overfitting
    When to use: If baseline overfits (train R² >> test R²)
    """
    model = Sequential([
        LSTM(32, input_shape=(window_size, n_features)),
        Dropout(dropout_rate),
        Dense(n_outputs)
    ], name='LSTM32_Dropout')
    
    return model


def architecture_3_two_layers(window_size, n_features, n_outputs):
    """
    EXPERIMENT 3: Two LSTM layers
    
    Purpose: Capture more complex patterns
    When to use: If single layer plateaus at moderate performance
    """
    model = Sequential([
        LSTM(32, return_sequences=True, input_shape=(window_size, n_features)),
        Dropout(0.3),
        LSTM(16),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='LSTM32_16_TwoLayers')
    
    return model


def architecture_4_deeper(window_size, n_features, n_outputs):
    """
    EXPERIMENT 4: Three LSTM layers
    
    Purpose: Capture very complex temporal patterns
    When to use: If two layers show improvement
    Warning: High risk of overfitting
    """
    model = Sequential([
        LSTM(64, return_sequences=True, input_shape=(window_size, n_features)),
        Dropout(0.3),
        LSTM(32, return_sequences=True),
        Dropout(0.3),
        LSTM(16),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='LSTM64_32_16_ThreeLayers')
    
    return model


def architecture_5_bidirectional(window_size, n_features, n_outputs):
    """
    EXPERIMENT 5: Bidirectional LSTM
    
    Purpose: Look at future context (within window)
    When to use: If unidirectional LSTM is not enough
    Note: Doubles parameters, slower training
    """
    model = Sequential([
        Bidirectional(LSTM(32, input_shape=(window_size, n_features))),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='BiLSTM32')
    
    return model


def architecture_6_bidirectional_deep(window_size, n_features, n_outputs):
    """
    EXPERIMENT 6: Deep Bidirectional LSTM
    
    Purpose: Maximum pattern capture
    When to use: If simple bidirectional helps
    Warning: Very high capacity, needs lots of data
    """
    model = Sequential([
        Bidirectional(LSTM(64, return_sequences=True, input_shape=(window_size, n_features))),
        Dropout(0.3),
        Bidirectional(LSTM(32)),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='BiLSTM64_32_Deep')
    
    return model


def architecture_7_gru(window_size, n_features, n_outputs):
    """
    EXPERIMENT 7: GRU instead of LSTM
    
    Purpose: Faster training, fewer parameters
    When to use: If LSTM is slow or overfit
    """
    model = Sequential([
        GRU(32, input_shape=(window_size, n_features)),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='GRU32')
    
    return model


def architecture_8_gru_deep(window_size, n_features, n_outputs):
    """
    EXPERIMENT 8: Deep GRU
    
    Purpose: Complex patterns with GRU
    When to use: If simple GRU shows promise
    """
    model = Sequential([
        GRU(64, return_sequences=True, input_shape=(window_size, n_features)),
        Dropout(0.3),
        GRU(32),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='GRU64_32_Deep')
    
    return model


def architecture_9_with_batchnorm(window_size, n_features, n_outputs):
    """
    EXPERIMENT 9: LSTM with Batch Normalization
    
    Purpose: Stabilize training
    When to use: If training is unstable
    """
    model = Sequential([
        LSTM(32, return_sequences=True, input_shape=(window_size, n_features)),
        BatchNormalization(),
        Dropout(0.3),
        LSTM(16),
        BatchNormalization(),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='LSTM32_16_BatchNorm')
    
    return model


def architecture_10_l2_regularization(window_size, n_features, n_outputs):
    """
    EXPERIMENT 10: LSTM with L2 regularization
    
    Purpose: Prevent overfitting through weight penalty
    When to use: If dropout alone doesn't help
    """
    model = Sequential([
        LSTM(32, kernel_regularizer=l2(0.01), input_shape=(window_size, n_features)),
        Dropout(0.3),
        Dense(n_outputs)
    ], name='LSTM32_L2Reg')
    
    return model


# ============================================================================
# HYPERPARAMETER CONFIGURATIONS
# ============================================================================

WINDOW_SIZES = {
    'very_small': 10,    # ~0.3 seconds at 33Hz
    'small': 20,         # ~0.6 seconds
    'medium': 50,        # ~1.5 seconds
    'large': 100,        # ~3 seconds
    'very_large': 200    # ~6 seconds
}

LEARNING_RATES = {
    'very_low': 0.00001,
    'low': 0.00005,
    'medium': 0.0001,
    'high': 0.0005,
    'very_high': 0.001
}

BATCH_SIZES = {
    'small': 32,
    'medium': 64,
    'large': 128,
    'very_large': 256
}

OPTIMIZERS = {
    'adam': lambda lr: tf.keras.optimizers.Adam(learning_rate=lr),
    'rmsprop': lambda lr: tf.keras.optimizers.RMSprop(learning_rate=lr),
    'sgd': lambda lr: tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
}

LOSS_FUNCTIONS = {
    'mse': 'mse',
    'mae': 'mae',
    'huber': tf.keras.losses.Huber(),
    'logcosh': 'logcosh'
}


# ============================================================================
# EXPERIMENT RUNNER
# ============================================================================

def run_experiment(
    experiment_name,
    architecture_fn,
    X_train_seq,
    y_train_seq,
    X_test_seq,
    y_test_seq,
    scaler_y,
    window_size,
    n_features,
    n_outputs,
    # Hyperparameters
    learning_rate=0.0001,
    batch_size=64,
    epochs=200,
    optimizer_name='adam',
    loss_fn='mse',
    patience=20,
    # Optional parameters
    verbose=1,
    save_path='./'
):
    """
    Run a complete experiment with given configuration
    """
    print("\n" + "="*80)
    print(f"EXPERIMENT: {experiment_name}")
    print("="*80)
    
    # Build model
    model = architecture_fn(window_size, n_features, n_outputs)
    
    # Compile
    optimizer = OPTIMIZERS[optimizer_name](learning_rate)
    model.compile(
        optimizer=optimizer,
        loss=loss_fn,
        metrics=['mae']
    )
    
    # Print summary
    print("\nModel Architecture:")
    model.summary()
    
    # Config for saving
    config = {
        'window_size': window_size,
        'learning_rate': learning_rate,
        'batch_size': batch_size,
        'optimizer': optimizer_name,
        'loss': str(loss_fn),
        'epochs': epochs,
        'patience': patience
    }
    
    # Callbacks
    callbacks = [
        EarlyStopping(
            monitor='val_loss',
            patience=patience,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=patience//2,
            min_lr=1e-7,
            verbose=1
        )
    ]
    
    # Train
    print(f"\nTraining with:")
    print(f"  Learning Rate: {learning_rate}")
    print(f"  Batch Size: {batch_size}")
    print(f"  Optimizer: {optimizer_name}")
    print(f"  Loss: {loss_fn}")
    
    history = model.fit(
        X_train_seq, y_train_seq,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=0.2,
        callbacks=callbacks,
        verbose=verbose
    )
    
    # Evaluate
    print("\nEvaluating...")
    metrics, y_train_pred, y_test_pred, y_train_true, y_test_true = evaluate_model(
        model, X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y
    )
    
    # Print results
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    print(f"\nAverage Metrics:")
    print(f"  Train R²: {metrics['train']['r2_avg']:.4f}")
    print(f"  Test R²:  {metrics['test']['r2_avg']:.4f}")
    print(f"  Gap:      {metrics['gap']:.4f}")
    
    print(f"\nPer-Output Test R²:")
    for i, r2 in enumerate(metrics['test']['r2']):
        print(f"  Output {i+1}: {r2:.4f}")
    
    # Assess result
    if metrics['test']['r2_avg'] < 0:
        print("\n⚠️  WARNING: Negative test R² - Model is worse than baseline!")
        print("    Suggestions:")
        print("    1. Check for data issues")
        print("    2. Try simpler model")
        print("    3. Reduce window size")
        print("    4. Check scaling")
    elif metrics['gap'] > 0.2:
        print("\n⚠️  WARNING: Large train-test gap - Overfitting!")
        print("    Suggestions:")
        print("    1. Add more dropout")
        print("    2. Add regularization")
        print("    3. Use simpler model")
        print("    4. Get more training data")
    elif metrics['test']['r2_avg'] > 0.7:
        print("\n✅ EXCELLENT: Good test performance!")
    elif metrics['test']['r2_avg'] > 0.5:
        print("\n✓  GOOD: Reasonable test performance")
        print("    Can try more complex models")
    else:
        print("\n⚠️  POOR: Low test performance")
        print("    Suggestions:")
        print("    1. Check data quality")
        print("    2. Try different window sizes")
        print("    3. Check feature engineering")
    
    # Plot results
    print("\nGenerating plots...")
    plot_results(history, y_train_true, y_train_pred, y_test_true, y_test_pred,
                 metrics, experiment_name, save_path)
    
    # Save results
    save_results(experiment_name, config, metrics, save_path)
    
    print(f"\n{'='*80}")
    print(f"Experiment Complete: {experiment_name}")
    print(f"{'='*80}\n")
    
    return model, history, metrics


# ============================================================================
# SYSTEMATIC EXPERIMENTATION GUIDE
# ============================================================================

def systematic_experiments(
    X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
    window_size, n_features, n_outputs, save_path='./'
):
    """
    Run experiments in recommended order
    
    RECOMMENDED ORDER:
    
    PHASE 1: BASELINE (Always start here)
    - Experiment 1: Simplest model
    
    PHASE 2: IF OVERFITTING (Train R² >> Test R²)
    - Experiment 2: Add dropout
    - Experiment 10: Add L2 regularization
    - Try smaller window sizes
    
    PHASE 3: IF UNDERFITTING (Both train and test R² low)
    - Experiment 3: Two layers
    - Experiment 5: Bidirectional
    - Try larger window sizes
    
    PHASE 4: IF NEED MORE CAPACITY
    - Experiment 4: Three layers
    - Experiment 6: Deep bidirectional
    
    PHASE 5: ALTERNATIVES
    - Experiment 7-8: Try GRU
    - Experiment 9: Try BatchNorm
    """
    
    results_summary = []
    
    print("\n" + "🚀"*40)
    print("SYSTEMATIC EXPERIMENTATION FRAMEWORK")
    print("🚀"*40 + "\n")
    
    # ========================================================================
    # PHASE 1: BASELINE
    # ========================================================================
    
    print("\n" + "="*80)
    print("PHASE 1: BASELINE")
    print("="*80)
    
    exp1_model, exp1_history, exp1_metrics = run_experiment(
        "Exp1_Baseline",
        architecture_1_baseline,
        X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
        window_size, n_features, n_outputs,
        learning_rate=0.0001,
        batch_size=64,
        save_path=save_path
    )
    
    results_summary.append({
        'name': 'Exp1_Baseline',
        'test_r2': exp1_metrics['test']['r2_avg'],
        'gap': exp1_metrics['gap']
    })
    
    # Decision tree
    baseline_r2 = exp1_metrics['test']['r2_avg']
    baseline_gap = exp1_metrics['gap']
    
    if baseline_r2 < 0:
        print("\n" + "⚠️ "*40)
        print("CRITICAL: Baseline has negative R²!")
        print("Before proceeding, you MUST:")
        print("1. Check data loading and preprocessing")
        print("2. Verify scaling is correct")
        print("3. Check sequence creation")
        print("4. Try different window sizes (10, 20, 50)")
        print("5. Verify no data leakage")
        print("⚠️ "*40)
        
        # Try different window sizes
        print("\n\nTrying different window sizes as diagnostic...")
        for ws_name, ws_value in [('very_small', 10), ('small', 20), ('medium', 50)]:
            print(f"\n--- Testing window_size = {ws_value} ---")
            # Would need to recreate sequences here
            # This is a placeholder for the concept
        
        return results_summary
    
    # ========================================================================
    # PHASE 2: HANDLE OVERFITTING (if gap > 0.15)
    # ========================================================================
    
    if baseline_gap > 0.15:
        print("\n" + "="*80)
        print("PHASE 2: REDUCING OVERFITTING")
        print(f"Baseline gap is {baseline_gap:.4f} - trying regularization")
        print("="*80)
        
        # Try dropout
        exp2_model, exp2_history, exp2_metrics = run_experiment(
            "Exp2_WithDropout",
            architecture_2_dropout,
            X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
            window_size, n_features, n_outputs,
            learning_rate=0.0001,
            batch_size=64,
            save_path=save_path
        )
        
        results_summary.append({
            'name': 'Exp2_WithDropout',
            'test_r2': exp2_metrics['test']['r2_avg'],
            'gap': exp2_metrics['gap']
        })
        
        # Try L2 regularization
        exp10_model, exp10_history, exp10_metrics = run_experiment(
            "Exp10_L2Regularization",
            architecture_10_l2_regularization,
            X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
            window_size, n_features, n_outputs,
            learning_rate=0.0001,
            batch_size=64,
            save_path=save_path
        )
        
        results_summary.append({
            'name': 'Exp10_L2Regularization',
            'test_r2': exp10_metrics['test']['r2_avg'],
            'gap': exp10_metrics['gap']
        })
    
    # ========================================================================
    # PHASE 3: INCREASE CAPACITY (if baseline good but not great)
    # ========================================================================
    
    if 0.3 < baseline_r2 < 0.7 and baseline_gap < 0.15:
        print("\n" + "="*80)
        print("PHASE 3: INCREASING MODEL CAPACITY")
        print(f"Baseline R² is {baseline_r2:.4f} - trying more complex models")
        print("="*80)
        
        # Two layers
        exp3_model, exp3_history, exp3_metrics = run_experiment(
            "Exp3_TwoLayers",
            architecture_3_two_layers,
            X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
            window_size, n_features, n_outputs,
            learning_rate=0.0001,
            batch_size=64,
            save_path=save_path
        )
        
        results_summary.append({
            'name': 'Exp3_TwoLayers',
            'test_r2': exp3_metrics['test']['r2_avg'],
            'gap': exp3_metrics['gap']
        })
        
        # Bidirectional
        exp5_model, exp5_history, exp5_metrics = run_experiment(
            "Exp5_Bidirectional",
            architecture_5_bidirectional,
            X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
            window_size, n_features, n_outputs,
            learning_rate=0.0001,
            batch_size=64,
            save_path=save_path
        )
        
        results_summary.append({
            'name': 'Exp5_Bidirectional',
            'test_r2': exp5_metrics['test']['r2_avg'],
            'gap': exp5_metrics['gap']
        })
        
        # GRU alternative
        exp7_model, exp7_history, exp7_metrics = run_experiment(
            "Exp7_GRU",
            architecture_7_gru,
            X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
            window_size, n_features, n_outputs,
            learning_rate=0.0001,
            batch_size=64,
            save_path=save_path
        )
        
        results_summary.append({
            'name': 'Exp7_GRU',
            'test_r2': exp7_metrics['test']['r2_avg'],
            'gap': exp7_metrics['gap']
        })
    
    # ========================================================================
    # SUMMARY
    # ========================================================================
    
    print("\n" + "="*80)
    print("EXPERIMENT SUMMARY")
    print("="*80)
    
    results_df = pd.DataFrame(results_summary)
    results_df = results_df.sort_values('test_r2', ascending=False)
    
    print("\nResults sorted by Test R²:")
    print(results_df.to_string(index=False))
    
    best_exp = results_df.iloc[0]
    print(f"\n🏆 BEST MODEL: {best_exp['name']}")
    print(f"   Test R²: {best_exp['test_r2']:.4f}")
    print(f"   Gap: {best_exp['gap']:.4f}")
    
    return results_summary


# ============================================================================
# HYPERPARAMETER SEARCH
# ============================================================================

def hyperparameter_search(
    architecture_fn,
    X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
    window_size, n_features, n_outputs,
    param_grid,
    save_path='./'
):
    """
    Search over hyperparameter grid
    
    Example param_grid:
    {
        'learning_rate': [0.00001, 0.0001, 0.001],
        'batch_size': [32, 64, 128],
        'dropout_rate': [0.2, 0.3, 0.4]
    }
    """
    print("\n" + "🔍"*40)
    print("HYPERPARAMETER SEARCH")
    print("🔍"*40 + "\n")
    
    results = []
    
    # Generate all combinations
    import itertools
    keys = param_grid.keys()
    values = param_grid.values()
    
    for i, combination in enumerate(itertools.product(*values), 1):
        params = dict(zip(keys, combination))
        
        exp_name = f"HyperSearch_{i}_" + "_".join([f"{k}={v}" for k, v in params.items()])
        
        print(f"\n{'='*80}")
        print(f"Testing combination {i}: {params}")
        print(f"{'='*80}")
        
        try:
            _, _, metrics = run_experiment(
                exp_name,
                architecture_fn,
                X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
                window_size, n_features, n_outputs,
                **params,
                verbose=0,
                save_path=save_path
            )
            
            results.append({
                **params,
                'test_r2': metrics['test']['r2_avg'],
                'gap': metrics['gap']
            })
            
        except Exception as e:
            print(f"❌ Error with combination {params}: {str(e)}")
            continue
    
    # Summary
    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values('test_r2', ascending=False)
    
    print("\n" + "="*80)
    print("HYPERPARAMETER SEARCH RESULTS")
    print("="*80)
    print(results_df)
    
    best_params = results_df.iloc[0].to_dict()
    print(f"\n🏆 BEST HYPERPARAMETERS:")
    for k, v in best_params.items():
        print(f"   {k}: {v}")
    
    return results_df


# ============================================================================
# MAIN TEMPLATE
# ============================================================================

def main():
    """
    MAIN EXECUTION TEMPLATE
    
    Replace the data loading section with your actual data loading code
    """
    
    print("\n" + "="*80)
    print("LSTM TEMPERATURE PREDICTION - EXPERIMENTAL FRAMEWORK")
    print("="*80 + "\n")
    
    # ========================================================================
    # STEP 1: LOAD YOUR DATA
    # ========================================================================
    
    print("Step 1: Loading data...")
    
    # TODO: Replace with your actual data loading
    """
    # Example:
    sortie1_stn5 = pd.read_csv('sortie1_stn5.csv')
    sortie2_stn5 = pd.read_csv('sortie2_stn5.csv')
    sortie3_stn1 = pd.read_csv('sortie3_stn1.csv')
    test_stn1 = pd.read_csv('test_stn1.csv')
    test_stn6 = pd.read_csv('test_stn6.csv')
    
    # Add station labels
    sortie1_stn5['station'] = 5
    sortie2_stn5['station'] = 5
    sortie3_stn1['station'] = 1
    test_stn1['station'] = 1
    test_stn6['station'] = 6
    
    # Combine
    train_data = pd.concat([sortie1_stn5, sortie2_stn5, sortie3_stn1], ignore_index=True)
    test_data = pd.concat([test_stn1, test_stn6], ignore_index=True)
    
    train_sortie_lengths = [len(sortie1_stn5), len(sortie2_stn5), len(sortie3_stn1)]
    test_sortie_lengths = [len(test_stn1), len(test_stn6)]
    """
    
    # Placeholder - replace with actual data
    print("⚠️  Using placeholder data. Replace with actual data loading!")
    
    # ========================================================================
    # STEP 2: SCALE DATA
    # ========================================================================
    
    print("\nStep 2: Scaling data...")
    
    # TODO: Replace with your actual column names
    """
    input_cols = ['feature1', 'feature2', ..., 'feature12']
    output_cols = ['temp1', 'temp2', 'temp3', 'temp4']
    
    X_train = train_data[input_cols].values
    y_train = train_data[output_cols].values
    X_test = test_data[input_cols].values
    y_test = test_data[output_cols].values
    
    # Scale
    scaler_X = StandardScaler()
    scaler_y = StandardScaler()
    
    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)
    X_test_scaled = scaler_X.transform(X_test)
    y_test_scaled = scaler_y.transform(y_test)
    
    # Add station info (one-hot encoded)
    encoder = OneHotEncoder(sparse=False)
    encoder.fit([[1], [5], [6]])
    
    train_station = encoder.transform(train_data[['station']].values)
    test_station = encoder.transform(test_data[['station']].values)
    
    X_train_scaled = np.concatenate([X_train_scaled, train_station], axis=1)
    X_test_scaled = np.concatenate([X_test_scaled, test_station], axis=1)
    """
    
    # ========================================================================
    # STEP 3: CREATE SEQUENCES
    # ========================================================================
    
    print("\nStep 3: Creating sequences...")
    
    # Choose window size
    WINDOW_SIZE = 50  # Start with this
    
    """
    X_train_seq, y_train_seq = create_sequences_with_boundaries(
        X_train_scaled, y_train_scaled, train_sortie_lengths, WINDOW_SIZE
    )
    
    X_test_seq, y_test_seq = create_sequences_with_boundaries(
        X_test_scaled, y_test_scaled, test_sortie_lengths, WINDOW_SIZE
    )
    
    n_features = X_train_seq.shape[2]  # Should be 15 (12 + 3 station)
    n_outputs = 4
    
    print(f"X_train_seq shape: {X_train_seq.shape}")
    print(f"y_train_seq shape: {y_train_seq.shape}")
    print(f"X_test_seq shape: {X_test_seq.shape}")
    print(f"y_test_seq shape: {y_test_seq.shape}")
    """
    
    # ========================================================================
    # STEP 4: RUN EXPERIMENTS
    # ========================================================================
    
    print("\nStep 4: Running experiments...")
    
    save_path = './experiment_results/'
    
    """
    # Option 1: Run systematic experiments (recommended)
    results = systematic_experiments(
        X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
        WINDOW_SIZE, n_features, n_outputs, save_path
    )
    
    # Option 2: Run single experiment
    model, history, metrics = run_experiment(
        "Test_Experiment",
        architecture_1_baseline,
        X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
        WINDOW_SIZE, n_features, n_outputs,
        learning_rate=0.0001,
        batch_size=64,
        save_path=save_path
    )
    
    # Option 3: Hyperparameter search
    param_grid = {
        'learning_rate': [0.00005, 0.0001, 0.0005],
        'batch_size': [32, 64, 128]
    }
    
    results_df = hyperparameter_search(
        architecture_2_dropout,
        X_train_seq, y_train_seq, X_test_seq, y_test_seq, scaler_y,
        WINDOW_SIZE, n_features, n_outputs,
        param_grid,
        save_path
    )
    """
    
    print("\n✅ Experimental framework ready!")
    print("📝 Fill in the TODO sections with your actual data")
    print("🚀 Then run the experiments!")


if __name__ == "__main__":
    print(__doc__)
    print("\n" + "="*80)
    print("This is the experimental framework template.")
    print("Read the docstrings and fill in your data loading code.")
    print("="*80 + "\n")


# ============================================================================
# QUICK REFERENCE: WHAT TO TRY WHEN
# ============================================================================

"""
DECISION TREE FOR EXPERIMENTS:

START: Run Experiment 1 (Baseline)

├─ Test R² < 0 (NEGATIVE)?
│  ├─ YES → CRITICAL PROBLEM
│  │   ├─ Check data loading
│  │   ├─ Verify scaling (fit only on train!)
│  │   ├─ Check sequence creation (no sortie mixing)
│  │   ├─ Try window sizes: 10, 20, 50
│  │   └─ Verify no data leakage
│  │
│  └─ NO → Continue
│
├─ Train R² - Test R² > 0.2 (OVERFITTING)?
│  ├─ YES → Try:
│  │   ├─ Experiment 2: Add dropout (0.3, 0.4, 0.5)
│  │   ├─ Experiment 10: L2 regularization
│  │   ├─ Reduce window size (200 → 100 → 50)
│  │   ├─ Reduce model size (32 → 16 units)
│  │   └─ Increase batch size (64 → 128)
│  │
│  └─ NO → Continue
│
├─ Test R² < 0.5 (UNDERFITTING)?
│  ├─ YES → Try:
│  │   ├─ Experiment 3: Two layers
│  │   ├─ Experiment 5: Bidirectional
│  │   ├─ Increase window size (50 → 100 → 200)
│  │   ├─ Lower learning rate (0.0001 → 0.00005)
│  │   └─ Train longer (more epochs)
│  │
│  └─ NO → Model is good!
│
└─ Test R² > 0.5 and Gap < 0.15?
   └─ GOOD! Try to improve further:
       ├─ Experiment 4: Three layers
       ├─ Experiment 6: Deep bidirectional
       ├─ Experiment 7-8: Try GRU
       ├─ Hyperparameter tuning
       └─ Ensemble methods

HYPERPARAMETER TUNING PRIORITY:
1. Window size (MOST IMPORTANT)
2. Learning rate
3. Dropout rate
4. Batch size
5. Architecture complexity
6. Optimizer choice
7. Loss function

WINDOW SIZE GUIDELINES:
- Start with 50 (1.5 seconds at 33Hz)
- If underfitting: increase (100, 200)
- If overfitting: decrease (20, 10)
- If unstable: try multiple and compare

LEARNING RATE GUIDELINES:
- Start with 0.0001
- If loss fluctuates: decrease (0.00005, 0.00001)
- If learning too slow: increase (0.0005)
- Use ReduceLROnPlateau callback

BATCH SIZE GUIDELINES:
- Start with 64
- If overfitting: increase (128, 256)
- If underfitting: decrease (32)
- Larger batches = more stable but less frequent updates

DROPOUT RATE GUIDELINES:
- Start with 0.3
- If overfitting: increase (0.4, 0.5)
- If underfitting: decrease (0.2, 0.1)
- Don't go above 0.5 (information loss)
"""
