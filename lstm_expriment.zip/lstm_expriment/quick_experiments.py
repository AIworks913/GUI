"""
QUICK EXPERIMENT RUNNER
========================

Run multiple experiments with different configurations easily
"""

from simple_lstm_trainer import Config, train_model
import pandas as pd


def run_window_size_experiments(train_data, test_data, train_sortie_lengths, test_sortie_lengths):
    """
    Experiment 1: Try different window sizes
    
    This is the MOST IMPORTANT parameter to tune!
    """
    print("\n" + "🔬"*40)
    print("EXPERIMENT: WINDOW SIZE COMPARISON")
    print("🔬"*40)
    
    window_sizes = [10, 20, 50, 100, 200]
    results = []
    
    for window_size in window_sizes:
        print(f"\n{'='*80}")
        print(f"Testing window_size = {window_size}")
        print(f"{'='*80}")
        
        # Create config
        config = Config()
        config.WINDOW_SIZE = window_size
        config.LSTM_UNITS = 32
        config.NUM_LAYERS = 1
        config.DROPOUT_RATE = 0.3
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = f'WindowSize_{window_size}'
        
        try:
            # Train
            model, scaler_X, scaler_y, metrics = train_model(
                train_data, test_data, 
                train_sortie_lengths, test_sortie_lengths,
                config
            )
            
            results.append({
                'window_size': window_size,
                'test_r2': metrics['test']['r2_avg'],
                'gap': metrics['gap']
            })
            
        except Exception as e:
            print(f"❌ Error with window_size={window_size}: {str(e)}")
            results.append({
                'window_size': window_size,
                'test_r2': None,
                'gap': None
            })
    
    # Summary
    print("\n" + "="*80)
    print("WINDOW SIZE EXPERIMENT SUMMARY")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    print(results_df)
    
    best = results_df.loc[results_df['test_r2'].idxmax()]
    print(f"\n🏆 BEST: window_size={best['window_size']}, Test R²={best['test_r2']:.4f}")
    
    return results_df


def run_architecture_experiments(train_data, test_data, train_sortie_lengths, test_sortie_lengths,
                                 best_window_size=50):
    """
    Experiment 2: Try different architectures
    
    Run this AFTER finding best window size
    """
    print("\n" + "🔬"*40)
    print("EXPERIMENT: ARCHITECTURE COMPARISON")
    print("🔬"*40)
    
    architectures = [
        {'name': 'Simple_LSTM16', 'units': 16, 'layers': 1, 'dropout': 0.0, 'bidirectional': False},
        {'name': 'LSTM32_Dropout', 'units': 32, 'layers': 1, 'dropout': 0.3, 'bidirectional': False},
        {'name': 'LSTM32x2', 'units': 32, 'layers': 2, 'dropout': 0.3, 'bidirectional': False},
        {'name': 'BiLSTM32', 'units': 32, 'layers': 1, 'dropout': 0.3, 'bidirectional': True},
        {'name': 'GRU32', 'units': 32, 'layers': 1, 'dropout': 0.3, 'bidirectional': False, 'use_gru': True},
    ]
    
    results = []
    
    for arch in architectures:
        print(f"\n{'='*80}")
        print(f"Testing {arch['name']}")
        print(f"{'='*80}")
        
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.LSTM_UNITS = arch['units']
        config.NUM_LAYERS = arch['layers']
        config.DROPOUT_RATE = arch['dropout']
        config.USE_BIDIRECTIONAL = arch.get('bidirectional', False)
        config.USE_GRU = arch.get('use_gru', False)
        config.LEARNING_RATE = 0.0001
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = arch['name']
        
        try:
            model, scaler_X, scaler_y, metrics = train_model(
                train_data, test_data,
                train_sortie_lengths, test_sortie_lengths,
                config
            )
            
            results.append({
                'architecture': arch['name'],
                'test_r2': metrics['test']['r2_avg'],
                'gap': metrics['gap']
            })
            
        except Exception as e:
            print(f"❌ Error with {arch['name']}: {str(e)}")
            results.append({
                'architecture': arch['name'],
                'test_r2': None,
                'gap': None
            })
    
    # Summary
    print("\n" + "="*80)
    print("ARCHITECTURE EXPERIMENT SUMMARY")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    print(results_df)
    
    best = results_df.loc[results_df['test_r2'].idxmax()]
    print(f"\n🏆 BEST: {best['architecture']}, Test R²={best['test_r2']:.4f}")
    
    return results_df


def run_learning_rate_experiments(train_data, test_data, train_sortie_lengths, test_sortie_lengths,
                                  best_window_size=50):
    """
    Experiment 3: Try different learning rates
    """
    print("\n" + "🔬"*40)
    print("EXPERIMENT: LEARNING RATE COMPARISON")
    print("🔬"*40)
    
    learning_rates = [0.00005, 0.0001, 0.0005, 0.001]
    results = []
    
    for lr in learning_rates:
        print(f"\n{'='*80}")
        print(f"Testing learning_rate = {lr}")
        print(f"{'='*80}")
        
        config = Config()
        config.WINDOW_SIZE = best_window_size
        config.LSTM_UNITS = 32
        config.NUM_LAYERS = 1
        config.DROPOUT_RATE = 0.3
        config.LEARNING_RATE = lr
        config.BATCH_SIZE = 64
        config.EXPERIMENT_NAME = f'LR_{lr}'
        
        try:
            model, scaler_X, scaler_y, metrics = train_model(
                train_data, test_data,
                train_sortie_lengths, test_sortie_lengths,
                config
            )
            
            results.append({
                'learning_rate': lr,
                'test_r2': metrics['test']['r2_avg'],
                'gap': metrics['gap']
            })
            
        except Exception as e:
            print(f"❌ Error with lr={lr}: {str(e)}")
            results.append({
                'learning_rate': lr,
                'test_r2': None,
                'gap': None
            })
    
    # Summary
    print("\n" + "="*80)
    print("LEARNING RATE EXPERIMENT SUMMARY")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    print(results_df)
    
    best = results_df.loc[results_df['test_r2'].idxmax()]
    print(f"\n🏆 BEST: lr={best['learning_rate']}, Test R²={best['test_r2']:.4f}")
    
    return results_df


def run_single_quick_test(train_data, test_data, train_sortie_lengths, test_sortie_lengths):
    """
    Quick single test with recommended settings
    
    Use this to quickly check if everything is working
    """
    print("\n" + "⚡"*40)
    print("QUICK TEST WITH RECOMMENDED SETTINGS")
    print("⚡"*40)
    
    config = Config()
    config.WINDOW_SIZE = 50          # Reasonable default
    config.LSTM_UNITS = 32           # Moderate capacity
    config.NUM_LAYERS = 1            # Simple
    config.DROPOUT_RATE = 0.3        # Some regularization
    config.LEARNING_RATE = 0.0001    # Safe learning rate
    config.BATCH_SIZE = 64           # Standard batch size
    config.EXPERIMENT_NAME = 'QuickTest'
    
    model, scaler_X, scaler_y, metrics = train_model(
        train_data, test_data,
        train_sortie_lengths, test_sortie_lengths,
        config
    )
    
    return model, scaler_X, scaler_y, metrics


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    
    print("\n" + "="*80)
    print("QUICK EXPERIMENT RUNNER - TEMPLATE")
    print("="*80)
    
    print("""
    
How to use:

1. Load your data:
   
   train_data = pd.concat([sortie1, sortie2, sortie3])
   test_data = pd.concat([test1, test2])
   train_sortie_lengths = [len(sortie1), len(sortie2), len(sortie3)]
   test_sortie_lengths = [len(test1), len(test2)]

2. Choose an experiment to run:

   # Quick test (recommended first)
   model, scaler_X, scaler_y, metrics = run_single_quick_test(
       train_data, test_data, 
       train_sortie_lengths, test_sortie_lengths
   )
   
   # Find best window size (MOST IMPORTANT!)
   results = run_window_size_experiments(
       train_data, test_data,
       train_sortie_lengths, test_sortie_lengths
   )
   
   # Try different architectures (after finding best window)
   results = run_architecture_experiments(
       train_data, test_data,
       train_sortie_lengths, test_sortie_lengths,
       best_window_size=50  # Use best from previous step
   )
   
   # Fine-tune learning rate
   results = run_learning_rate_experiments(
       train_data, test_data,
       train_sortie_lengths, test_sortie_lengths,
       best_window_size=50
   )

All results, models, and plots are automatically saved to ./outputs/
    """)
