"""
QUICK REFERENCE: WHAT TO TRY WHEN
==================================

This is a simplified decision guide for your LSTM experiments.
"""

# ============================================================================
# PROBLEM: NEGATIVE TEST R² (Model worse than predicting mean)
# ============================================================================

"""
SYMPTOMS:
- Test R² < 0
- Very high Test MSE/MAE
- Predictions way off

ROOT CAUSES & SOLUTIONS:

1. DATA LEAKAGE IN SCALING ⚠️ MOST COMMON
   ❌ Wrong:
      scaler.fit(all_data)  # Including test data
   
   ✅ Correct:
      scaler.fit(train_data_only)  # ONLY training data
      train_scaled = scaler.transform(train_data)
      test_scaled = scaler.transform(test_data)

2. SEQUENCES CROSSING SORTIE BOUNDARIES
   - Make sure sequences don't span across different sorties
   - Use create_sequences_with_boundaries() function

3. WINDOW SIZE TOO LARGE
   Try: 10, 20, 50 (instead of 200)

4. WRONG FEATURE/TARGET COLUMNS
   - Double-check you're using correct columns
   - Print shapes and verify

IMMEDIATE ACTIONS:
1. Verify scaling code (fit only on train!)
2. Try window_size = 10
3. Use simplest model (Experiment 1: Baseline)
4. Print and inspect first few predictions
"""

# ============================================================================
# PROBLEM: OVERFITTING (Train R² >> Test R²)
# ============================================================================

"""
SYMPTOMS:
- Train R² = 0.95-0.99
- Test R² = 0.3-0.6 or negative
- Gap > 0.2
- Val loss increases after initial decrease

ROOT CAUSES & SOLUTIONS:

1. MODEL TOO COMPLEX
   Current: Bidirectional, 3-4 layers, 64 units
   Try: Simple LSTM, 1 layer, 16-32 units
   
   ✅ Use: Experiment 1 (Baseline) or Experiment 2 (+ Dropout)

2. WINDOW SIZE TOO LARGE
   Current: 200
   Try: 50, 20, 10
   
3. NO REGULARIZATION
   Add:
   - Dropout: 0.3-0.5
   - L2 regularization: 0.01
   - Early stopping (already have)

4. BATCH SIZE TOO SMALL
   Current: 256
   Try: 64, 32
   
5. TRAINING TOO LONG
   - Model memorizing training data
   - Rely on early stopping

HYPERPARAMETERS TO TRY:
┌─────────────────┬──────────────┬─────────────────┐
│ Parameter       │ Current      │ Try Instead     │
├─────────────────┼──────────────┼─────────────────┤
│ Architecture    │ BiLSTM, 3-4L │ LSTM, 1 layer   │
│ Units           │ 64           │ 16, 32          │
│ Window Size     │ 200          │ 20, 50          │
│ Dropout         │ None/Low     │ 0.3, 0.4, 0.5   │
│ Batch Size      │ 256          │ 64, 128         │
│ Learning Rate   │ 0.001        │ 0.0001          │
└─────────────────┴──────────────┴─────────────────┘

EXPERIMENTS TO RUN IN ORDER:
1. Experiment 1: Baseline (Simple LSTM, 16 units)
2. Experiment 2: Add Dropout (0.3)
3. Try window_size = 50
4. Try window_size = 20
5. Experiment 10: L2 Regularization
"""

# ============================================================================
# PROBLEM: UNDERFITTING (Both Train and Test R² Low)
# ============================================================================

"""
SYMPTOMS:
- Train R² < 0.7
- Test R² < 0.6
- Small gap between train and test
- Loss not decreasing much

ROOT CAUSES & SOLUTIONS:

1. MODEL TOO SIMPLE
   Current: 1 layer, 16 units
   Try: 2 layers, 32-64 units
   
   ✅ Use: Experiment 3 (Two Layers), Experiment 5 (Bidirectional)

2. WINDOW SIZE TOO SMALL
   Current: 10, 20
   Try: 50, 100, 200
   
3. LEARNING RATE TOO HIGH/LOW
   Try: 0.00005, 0.0001, 0.0005
   
4. NOT ENOUGH TRAINING
   - Increase epochs (100 → 200)
   - Remove early stopping or increase patience

5. MISSING IMPORTANT FEATURES
   - Check if station info is included
   - Consider feature engineering

HYPERPARAMETERS TO TRY:
┌─────────────────┬──────────────┬─────────────────┐
│ Parameter       │ Current      │ Try Instead     │
├─────────────────┼──────────────┼─────────────────┤
│ Architecture    │ LSTM, 1L     │ LSTM 2-3 layers │
│ Units           │ 16           │ 32, 64          │
│ Window Size     │ 10, 20       │ 50, 100, 200    │
│ Learning Rate   │ 0.001        │ 0.0001, 0.00005 │
│ Epochs          │ 50-100       │ 200-300         │
└─────────────────┴──────────────┴─────────────────┘

EXPERIMENTS TO RUN IN ORDER:
1. Try window_size = 100 (with baseline)
2. Experiment 3: Two Layers
3. Try window_size = 200
4. Experiment 5: Bidirectional
5. Experiment 4: Three Layers (if still underfitting)
"""

# ============================================================================
# PROBLEM: LOSS FLUCTUATIONS (Unstable Training)
# ============================================================================

"""
SYMPTOMS:
- Loss goes up and down erratically
- Val loss jumps around
- Can't converge

ROOT CAUSES & SOLUTIONS:

1. LEARNING RATE TOO HIGH ⚠️ MOST COMMON
   Current: 0.001
   Try: 0.0001, 0.00005, 0.00001
   
2. BATCH SIZE TOO LARGE
   Current: 256
   Try: 64, 32
   
3. GRADIENT EXPLODING
   Add: Gradient clipping
   
   model.compile(
       optimizer=tf.keras.optimizers.Adam(
           learning_rate=0.0001,
           clipnorm=1.0  # Add this
       ),
       ...
   )

4. BAD INITIALIZATION
   - Try different random seeds
   - Use different optimizer (RMSprop)

HYPERPARAMETERS TO TRY:
┌─────────────────┬──────────────┬─────────────────┐
│ Parameter       │ Current      │ Try Instead     │
├─────────────────┼──────────────┼─────────────────┤
│ Learning Rate   │ 0.001        │ 0.0001, 0.00005 │
│ Batch Size      │ 256          │ 64, 32          │
│ Optimizer       │ Adam         │ RMSprop         │
│ Gradient Clip   │ None         │ 1.0, 5.0        │
└─────────────────┴──────────────┴─────────────────┘

QUICK FIX:
learning_rate = 0.0001  # Reduce by 10x
batch_size = 64         # Reduce by 4x
"""

# ============================================================================
# PROBLEM: MODEL PREDICTS CONSTANT VALUE
# ============================================================================

"""
SYMPTOMS:
- All predictions are similar
- Predictions don't vary with inputs
- Flat prediction line

ROOT CAUSES & SOLUTIONS:

1. LEARNING RATE TOO LOW
   Current: 0.00001
   Try: 0.0001, 0.0005
   
2. MODEL STUCK IN LOCAL MINIMUM
   - Try different initialization
   - Increase learning rate
   - Use different optimizer

3. TARGETS NOT PROPERLY SCALED
   - Check y_train_scaled statistics
   - Should have mean ≈ 0, std ≈ 1

4. ALL OUTPUTS SAME IN TRAINING DATA
   - Verify training data has variation
   - Check if correct column selected

QUICK FIX:
- Increase learning rate to 0.0005
- Train longer (more epochs)
- Check data has actual variation
"""

# ============================================================================
# STATION (STN) GENERALIZATION PROBLEM
# ============================================================================

"""
YOUR SPECIFIC ISSUE:
- STN1 (seen in training) still performs poorly on test
- STN6 (unseen) also performs poorly
- This suggests problem is NOT just about unseen station

DIAGNOSTIC TEST:
# Separate test performance by station
test_stn1_indices = ...  # Get indices of STN1 in test
test_stn6_indices = ...  # Get indices of STN6 in test

r2_stn1 = r2_score(y_test[test_stn1_indices], y_pred[test_stn1_indices])
r2_stn6 = r2_score(y_test[test_stn6_indices], y_pred[test_stn6_indices])

print(f"Test R² on STN1 (seen): {r2_stn1:.4f}")
print(f"Test R² on STN6 (unseen): {r2_stn6:.4f}")

IF BOTH ARE BAD:
→ Problem is NOT station generalization
→ Problem is fundamental modeling issue
→ Go back to basics (check scaling, window size, architecture)

IF STN1 GOOD but STN6 BAD:
→ Problem IS station generalization
→ Solutions:
   1. Add station as feature (one-hot encode)
   2. Include STN6 in training (if possible)
   3. Use transfer learning
   4. Train separate models per station

ADDING STATION INFORMATION:
# One-hot encode
from sklearn.preprocessing import OneHotEncoder
encoder = OneHotEncoder(sparse=False)
encoder.fit([[1], [5], [6]])

# Add to features
train_station = encoder.transform(train_data[['station']])
X_train_with_stn = np.concatenate([X_train_scaled, train_station], axis=1)

# Now model knows which station each sample is from
"""

# ============================================================================
# SYSTEMATIC TROUBLESHOOTING CHECKLIST
# ============================================================================

"""
USE THIS CHECKLIST WHEN MODEL FAILS:

□ 1. CHECK DATA LOADING
   - Print first 5 rows of train and test
   - Verify shapes are correct
   - Check no NaN values

□ 2. CHECK SCALING
   - Scaler fitted ONLY on training data?
   - Print: scaler.mean_, scaler.scale_
   - After scaling: mean ≈ 0, std ≈ 1?

□ 3. CHECK SEQUENCE CREATION
   - Print first sequence: X_train_seq[0]
   - Verify it's 'window_size' consecutive samples
   - Check sequences don't cross sortie boundaries

□ 4. CHECK MODEL INPUT/OUTPUT SHAPES
   - X_train_seq.shape = (samples, window, features)
   - y_train_seq.shape = (samples, outputs)
   - Model input_shape matches X_train_seq

□ 5. CHECK ACTUAL vs PREDICTED RANGES
   - print(f"Actual range: {y_test.min()} to {y_test.max()}")
   - print(f"Predicted range: {y_pred.min()} to {y_pred.max()}")
   - Should be similar!

□ 6. CHECK INDIVIDUAL OUTPUT PERFORMANCE
   - Calculate R² for each of 4 outputs separately
   - Maybe 3 are good, 1 is bad → specific issue

□ 7. VISUALIZE PREDICTIONS
   - Plot actual vs predicted for test set
   - Look for patterns in errors
   - Are predictions lagging behind actual?

□ 8. CHECK SORTIE-WISE PERFORMANCE
   - Evaluate on each test sortie separately
   - Maybe one sortie good, one bad

□ 9. TRY SANITY CHECK MODEL
   - Train on 100 samples, test on same 100
   - Should get R² ≈ 0.99
   - If not → fundamental problem

□ 10. SIMPLIFY TO EXTREME
   - Use window_size = 1 (no temporal)
   - Use Dense network (not LSTM)
   - Should get some reasonable result
   - If not → check data itself
"""

# ============================================================================
# RECOMMENDED EXPERIMENTAL ORDER (YOUR CASE)
# ============================================================================

"""
Given your symptoms (negative R² on both seen and unseen stations):

PHASE 1: VERIFY BASICS (DO THIS FIRST!)
========================================
1. Print and manually inspect:
   - First 10 rows of X_train_scaled
   - First 10 rows of y_train_scaled
   - First sequence X_train_seq[0]
   - Scaling statistics (mean, std)

2. Sanity check:
   - Train on 500 samples, test on SAME 500 samples
   - Should get R² > 0.9
   - If not → data loading/scaling issue

3. Try extreme simplification:
   - window_size = 1
   - Simple Dense network
   - Should get R² > 0.3 at least

PHASE 2: FIND WORKING BASELINE
===============================
Try in this exact order:

Exp 1: window=10, LSTM(16), lr=0.0001, batch=64
Exp 2: window=20, LSTM(16), lr=0.0001, batch=64  
Exp 3: window=50, LSTM(16), lr=0.0001, batch=64
Exp 4: window=50, LSTM(32), lr=0.0001, batch=64
Exp 5: window=50, LSTM(32), lr=0.00005, batch=64

STOP when you get Test R² > 0.3

PHASE 3: ADD REGULARIZATION (if overfitting)
=============================================
Once you have Test R² > 0.3:

Exp 6: Add dropout=0.3
Exp 7: Add dropout=0.5
Exp 8: Try L2 regularization

PHASE 4: INCREASE CAPACITY (if underfitting)
=============================================
Once you have stable positive R²:

Exp 9: Two layers LSTM(32, 16)
Exp 10: Bidirectional LSTM(32)
Exp 11: Three layers if needed

PHASE 5: HANDLE STATION INFO
=============================
Once core model works:

Exp 12: Add station as feature (one-hot)
Exp 13: Compare performance on STN1 vs STN6
"""

# ============================================================================
# QUICK HYPERPARAMETER REFERENCE TABLE
# ============================================================================

"""
┌──────────────────┬─────────────┬──────────────┬────────────────────────┐
│ Hyperparameter   │ Start With  │ If Overfit   │ If Underfit            │
├──────────────────┼─────────────┼──────────────┼────────────────────────┤
│ Window Size      │ 50          │ Reduce: 20   │ Increase: 100, 200     │
│ LSTM Units       │ 32          │ Reduce: 16   │ Increase: 64           │
│ Layers           │ 1           │ Keep 1       │ Increase: 2, 3         │
│ Dropout          │ 0.3         │ Increase:0.5 │ Decrease: 0.1          │
│ Learning Rate    │ 0.0001      │ Same         │ Decrease: 0.00005      │
│ Batch Size       │ 64          │ Increase:128 │ Decrease: 32           │
│ Epochs           │ 100         │ Same (early) │ Increase: 200          │
└──────────────────┴─────────────┴──────────────┴────────────────────────┘

PRIORITY ORDER TO TUNE:
1. Window Size    (Most impact)
2. Architecture   (LSTM vs GRU, layers)
3. Learning Rate  (Training stability)
4. Dropout        (Regularization)
5. Batch Size     (Less critical)
"""

# ============================================================================
# EXPECTED RESULTS GUIDE
# ============================================================================

"""
WHAT GOOD RESULTS LOOK LIKE:

✅ EXCELLENT (You're done!)
- Train R²: 0.80-0.90
- Test R²: 0.75-0.85
- Gap: < 0.10
- Loss curves: Smooth, converged
- Predictions follow actual trends closely

✅ GOOD (Can try to improve)
- Train R²: 0.70-0.85
- Test R²: 0.60-0.75
- Gap: 0.10-0.15
- Loss curves: Mostly smooth
- Predictions reasonable

⚠️ ACCEPTABLE (Needs work)
- Train R²: 0.60-0.75
- Test R²: 0.45-0.60
- Gap: < 0.20
- Try increasing model capacity

❌ POOR (Major issues)
- Train R²: 0.50-0.70
- Test R²: 0.20-0.40
- Gap: > 0.20
- Fundamental problems, start over

❌ BROKEN (Critical issues)
- Test R² < 0 (negative)
- Check data loading/scaling
- Verify no data leakage
- Try extreme simplification
"""

print(__doc__)
