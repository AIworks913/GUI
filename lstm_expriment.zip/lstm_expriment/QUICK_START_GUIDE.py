"""
QUICK START GUIDE
=================

How to use the Complete Data Analysis Pipeline
"""

# ============================================================================
# METHOD 1: RUN THE DEMO (Easiest way to see how it works)
# ============================================================================

"""
Simply run the demo script:

    python demo_pipeline.py

This will:
1. Generate sample aircraft data
2. Run complete analysis
3. Create all visualizations
4. Generate a report
"""

# ============================================================================
# METHOD 2: USE WITH YOUR OWN CSV FILE
# ============================================================================

from complete_data_analysis_pipeline import DataAnalysisPipeline

# Basic usage - just provide CSV path and target column
pipeline = DataAnalysisPipeline(
    data_path='your_data.csv',
    target_column='temperature'  # Replace with your target variable name
)

# Run the complete pipeline
pipeline.run_complete_pipeline()

# That's it! It will automatically:
# - Detect if your data is time series
# - Find the time column
# - Perform all analysis
# - Create visualizations
# - Train models
# - Generate report

# ============================================================================
# METHOD 3: USE WITH EXISTING DATAFRAME
# ============================================================================

import pandas as pd
from complete_data_analysis_pipeline import DataAnalysisPipeline

# Load your data
df = pd.read_csv('your_data.csv')

# Or create it some other way
# df = your_data_loading_function()

# Create pipeline with DataFrame
pipeline = DataAnalysisPipeline(
    df=df,
    target_column='your_target_column_name'
)

# Run pipeline
pipeline.run_complete_pipeline()

# ============================================================================
# METHOD 4: STEP-BY-STEP (More Control)
# ============================================================================

from complete_data_analysis_pipeline import DataAnalysisPipeline

# Initialize
pipeline = DataAnalysisPipeline(
    data_path='your_data.csv',
    target_column='temperature'
)

# Run each phase separately if you want more control
pipeline.load_data()
pipeline.detect_time_column()
pipeline.detect_target_column()
pipeline.assess_data_quality()
pipeline.detect_outliers()
pipeline.visualize_distributions()
pipeline.visualize_time_series()
pipeline.correlation_analysis()
pipeline.scatter_matrix()

# Time series specific (if applicable)
pipeline.check_stationarity()
pipeline.decompose_time_series()
pipeline.autocorrelation_analysis()

# Feature engineering
pipeline.create_lag_features(lags=[1, 2, 3, 5, 10])
pipeline.create_time_features()

# Modeling
pipeline.prepare_data_for_modeling()
pipeline.split_data()
pipeline.train_models()
pipeline.evaluate_best_model()
pipeline.compare_models()

# Generate report
pipeline.generate_report()

# ============================================================================
# CUSTOMIZATION OPTIONS
# ============================================================================

# 1. Skip feature creation (use only original features)
pipeline.run_complete_pipeline(create_features=False)

# 2. Skip model training (just do EDA)
pipeline.run_complete_pipeline(train_models_flag=False)

# 3. Both
pipeline.run_complete_pipeline(create_features=False, train_models_flag=False)

# 4. Custom train/test split
pipeline.split_data(test_size=0.3)  # 30% test set

# 5. Force non-time-series split (random) even if time column exists
pipeline.split_data(time_series=False)

# 6. Custom lag features
pipeline.create_lag_features(lags=[1, 2, 5, 10, 20, 50])

# ============================================================================
# EXPECTED OUTPUTS
# ============================================================================

"""
After running the pipeline, you'll get:

FILES:
------
1. ANALYSIS_REPORT.txt - Comprehensive text report
2. 01_distributions.png - Histograms of all variables
3. 02_time_series_plots.png - Time series plots
4. 03_correlation_matrix.png - Correlation heatmap
5. 04_scatter_matrix.png - Scatter plot matrix
6. 05_time_series_decomposition.png - Trend/Seasonal/Residual
7. 06_autocorrelation.png - ACF/PACF plots
8. 07_feature_importance.png - Important features
9. 08_model_evaluation.png - Model diagnostics
10. 09_model_comparison.png - Model performance comparison

IN TERMINAL:
-----------
- Detailed analysis progress
- Statistical summaries
- Model performance metrics
- Insights and findings
"""

# ============================================================================
# EXAMPLE: YOUR AIRCRAFT DATA
# ============================================================================

"""
For your aircraft temperature/Grms prediction:

# If your CSV has columns: time, altitude, speed, engine_power, temperature, grms

# To predict temperature:
pipeline = DataAnalysisPipeline(
    data_path='aircraft_data.csv',
    target_column='temperature'
)
pipeline.run_complete_pipeline()

# To predict grms:
pipeline = DataAnalysisPipeline(
    data_path='aircraft_data.csv',
    target_column='grms'
)
pipeline.run_complete_pipeline()
"""

# ============================================================================
# REQUIREMENTS
# ============================================================================

"""
Required packages:
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- scipy
- statsmodels (optional but recommended for time series)

Install with:
    pip install pandas numpy matplotlib seaborn scikit-learn scipy statsmodels
"""

# ============================================================================
# TROUBLESHOOTING
# ============================================================================

"""
Q: "No target column specified"
A: Make sure to provide target_column parameter when creating the pipeline

Q: "Could not detect time column"
A: The pipeline auto-detects time columns. If yours isn't detected, manually specify it:
   pipeline.time_column = 'your_time_column_name'

Q: "Not enough data for time series analysis"
A: Some analyses need minimum data points. Try with more data or skip those analyses

Q: "Statsmodels not installed"
A: Install it: pip install statsmodels
   Or the pipeline will skip statsmodels-dependent analyses

Q: How do I access the trained models?
A: After running the pipeline:
   best_model = pipeline.trained_models[pipeline.report['best_model']]
   
Q: How do I make predictions on new data?
A: 
   # Get the best model
   model = pipeline.trained_models[pipeline.report['best_model']]
   
   # Prepare new data (same features as training)
   new_predictions = model.predict(new_data_X)
"""

# ============================================================================
# NEXT STEPS AFTER ANALYSIS
# ============================================================================

"""
1. Review ANALYSIS_REPORT.txt for key findings
2. Check all visualization plots
3. Look at feature importance to understand what drives your target
4. Review model performance metrics (R², RMSE, MAE)
5. Analyze residual plots to check for patterns
6. Decide if you need to:
   - Collect more data
   - Engineer different features
   - Try different models
   - Adjust for outliers
   - Handle non-stationarity (for time series)
"""

print(__doc__)
