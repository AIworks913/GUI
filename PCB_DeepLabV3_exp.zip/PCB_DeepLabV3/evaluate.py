"""
evaluate.py — Evaluate a trained PCB-DeepLabV3 checkpoint on the val set.

Computes the four metrics from the paper:
  mIOU, MPA (mean Pixel Accuracy), CPA (void Precision), Recall

Usage:
    python evaluate.py \
        --dataset    /path/to/dataset \
        --checkpoint ./checkpoints/best.pth
"""

import os
import argparse
import torch
from torch.utils.data import DataLoader

from nets.deeplabv3_plus import DeepLab
from datasets.seg_dataset import VOCSegDataset
from utils.metrics import SegMetrics


def get_args():
    p = argparse.ArgumentParser(description='Evaluate PCB-DeepLabV3')
    p.add_argument('--dataset',     required=True)
    p.add_argument('--checkpoint',  required=True)
    p.add_argument('--split',       default='val', choices=['train', 'val'])
    p.add_argument('--num_classes', type=int, default=2)
    p.add_argument('--input_size',  type=int, default=512)
    p.add_argument('--batch_size',  type=int, default=4)
    p.add_argument('--num_workers', type=int, default=4)
    p.add_argument('--device',      default='auto')
    return p.parse_args()


def main():
    args   = get_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') \
             if args.device == 'auto' else torch.device(args.device)

    print(f"\nLoading checkpoint: {args.checkpoint}")
    ckpt  = torch.load(args.checkpoint, map_location=device)
    model = DeepLab(num_classes=args.num_classes, pretrained=False).to(device)
    # Handle DataParallel checkpoints
    state = ckpt['model_state']
    state = {k.replace('module.', ''): v for k, v in state.items()}
    model.load_state_dict(state)
    model.eval()

    ds = VOCSegDataset(
        args.dataset,
        split      = args.split,
        input_size = (args.input_size, args.input_size),
        augment    = False,
    )
    loader = DataLoader(ds, batch_size=args.batch_size,
                        shuffle=False, num_workers=args.num_workers)

    print(f"Evaluating on {len(ds)} samples ({args.split} split)...\n")

    metrics = SegMetrics(num_classes=args.num_classes)
    with torch.no_grad():
        for images, masks, stems in loader:
            images = images.to(device)
            masks  = masks.to(device)
            preds  = model(images).argmax(dim=1)
            metrics.update(preds, masks)

    results = metrics.print_results()
    return results


if __name__ == '__main__':
    main()
