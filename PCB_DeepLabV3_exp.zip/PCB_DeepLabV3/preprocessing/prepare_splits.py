"""
prepare_splits.py — Create train.txt and val.txt split files.

Run this after (optionally) running cut_images.py.
It scans your images/ directory, matches each image to a mask in masks/,
and writes the stem names into train.txt and val.txt.

Usage:
    python preprocessing/prepare_splits.py \
        --dataset /path/to/dataset \
        --val_ratio 0.2 \
        --seed 42

Output:
    /path/to/dataset/train.txt
    /path/to/dataset/val.txt
"""

import os
import random
import argparse


def prepare_splits(dataset_root, val_ratio=0.2, seed=42):
    img_dir  = os.path.join(dataset_root, 'images')
    mask_dir = os.path.join(dataset_root, 'masks')

    if not os.path.isdir(img_dir):
        raise FileNotFoundError(f"images/ directory not found: {img_dir}")
    if not os.path.isdir(mask_dir):
        raise FileNotFoundError(f"masks/ directory not found: {mask_dir}")

    img_extensions  = {'.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp'}
    mask_extensions = {'.png', '.jpg', '.jpeg'}

    # Build set of stems with matching masks
    mask_stems = set()
    for f in os.listdir(mask_dir):
        stem, ext = os.path.splitext(f)
        if ext.lower() in mask_extensions:
            mask_stems.add(stem)

    paired_stems = []
    missing_masks = []
    for f in sorted(os.listdir(img_dir)):
        stem, ext = os.path.splitext(f)
        if ext.lower() not in img_extensions:
            continue
        if stem in mask_stems:
            paired_stems.append(stem)
        else:
            missing_masks.append(f)

    if missing_masks:
        print(f"[WARN] {len(missing_masks)} images have no matching mask and will be skipped:")
        for m in missing_masks[:5]:
            print(f"        {m}")
        if len(missing_masks) > 5:
            print(f"        ... and {len(missing_masks)-5} more")

    if len(paired_stems) == 0:
        raise ValueError("No image-mask pairs found. Check your directory names.")

    # Shuffle + split
    random.seed(seed)
    random.shuffle(paired_stems)
    n_val   = max(1, int(len(paired_stems) * val_ratio))
    n_train = len(paired_stems) - n_val
    val_stems   = paired_stems[:n_val]
    train_stems = paired_stems[n_val:]

    train_file = os.path.join(dataset_root, 'train.txt')
    val_file   = os.path.join(dataset_root, 'val.txt')

    with open(train_file, 'w') as f:
        f.write('\n'.join(train_stems) + '\n')
    with open(val_file, 'w') as f:
        f.write('\n'.join(val_stems) + '\n')

    print(f"\nDataset split complete:")
    print(f"  Total paired images : {len(paired_stems)}")
    print(f"  Training samples    : {n_train}")
    print(f"  Validation samples  : {n_val}")
    print(f"  train.txt → {train_file}")
    print(f"  val.txt   → {val_file}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create train/val split files')
    parser.add_argument('--dataset',   required=True,       help='Dataset root directory')
    parser.add_argument('--val_ratio', type=float, default=0.2,
                        help='Fraction of data for validation (default 0.2)')
    parser.add_argument('--seed',      type=int,   default=42,
                        help='Random seed (default 42)')
    args = parser.parse_args()
    prepare_splits(args.dataset, args.val_ratio, args.seed)
