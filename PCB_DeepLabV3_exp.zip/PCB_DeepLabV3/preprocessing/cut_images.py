"""
cut_images.py — Enhanced version of the paper's original script.

What it does (matching paper exactly):
  1. Crops the outer edge region from each large X-ray image
  2. Divides the remaining area into a 3×2 grid of sub-images (6 tiles)
  3. Discards tiles with NO void pixels in the mask
  4. Discards tiles where void pixels / total pixels < 5%
  Result: expands 450 images → ~4128 trainable tiles (as reported in the paper)

Changes vs the original:
  - Processes image AND mask pairs together
  - Saves mask tiles alongside image tiles
  - Configurable void threshold (default 5%)

Usage:
    python preprocessing/cut_images.py \
        --images  /path/to/original/images \
        --masks   /path/to/original/masks  \
        --out_images  /path/to/cropped/images \
        --out_masks   /path/to/cropped/masks

IMPORTANT: Only run this if your images are the large full-board X-ray scans
(like those from the Kaggle dataset). If your images are already cropped to
individual chip regions, skip this step and go straight to prepare_splits.py.
"""

import os
import argparse
import numpy as np
from PIL import Image


def cut_images(image_path, mask_path, save_img_path, save_mask_path,
               box=None, out_shape=(3, 2), void_threshold=0.05):
    """
    Crop and tile image+mask pairs, discarding tiles without sufficient voids.

    Parameters
    ----------
    image_path     : directory containing original images
    mask_path      : directory containing corresponding masks (same stem, .png)
    save_img_path  : output directory for image tiles
    save_mask_path : output directory for mask tiles
    box            : (left, top, right, bottom) crop region on original image
                     Set to None to use the full image
    out_shape      : (rows, cols) grid to divide the cropped image into
    void_threshold : minimum fraction of void pixels required to keep a tile
    """
    os.makedirs(save_img_path,  exist_ok=True)
    os.makedirs(save_mask_path, exist_ok=True)

    image_files = sorted([
        f for f in os.listdir(image_path)
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.tiff'))
    ])

    kept = 0
    discarded_empty = 0
    discarded_sparse = 0

    for fname in image_files:
        stem = os.path.splitext(fname)[0]
        img_file = os.path.join(image_path, fname)

        # Find corresponding mask
        mask_file = None
        for ext in ('.png', '.jpg', '.jpeg'):
            candidate = os.path.join(mask_path, stem + ext)
            if os.path.exists(candidate):
                mask_file = candidate
                break
        if mask_file is None:
            print(f"[WARN] No mask found for {fname}, skipping.")
            continue

        image = Image.open(img_file).convert('RGB')
        mask  = Image.open(mask_file).convert('L')

        # Optional outer-edge crop
        if box is not None:
            image = image.crop(box)
            mask  = mask.crop(box)

        cropped_w, cropped_h = image.size
        rows, cols = out_shape
        tile_h = cropped_h // rows
        tile_w = cropped_w // cols

        for r in range(rows):
            for c in range(cols):
                tile_box = (c * tile_w, r * tile_h,
                            (c + 1) * tile_w, (r + 1) * tile_h)

                img_tile  = image.crop(tile_box)
                mask_tile = mask.crop(tile_box)

                mask_arr  = np.array(mask_tile)

                # Normalise mask to {0, 1}
                if mask_arr.max() > 1:
                    mask_arr = (mask_arr >= 128).astype(np.uint8)

                void_pixels  = mask_arr.sum()
                total_pixels = mask_arr.size

                # Filter 1: no void pixels at all → discard
                if void_pixels == 0:
                    discarded_empty += 1
                    continue

                # Filter 2: void fraction too low → discard
                if void_pixels / total_pixels < void_threshold:
                    discarded_sparse += 1
                    continue

                # Save tile
                tile_name = f"{stem}_{c}_{r}.png"
                img_tile.save(os.path.join(save_img_path, tile_name))
                Image.fromarray(mask_arr * 255).save(
                    os.path.join(save_mask_path, tile_name)
                )
                kept += 1

    print(f"\nCropping complete:")
    print(f"  Kept      : {kept}")
    print(f"  Discarded (no void)    : {discarded_empty}")
    print(f"  Discarded (< {void_threshold*100:.0f}% void): {discarded_sparse}")
    return kept


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Crop and tile X-ray images + masks')
    parser.add_argument('--images',     required=True,  help='Input images directory')
    parser.add_argument('--masks',      required=True,  help='Input masks directory')
    parser.add_argument('--out_images', required=True,  help='Output images directory')
    parser.add_argument('--out_masks',  required=True,  help='Output masks directory')
    parser.add_argument('--rows',    type=int,   default=3,    help='Grid rows (default 3)')
    parser.add_argument('--cols',    type=int,   default=2,    help='Grid cols (default 2)')
    parser.add_argument('--threshold', type=float, default=0.05,
                        help='Min void fraction to keep tile (default 0.05 = 5%%)')
    # The paper crops edges: adjust these to your image dimensions
    parser.add_argument('--crop_left',   type=int, default=None)
    parser.add_argument('--crop_top',    type=int, default=None)
    parser.add_argument('--crop_right',  type=int, default=None)
    parser.add_argument('--crop_bottom', type=int, default=None)
    args = parser.parse_args()

    box = None
    if all(v is not None for v in [args.crop_left, args.crop_top,
                                    args.crop_right, args.crop_bottom]):
        box = (args.crop_left, args.crop_top, args.crop_right, args.crop_bottom)

    cut_images(
        image_path     = args.images,
        mask_path      = args.masks,
        save_img_path  = args.out_images,
        save_mask_path = args.out_masks,
        box            = box,
        out_shape      = (args.rows, args.cols),
        void_threshold = args.threshold,
    )
