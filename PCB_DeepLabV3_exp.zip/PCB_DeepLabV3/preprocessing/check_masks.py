"""
check_masks.py — Inspect your CVAT mask files before training.

Run this first to verify mask pixel values are being read correctly.

Usage:
    python preprocessing/check_masks.py --masks /path/to/masks --n 10
"""

import os
import argparse
import numpy as np
from PIL import Image


def check_masks(mask_dir, n_samples=10):
    files = [f for f in sorted(os.listdir(mask_dir))
             if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    if not files:
        print("No mask files found.")
        return

    print(f"Checking {min(n_samples, len(files))} masks in: {mask_dir}\n")

    for fname in files[:n_samples]:
        path = os.path.join(mask_dir, fname)
        img  = Image.open(path)
        arr  = np.array(img)

        unique_vals = np.unique(arr)
        void_pixels = 0

        if arr.ndim == 3:
            # RGB/RGBA
            void_mask   = (arr[:, :, :3].sum(axis=2) > 0)
            void_pixels = void_mask.sum()
        else:
            void_pixels = (arr > 0).sum()

        total = arr.shape[0] * arr.shape[1]
        print(f"  {fname}")
        print(f"    Mode        : {img.mode}")
        print(f"    Shape       : {arr.shape}")
        print(f"    Unique vals : {unique_vals}")
        print(f"    Void pixels : {void_pixels} / {total}  ({100*void_pixels/total:.2f}%)")
        print()

    print("─" * 50)
    print("Expected for training:")
    print("  Unique vals should be {0, 1} or {0, 255}")
    print("  Void pixels > 0  (at least some masks must have voids)")
    print("  The dataset loader handles both {0,1} and {0,255} automatically.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--masks', required=True, help='Masks directory')
    parser.add_argument('--n',     type=int, default=10, help='Number of masks to inspect')
    args = parser.parse_args()
    check_masks(args.masks, args.n)
