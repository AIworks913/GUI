"""
Segmentation evaluation metrics used in the paper:
  - mIOU  : mean Intersection over Union
  - MPA   : mean Pixel Accuracy
  - CPA   : Class Pixel Accuracy  (= Precision for the void class)
  - Recall: completeness of void pixel segmentation

All metrics computed from a running confusion matrix accumulated over batches.
"""

import numpy as np
import torch


class SegMetrics:
    """
    Accumulates a confusion matrix over multiple batches,
    then computes mIOU / MPA / CPA / Recall.

    Usage:
        metrics = SegMetrics(num_classes=2)
        for pred, target in loader:
            metrics.update(pred, target)
        results = metrics.compute()
        metrics.reset()
    """

    def __init__(self, num_classes=2):
        self.num_classes = num_classes
        self.conf_mat = np.zeros((num_classes, num_classes), dtype=np.int64)

    def reset(self):
        self.conf_mat = np.zeros((self.num_classes, self.num_classes), dtype=np.int64)

    def update(self, pred: torch.Tensor, target: torch.Tensor):
        """
        pred   : [B, H, W] int64 — argmax of model output
        target : [B, H, W] int64 — ground-truth class indices
        """
        pred   = pred.cpu().numpy().flatten()
        target = target.cpu().numpy().flatten()

        # Mask out any invalid labels (safety)
        valid = (target >= 0) & (target < self.num_classes)
        pred   = pred[valid]
        target = target[valid]

        # Accumulate confusion matrix
        np.add.at(self.conf_mat, (target, pred), 1)

    def compute(self):
        """Returns dict with mPA, mIOU, CPA (void), Recall (void)."""
        cm = self.conf_mat.astype(np.float64)

        # Per-class pixel accuracy  (diagonal / row sum)
        row_sums = cm.sum(axis=1)
        per_class_acc = np.where(row_sums > 0, np.diag(cm) / row_sums, 0.0)
        mpa = np.mean(per_class_acc) * 100.0

        # Per-class IoU  = TP / (TP + FP + FN)
        col_sums   = cm.sum(axis=0)
        union      = row_sums + col_sums - np.diag(cm)
        per_class_iou = np.where(union > 0, np.diag(cm) / union, 0.0)
        miou = np.mean(per_class_iou) * 100.0

        # Void class (class 1) metrics
        void_idx = 1
        tp = cm[void_idx, void_idx]
        fp = col_sums[void_idx] - tp          # predicted void, actually background
        fn = row_sums[void_idx] - tp          # actually void, predicted background

        cpa    = (tp / (tp + fp) * 100.0) if (tp + fp) > 0 else 0.0   # Precision
        recall = (tp / (tp + fn) * 100.0) if (tp + fn) > 0 else 0.0

        return {
            'mPA  (%)': round(mpa,    2),
            'mIOU (%)': round(miou,   2),
            'CPA  (%)': round(cpa,    2),
            'Recall(%)': round(recall, 2),
        }

    def print_results(self):
        res = self.compute()
        print("\n── Evaluation Results ──────────────────")
        for k, v in res.items():
            print(f"  {k}: {v:.2f}")
        print("────────────────────────────────────────\n")
        return res
