"""
Loss functions for binary void segmentation.

CrossEntropy alone works well for this task.
Dice loss or the combined CE+Dice can help when class imbalance is severe
(many more background pixels than void pixels).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class CrossEntropyLoss(nn.Module):
    """Standard pixel-wise cross-entropy with optional class weights."""

    def __init__(self, num_classes=2, ignore_index=255, weight=None):
        super().__init__()
        if weight is not None:
            weight = torch.tensor(weight, dtype=torch.float32)
        self.criterion = nn.CrossEntropyLoss(
            weight=weight,
            ignore_index=ignore_index,
            reduction='mean'
        )

    def forward(self, pred, target):
        """
        pred   : [B, C, H, W] raw logits
        target : [B, H, W]    int64 class indices
        """
        return self.criterion(pred, target)


class DiceLoss(nn.Module):
    """
    Soft Dice loss for binary segmentation.
    Computed on the void class (class 1) probability map.
    """

    def __init__(self, smooth=1.0):
        super().__init__()
        self.smooth = smooth

    def forward(self, pred, target):
        prob = F.softmax(pred, dim=1)[:, 1]     # void class probability [B, H, W]
        tgt  = (target == 1).float()

        intersection = (prob * tgt).sum(dim=[1, 2])
        union        = prob.sum(dim=[1, 2]) + tgt.sum(dim=[1, 2])
        dice         = (2.0 * intersection + self.smooth) / (union + self.smooth)
        return 1.0 - dice.mean()


class CombinedLoss(nn.Module):
    """CE + Dice  (recommended when void pixels are rare)."""

    def __init__(self, num_classes=2, ce_weight=None, dice_weight=0.5, ignore_index=255):
        super().__init__()
        self.ce_loss   = CrossEntropyLoss(num_classes, ignore_index, ce_weight)
        self.dice_loss = DiceLoss()
        self.w_dice    = dice_weight

    def forward(self, pred, target):
        return self.ce_loss(pred, target) + self.w_dice * self.dice_loss(pred, target)


def build_loss(loss_type='ce', num_classes=2, void_weight=None):
    """
    Factory function.

    loss_type:
      'ce'       — cross-entropy only (default, as used in the paper)
      'dice'     — dice only
      'combined' — CE + Dice  (try this if mIOU is low due to class imbalance)

    void_weight: float — up-weight the void class in CE (e.g. 3.0)
                         Set to None (default) to use equal weights.
    """
    weight = None
    if void_weight is not None:
        weight = [1.0, float(void_weight)]

    if loss_type == 'ce':
        return CrossEntropyLoss(num_classes=num_classes, weight=weight)
    elif loss_type == 'dice':
        return DiceLoss()
    elif loss_type == 'combined':
        return CombinedLoss(num_classes=num_classes, ce_weight=weight)
    else:
        raise ValueError(f"Unknown loss_type '{loss_type}'. Choose: ce, dice, combined.")
