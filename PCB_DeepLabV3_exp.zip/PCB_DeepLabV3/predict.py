"""
predict.py — Run inference on a single image or a folder of images.

Saves side-by-side comparison:  [Original | Predicted mask overlay]

Usage:
    # Single image
    python predict.py --input image.png --checkpoint checkpoints/best.pth

    # Folder of images
    python predict.py --input /path/to/images/ --checkpoint checkpoints/best.pth \
                      --output ./predictions
"""

import os
import argparse
import numpy as np
from PIL import Image, ImageDraw

import torch
import torchvision.transforms.functional as TF

from nets.deeplabv3_plus import DeepLab


MEAN = [0.485, 0.456, 0.406]
STD  = [0.229, 0.224, 0.225]

# Void overlay colour (red, semi-transparent)
VOID_COLOR = (255, 50, 50)


def get_args():
    p = argparse.ArgumentParser(description='PCB-DeepLabV3 inference')
    p.add_argument('--input',       required=True,
                   help='Path to image file or directory of images')
    p.add_argument('--checkpoint',  required=True,
                   help='Path to best.pth checkpoint')
    p.add_argument('--output',      default='./predictions',
                   help='Output directory for result images')
    p.add_argument('--num_classes', type=int, default=2)
    p.add_argument('--input_size',  type=int, default=512,
                   help='Resize input to this size before inference')
    p.add_argument('--device',      default='auto')
    p.add_argument('--alpha',       type=float, default=0.5,
                   help='Overlay transparency (0=invisible, 1=opaque)')
    return p.parse_args()


def load_model(checkpoint_path, num_classes, device):
    model = DeepLab(num_classes=num_classes, pretrained=False).to(device)
    ckpt  = torch.load(checkpoint_path, map_location=device)
    state = ckpt['model_state']
    state = {k.replace('module.', ''): v for k, v in state.items()}
    model.load_state_dict(state)
    model.eval()
    print(f"Model loaded from {checkpoint_path}")
    return model


def preprocess(image_pil, input_size):
    """Resize → tensor → normalise."""
    img = image_pil.convert('RGB').resize((input_size, input_size), Image.BILINEAR)
    t   = TF.to_tensor(img)
    t   = TF.normalize(t, MEAN, STD)
    return t.unsqueeze(0)   # [1, 3, H, W]


def predict_image(model, image_pil, input_size, device):
    """Return prediction mask at the original image resolution."""
    orig_w, orig_h = image_pil.size
    inp = preprocess(image_pil, input_size).to(device)

    with torch.no_grad():
        out  = model(inp)             # [1, C, H, W]
        pred = out.argmax(dim=1)[0]   # [H, W]

    # Resize prediction back to original size
    pred_np = pred.cpu().numpy().astype(np.uint8)
    pred_pil = Image.fromarray(pred_np * 255, mode='L')
    pred_pil = pred_pil.resize((orig_w, orig_h), Image.NEAREST)
    return np.array(pred_pil) > 0    # boolean mask


def make_overlay(image_pil, void_mask, alpha=0.5, color=VOID_COLOR):
    """Overlay void regions on the original image."""
    base    = image_pil.convert('RGBA')
    overlay = Image.new('RGBA', base.size, (0, 0, 0, 0))
    pixels  = overlay.load()

    for y in range(base.size[1]):
        for x in range(base.size[0]):
            if void_mask[y, x]:
                a = int(alpha * 255)
                pixels[x, y] = (*color, a)

    result = Image.alpha_composite(base, overlay).convert('RGB')
    return result


def save_comparison(original, overlay, pred_mask, out_path):
    """Save a 3-panel comparison: original | overlay | binary mask."""
    w, h     = original.size
    mask_rgb = Image.fromarray(
        (pred_mask.astype(np.uint8) * 255)[:, :, None].repeat(3, axis=2)
    )
    canvas   = Image.new('RGB', (w * 3 + 20, h), (50, 50, 50))
    canvas.paste(original, (0, 0))
    canvas.paste(overlay,  (w + 10, 0))
    canvas.paste(mask_rgb, (w * 2 + 20, 0))
    canvas.save(out_path)


def main():
    args   = get_args()
    device = (torch.device('cuda' if torch.cuda.is_available() else 'cpu')
              if args.device == 'auto' else torch.device(args.device))

    model = load_model(args.checkpoint, args.num_classes, device)
    os.makedirs(args.output, exist_ok=True)

    # Collect input files
    if os.path.isdir(args.input):
        exts  = {'.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp'}
        files = [os.path.join(args.input, f) for f in sorted(os.listdir(args.input))
                 if os.path.splitext(f)[1].lower() in exts]
    else:
        files = [args.input]

    print(f"\nProcessing {len(files)} image(s)...")

    for fpath in files:
        stem  = os.path.splitext(os.path.basename(fpath))[0]
        image = Image.open(fpath)

        # Predict
        pred_mask = predict_image(model, image, args.input_size, device)
        overlay   = make_overlay(image.convert('RGB'), pred_mask, alpha=args.alpha)

        # Stats
        void_pct = 100.0 * pred_mask.sum() / pred_mask.size
        print(f"  {stem}: void area = {void_pct:.2f}%")

        # Save outputs
        out_path = os.path.join(args.output, f"{stem}_result.png")
        save_comparison(image.convert('RGB'), overlay, pred_mask, out_path)

        # Also save raw binary mask
        mask_path = os.path.join(args.output, f"{stem}_mask.png")
        Image.fromarray((pred_mask.astype(np.uint8) * 255)).save(mask_path)

    print(f"\nResults saved to: {args.output}")


if __name__ == '__main__':
    main()
