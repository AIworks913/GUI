"""
=============================================================
  ALGORITHM : LSTM (PyTorch)
  TARGETS   : temp4_stn5, temp4_stn6, temp9_stn5, temp9_stn6
  SORTIES   : S1 + S2 combined
=============================================================
  HOW TO USE:
    Train all targets  → run_all()
    Train one target   → run_one('temp4_stn5')
    Inference          → run_inference('temp4_stn5', 'data/unseen_inputs.csv')
=============================================================
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from torch.utils.data import DataLoader, TensorDataset

# ─────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────
SEQ_LEN     = 50        # sequence length — how many past steps to look at
BATCH_SIZE  = 32
EPOCHS      = 100
LR          = 0.001
HIDDEN_SIZE = 128       # neurons in LSTM
NUM_LAYERS  = 2         # stacked LSTM layers
TRAIN_RATIO = 0.8
SAVE_DIR    = 'outputs_lstm'
os.makedirs(SAVE_DIR, exist_ok=True)

INPUT_FEATURES = [
    'DP', 'altitude', 'mach_no', 'IaS',
    'Nx', 'Ny', 'Nz', 'alpha',
    'beta', 'roll_rate', 'pitch_rate', 'yaw_rate'
]

TARGETS = {
    'temp4_stn5': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn5_targets.csv',
        's2_target': 'data/s2_stn5_targets.csv',
        'col'      : 'temp4'
    },
    'temp4_stn6': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn6_targets.csv',
        's2_target': 'data/s2_stn6_targets.csv',
        'col'      : 'temp4'
    },
    'temp9_stn5': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn5_targets.csv',
        's2_target': 'data/s2_stn5_targets.csv',
        'col'      : 'temp9'
    },
    'temp9_stn6': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn6_targets.csv',
        's2_target': 'data/s2_stn6_targets.csv',
        'col'      : 'temp9'
    },
}


# ─────────────────────────────────────────
#  MODEL DEFINITION
# ─────────────────────────────────────────
class LSTMModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm    = nn.LSTM(len(INPUT_FEATURES), HIDDEN_SIZE, NUM_LAYERS,
                               batch_first=True, dropout=0.2)
        self.dense1  = nn.Linear(HIDDEN_SIZE, 64)
        self.dense2  = nn.Linear(64, 32)
        self.output  = nn.Linear(32, 1)
        self.relu    = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        out, _    = self.lstm(x)
        last_step = out[:, -1, :]
        x = self.relu(self.dense1(last_step))
        x = self.dropout(x)
        x = self.relu(self.dense2(x))
        x = self.output(x)
        return x


# ─────────────────────────────────────────
#  DATA LOADING
# ─────────────────────────────────────────
def load_data(cfg):
    s1_inputs  = pd.read_csv(cfg['s1_input'])
    s2_inputs  = pd.read_csv(cfg['s2_input'])
    s1_targets = pd.read_csv(cfg['s1_target'])
    s2_targets = pd.read_csv(cfg['s2_target'])

    s1_inputs = s1_inputs.sort_values('timestamp').reset_index(drop=True)
    s2_inputs = s2_inputs.sort_values('timestamp').reset_index(drop=True)

    s1_inputs = s1_inputs.drop(columns=['timestamp']).fillna(method='ffill')
    s2_inputs = s2_inputs.drop(columns=['timestamp']).fillna(method='ffill')

    s1_y = s1_targets[cfg['col']].fillna(method='ffill').values
    s2_y = s2_targets[cfg['col']].fillna(method='ffill').values

    return s1_inputs, s2_inputs, s1_y, s2_y


# ─────────────────────────────────────────
#  SCALING
# ─────────────────────────────────────────
def scale_data(target_name, s1_inputs, s2_inputs):
    combined = pd.concat([s1_inputs, s2_inputs], axis=0)
    scaler   = MinMaxScaler()
    scaler.fit(combined[INPUT_FEATURES])

    s1_scaled = scaler.transform(s1_inputs[INPUT_FEATURES])
    s2_scaled = scaler.transform(s2_inputs[INPUT_FEATURES])

    path = f'{SAVE_DIR}/scaler_{target_name}.pkl'
    joblib.dump(scaler, path)
    print(f"  Scaler saved → {path}")

    return s1_scaled, s2_scaled, scaler


# ─────────────────────────────────────────
#  CLIP OUTLIERS
# ─────────────────────────────────────────
def clip_outliers(df):
    df = df.copy()
    for col in ['pitch_rate', 'yaw_rate', 'beta', 'roll_rate']:
        if col in df.columns:
            q_low  = df[col].quantile(0.01)
            q_high = df[col].quantile(0.99)
            df[col] = df[col].clip(q_low, q_high)
    return df


# ─────────────────────────────────────────
#  SEQUENCE CREATION
# ─────────────────────────────────────────
def create_sequences(X, y, seq_len):
    """Create sequences per sortie — no boundary mixing."""
    X_seq, y_seq = [], []
    for i in range(len(X) - seq_len):
        X_seq.append(X[i : i + seq_len])
        y_seq.append(y[i + seq_len])
    return np.array(X_seq), np.array(y_seq)


# ─────────────────────────────────────────
#  TRAIN / TEST SPLIT
# ─────────────────────────────────────────
def split_data(s1_scaled, s2_scaled, s1_y, s2_y):
    # Create sequences per sortie first — no boundary mixing
    X1, y1 = create_sequences(s1_scaled, s1_y, SEQ_LEN)
    X2, y2 = create_sequences(s2_scaled, s2_y, SEQ_LEN)

    # Then concatenate
    X_all = np.concatenate([X1, X2], axis=0)
    y_all = np.concatenate([y1, y2], axis=0)

    split   = int(len(X_all) * TRAIN_RATIO)
    X_train = X_all[:split]
    X_test  = X_all[split:]
    y_train = y_all[:split]
    y_test  = y_all[split:]

    return X_train, X_test, y_train, y_test


# ─────────────────────────────────────────
#  TRAINING
# ─────────────────────────────────────────
def train_model(X_train, y_train):
    X_t = torch.FloatTensor(X_train)
    y_t = torch.FloatTensor(y_train).unsqueeze(1)

    dataset = TensorDataset(X_t, y_t)
    loader  = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False)

    model     = LSTMModel()
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)

    loss_history = []

    for epoch in range(EPOCHS):
        model.train()
        total_loss = 0

        for X_batch, y_batch in loader:
            optimizer.zero_grad()
            preds = model(X_batch)
            loss  = criterion(preds, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(loader)
        loss_history.append(avg_loss)

        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}/{EPOCHS}  Loss: {avg_loss:.4f}")

    return model, loss_history


# ─────────────────────────────────────────
#  EVALUATION
# ─────────────────────────────────────────
def evaluate_model(model, X_test, y_test):
    model.eval()
    X_t = torch.FloatTensor(X_test)

    with torch.no_grad():
        y_pred = model(X_t).numpy().flatten()

    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)

    print(f"  MAE  : {mae:.4f}")
    print(f"  RMSE : {rmse:.4f}")
    print(f"  R2   : {r2:.4f}")

    return y_pred, mae, rmse, r2


# ─────────────────────────────────────────
#  PLOTS
# ─────────────────────────────────────────
def save_loss_plot(target_name, loss_history):
    plt.figure(figsize=(10, 4))
    plt.plot(loss_history, color='#2E86AB')
    plt.title(f'Training Loss — LSTM — {target_name}')
    plt.xlabel('Epoch')
    plt.ylabel('MSE Loss')
    plt.tight_layout()
    path = f'{SAVE_DIR}/loss_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Loss plot saved → {path}")


def save_prediction_plot(target_name, y_true, y_pred):
    x = np.arange(len(y_true))
    plt.figure(figsize=(14, 5))
    plt.plot(x, y_true, color='black',   linewidth=1.2, label='Actual')
    plt.plot(x, y_pred, color='#E84855', linewidth=1.0, alpha=0.8, label='Predicted')
    plt.title(f'Actual vs Predicted — LSTM — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/pred_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Prediction plot saved → {path}")


def save_residual_plot(target_name, y_true, y_pred):
    residuals = y_true - y_pred
    plt.figure(figsize=(14, 4))
    plt.plot(residuals, color='#F4A261', linewidth=0.8)
    plt.axhline(0, color='black', linewidth=1, linestyle='--')
    plt.title(f'Residuals — LSTM — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Error')
    plt.tight_layout()
    path = f'{SAVE_DIR}/residual_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Residual plot saved → {path}")


# ─────────────────────────────────────────
#  SAVE MODEL
# ─────────────────────────────────────────
def save_model(target_name, model):
    path = f'{SAVE_DIR}/model_{target_name}.pth'
    torch.save(model.state_dict(), path)
    print(f"  Model saved → {path}")


# ─────────────────────────────────────────
#  SINGLE TARGET PIPELINE
# ─────────────────────────────────────────
def run_one(target_name):
    print(f"\n{'='*50}")
    print(f"  LSTM | {target_name}")
    print(f"{'='*50}")

    cfg = TARGETS[target_name]

    print("\n[1] Loading data...")
    s1_X, s2_X, s1_y, s2_y = load_data(cfg)

    print("\n[2] Clipping outliers...")
    s1_X = clip_outliers(s1_X)
    s2_X = clip_outliers(s2_X)

    print("\n[3] Scaling...")
    s1_scaled, s2_scaled, scaler = scale_data(target_name, s1_X, s2_X)

    print("\n[4] Creating sequences + splitting...")
    X_train, X_test, y_train, y_test = split_data(s1_scaled, s2_scaled, s1_y, s2_y)
    print(f"  Train: {X_train.shape} | Test: {X_test.shape}")

    print("\n[5] Training...")
    model, loss_history = train_model(X_train, y_train)

    print("\n[6] Evaluating...")
    y_pred, mae, rmse, r2 = evaluate_model(model, X_test, y_test)

    print("\n[7] Saving plots...")
    save_loss_plot(target_name, loss_history)
    save_prediction_plot(target_name, y_test, y_pred)
    save_residual_plot(target_name, y_test, y_pred)

    print("\n[8] Saving model...")
    save_model(target_name, model)

    print(f"\n✅ Done → {SAVE_DIR}/")
    return model, scaler


# ─────────────────────────────────────────
#  ALL TARGETS PIPELINE
# ─────────────────────────────────────────
def run_all():
    print("\n" + "="*50)
    print("  Training ALL targets — LSTM")
    print("="*50)

    results = {}
    for target_name in TARGETS:
        model, scaler = run_one(target_name)
        results[target_name] = model

    print("\n\n" + "="*50)
    print("  ALL MODELS TRAINED")
    print("="*50)
    for name in results:
        print(f"  ✅ {name}")


# ─────────────────────────────────────────
#  INFERENCE ON UNSEEN DATA
# ─────────────────────────────────────────
def run_inference(target_name, unseen_input_path):
    """
    Standalone inference — just provide target name and unseen CSV path.
    No target values needed.
    """
    print(f"\n{'='*50}")
    print(f"  Inference — LSTM | {target_name}")
    print(f"{'='*50}")

    # Load model
    model = LSTMModel()
    model.load_state_dict(torch.load(f'{SAVE_DIR}/model_{target_name}.pth'))
    model.eval()

    # Load scaler
    scaler = joblib.load(f'{SAVE_DIR}/scaler_{target_name}.pkl')

    # Load and prepare unseen data
    df = pd.read_csv(unseen_input_path)
    df = df.sort_values('timestamp').reset_index(drop=True)
    df = df.drop(columns=['timestamp']).fillna(method='ffill')
    df = clip_outliers(df)

    # Scale
    X_scaled = scaler.transform(df[INPUT_FEATURES])

    # Create sequences
    X_seq = []
    for i in range(len(X_scaled) - SEQ_LEN):
        X_seq.append(X_scaled[i : i + SEQ_LEN])
    X_seq = np.array(X_seq)

    # Predict
    X_t = torch.FloatTensor(X_seq)
    with torch.no_grad():
        predictions = model(X_t).numpy().flatten()

    print(f"  Predictions shape : {predictions.shape}")
    print(f"  Min  : {predictions.min():.3f}")
    print(f"  Max  : {predictions.max():.3f}")
    print(f"  Mean : {predictions.mean():.3f}")

    # Plot
    plt.figure(figsize=(14, 5))
    plt.plot(predictions, color='#9B59B6', linewidth=1.0, label='Predicted')
    plt.title(f'Inference — LSTM — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/inference_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Plot saved → {path}")

    # Save CSV
    out_df = pd.DataFrame({f'predicted_{target_name}': predictions})
    csv_path = f'{SAVE_DIR}/inference_{target_name}.csv'
    out_df.to_csv(csv_path, index=False)
    print(f"  CSV saved  → {csv_path}")

    return predictions


# ─────────────────────────────────────────
#  RUN
# ─────────────────────────────────────────
if __name__ == '__main__':

    # ── Train ALL targets ──────────────────
    run_all()

    # ── Train ONE target ───────────────────
    # run_one('temp9_stn5')

    # ── Inference on unseen ────────────────
    # run_inference('temp9_stn5', 'data/unseen_inputs.csv')
