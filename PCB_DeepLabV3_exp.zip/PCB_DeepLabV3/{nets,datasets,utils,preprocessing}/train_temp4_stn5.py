"""
=============================================================
  MODEL: temp4 | STATION: STN5
  Target: Predict temp4 from FDR input features
  Sorties: S1 + S2 combined for training
=============================================================
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from torch.utils.data import DataLoader, TensorDataset

# ─────────────────────────────────────────
#  CONFIG — change these as needed
# ─────────────────────────────────────────
TARGET      = 'temp4'
STATION     = 'stn5'
SEQ_LEN     = 50
BATCH_SIZE  = 32
EPOCHS      = 100
LR          = 0.001
HIDDEN_SIZE = 128
NUM_LAYERS  = 2
TRAIN_RATIO = 0.8
SAVE_DIR    = f'outputs_{TARGET}_{STATION}'
os.makedirs(SAVE_DIR, exist_ok=True)

INPUT_FEATURES = [
    'DP', 'altitude', 'mach_no', 'IaS',
    'Nx', 'Ny', 'Nz', 'alpha',
    'beta', 'roll_rate', 'pitch_rate', 'yaw_rate'
]


# ─────────────────────────────────────────
#  MODEL DEFINITION
# ─────────────────────────────────────────
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers):
        super().__init__()
        self.lstm    = nn.LSTM(input_size, hidden_size, num_layers,
                               batch_first=True, dropout=0.2)
        self.dense1  = nn.Linear(hidden_size, 64)
        self.dense2  = nn.Linear(64, 32)
        self.output  = nn.Linear(32, 1)
        self.relu    = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        out, _    = self.lstm(x)
        last_step = out[:, -1, :]
        x = self.relu(self.dense1(last_step))
        x = self.dropout(x)
        x = self.relu(self.dense2(x))
        x = self.output(x)
        return x


# ─────────────────────────────────────────
#  DATA LOADING
# ─────────────────────────────────────────
def load_data(s1_input_path, s2_input_path,
              s1_target_path, s2_target_path):
    s1_inputs  = pd.read_csv(s1_input_path)
    s2_inputs  = pd.read_csv(s2_input_path)
    s1_targets = pd.read_csv(s1_target_path)
    s2_targets = pd.read_csv(s2_target_path)

    s1_inputs  = s1_inputs.sort_values('timestamp').reset_index(drop=True)
    s2_inputs  = s2_inputs.sort_values('timestamp').reset_index(drop=True)

    s1_inputs  = s1_inputs.drop(columns=['timestamp']).fillna(method='ffill')
    s2_inputs  = s2_inputs.drop(columns=['timestamp']).fillna(method='ffill')

    s1_y = s1_targets[TARGET].fillna(method='ffill').values
    s2_y = s2_targets[TARGET].fillna(method='ffill').values

    return s1_inputs, s2_inputs, s1_y, s2_y


# ─────────────────────────────────────────
#  SCALING
# ─────────────────────────────────────────
def scale_data(s1_inputs, s2_inputs):
    combined = pd.concat([s1_inputs, s2_inputs], axis=0)
    scaler   = MinMaxScaler()
    scaler.fit(combined[INPUT_FEATURES])

    s1_scaled = scaler.transform(s1_inputs[INPUT_FEATURES])
    s2_scaled = scaler.transform(s2_inputs[INPUT_FEATURES])

    joblib.dump(scaler, f'{SAVE_DIR}/scaler_{TARGET}_{STATION}.pkl')
    print(f"Scaler saved → {SAVE_DIR}/scaler_{TARGET}_{STATION}.pkl")

    return s1_scaled, s2_scaled, scaler


# ─────────────────────────────────────────
#  SEQUENCE CREATION
# ─────────────────────────────────────────
def create_sequences(X, y, seq_len):
    X_seq, y_seq = [], []
    for i in range(len(X) - seq_len):
        X_seq.append(X[i : i + seq_len])
        y_seq.append(y[i + seq_len])
    return np.array(X_seq), np.array(y_seq)


# ─────────────────────────────────────────
#  TRAINING
# ─────────────────────────────────────────
def train_model(X_train, y_train):
    X_t = torch.FloatTensor(X_train)
    y_t = torch.FloatTensor(y_train).unsqueeze(1)

    dataset = TensorDataset(X_t, y_t)
    loader  = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False)

    model     = LSTMModel(len(INPUT_FEATURES), HIDDEN_SIZE, NUM_LAYERS)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)

    loss_history = []

    for epoch in range(EPOCHS):
        model.train()
        total_loss = 0

        for X_batch, y_batch in loader:
            optimizer.zero_grad()
            preds = model(X_batch)
            loss  = criterion(preds, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(loader)
        loss_history.append(avg_loss)

        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}/{EPOCHS}  Loss: {avg_loss:.4f}")

    return model, loss_history


# ─────────────────────────────────────────
#  EVALUATION
# ─────────────────────────────────────────
def evaluate_model(model, X_test, y_test):
    model.eval()
    X_t = torch.FloatTensor(X_test)

    with torch.no_grad():
        y_pred = model(X_t).numpy().flatten()

    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)

    print(f"\n  MAE  : {mae:.4f}")
    print(f"  RMSE : {rmse:.4f}")
    print(f"  R2   : {r2:.4f}")

    return y_pred, mae, rmse, r2


# ─────────────────────────────────────────
#  PLOTS
# ─────────────────────────────────────────
def save_loss_plot(loss_history):
    plt.figure(figsize=(10, 4))
    plt.plot(loss_history, color='#2E86AB')
    plt.title(f'Training Loss — {TARGET} {STATION}')
    plt.xlabel('Epoch')
    plt.ylabel('MSE Loss')
    plt.tight_layout()
    path = f'{SAVE_DIR}/loss_{TARGET}_{STATION}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Loss plot saved → {path}")


def save_prediction_plot(y_true, y_pred, split_name='test'):
    x = np.arange(len(y_true))
    plt.figure(figsize=(14, 5))
    plt.plot(x, y_true, color='black',   linewidth=1.2, label='Actual')
    plt.plot(x, y_pred, color='#E84855', linewidth=1.0, alpha=0.8, label='Predicted')
    plt.title(f'Actual vs Predicted — {TARGET} {STATION} ({split_name})')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/pred_{TARGET}_{STATION}_{split_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Prediction plot saved → {path}")


def save_residual_plot(y_true, y_pred, split_name='test'):
    residuals = y_true - y_pred
    x = np.arange(len(residuals))
    plt.figure(figsize=(14, 4))
    plt.plot(x, residuals, color='#F4A261', linewidth=0.8)
    plt.axhline(0, color='black', linewidth=1, linestyle='--')
    plt.title(f'Residuals — {TARGET} {STATION} ({split_name})')
    plt.xlabel('Time Steps')
    plt.ylabel('Error')
    plt.tight_layout()
    path = f'{SAVE_DIR}/residual_{TARGET}_{STATION}_{split_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Residual plot saved → {path}")


# ─────────────────────────────────────────
#  SAVE MODEL
# ─────────────────────────────────────────
def save_model(model):
    path = f'{SAVE_DIR}/model_{TARGET}_{STATION}.pth'
    torch.save(model.state_dict(), path)
    print(f"Model saved → {path}")


# ─────────────────────────────────────────
#  MAIN TRAINING PIPELINE
# ─────────────────────────────────────────
def run_training(s1_input_path, s2_input_path,
                 s1_target_path, s2_target_path):

    print(f"\n{'='*50}")
    print(f"  Training: {TARGET} | {STATION}")
    print(f"{'='*50}")

    print("\n[1] Loading data...")
    s1_X, s2_X, s1_y, s2_y = load_data(
        s1_input_path, s2_input_path,
        s1_target_path, s2_target_path
    )

    print("\n[2] Scaling...")
    s1_scaled, s2_scaled, scaler = scale_data(s1_X, s2_X)

    print("\n[3] Creating sequences...")
    X1, y1 = create_sequences(s1_scaled, s1_y, SEQ_LEN)
    X2, y2 = create_sequences(s2_scaled, s2_y, SEQ_LEN)

    X_all = np.concatenate([X1, X2], axis=0)
    y_all = np.concatenate([y1, y2], axis=0)
    print(f"     Total sequences: {X_all.shape}")

    split   = int(len(X_all) * TRAIN_RATIO)
    X_train = X_all[:split]
    X_test  = X_all[split:]
    y_train = y_all[:split]
    y_test  = y_all[split:]
    print(f"     Train: {X_train.shape} | Test: {X_test.shape}")

    print("\n[4] Training...")
    model, loss_history = train_model(X_train, y_train)

    print("\n[5] Evaluating...")
    y_pred, mae, rmse, r2 = evaluate_model(model, X_test, y_test)

    print("\n[6] Saving plots...")
    save_loss_plot(loss_history)
    save_prediction_plot(y_test, y_pred, split_name='test')
    save_residual_plot(y_test, y_pred,   split_name='test')

    print("\n[7] Saving model...")
    save_model(model)

    print(f"\n✅ Done! All outputs in → {SAVE_DIR}/")
    return model, scaler


# ─────────────────────────────────────────
#  INFERENCE ON UNSEEN DATA
# ─────────────────────────────────────────
def run_inference(unseen_input_path):
    print(f"\n{'='*50}")
    print(f"  Inference: {TARGET} | {STATION}")
    print(f"{'='*50}")

    model = LSTMModel(len(INPUT_FEATURES), HIDDEN_SIZE, NUM_LAYERS)
    model.load_state_dict(torch.load(f'{SAVE_DIR}/model_{TARGET}_{STATION}.pth'))
    model.eval()

    scaler = joblib.load(f'{SAVE_DIR}/scaler_{TARGET}_{STATION}.pkl')

    df = pd.read_csv(unseen_input_path)
    df = df.sort_values('timestamp').reset_index(drop=True)
    df = df.drop(columns=['timestamp']).fillna(method='ffill')

    X_scaled = scaler.transform(df[INPUT_FEATURES])

    X_seq = []
    for i in range(len(X_scaled) - SEQ_LEN):
        X_seq.append(X_scaled[i : i + SEQ_LEN])
    X_seq = np.array(X_seq)

    X_t = torch.FloatTensor(X_seq)
    with torch.no_grad():
        predictions = model(X_t).numpy().flatten()

    print(f"  Predictions shape: {predictions.shape}")
    print(f"  Min: {predictions.min():.3f}  Max: {predictions.max():.3f}  Mean: {predictions.mean():.3f}")

    plt.figure(figsize=(14, 5))
    plt.plot(predictions, color='#2E86AB', linewidth=1.0, label='Predicted')
    plt.title(f'Inference — {TARGET} {STATION}')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/inference_{TARGET}_{STATION}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Inference plot saved → {path}")

    out_df   = pd.DataFrame({f'predicted_{TARGET}': predictions})
    csv_path = f'{SAVE_DIR}/inference_predictions_{TARGET}_{STATION}.csv'
    out_df.to_csv(csv_path, index=False)
    print(f"  Predictions CSV saved → {csv_path}")

    return predictions


# ─────────────────────────────────────────
#  RUN
# ─────────────────────────────────────────
if __name__ == '__main__':

    # ── TRAINING ──────────────────────────
    run_training(
        s1_input_path  = 'data/s1_inputs.csv',
        s2_input_path  = 'data/s2_inputs.csv',
        s1_target_path = 'data/s1_stn5_targets.csv',
        s2_target_path = 'data/s2_stn5_targets.csv'
    )

    # ── INFERENCE ─────────────────────────
    # run_inference(unseen_input_path='data/unseen_inputs.csv')
