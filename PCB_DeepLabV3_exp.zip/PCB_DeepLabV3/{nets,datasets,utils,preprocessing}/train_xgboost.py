"""
=============================================================
  ALGORITHM : XGBoost
  TARGETS   : temp4_stn5, temp4_stn6, temp9_stn5, temp9_stn6
  SORTIES   : S1 + S2 combined
=============================================================
  HOW TO USE:
    Train all targets  → run_all()
    Train one target   → run_one('temp4_stn5')
    Inference          → run_inference('temp4_stn5', 'data/unseen_inputs.csv')
=============================================================
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
import xgboost as xgb
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ─────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────
TRAIN_RATIO   = 0.8
N_ESTIMATORS  = 300     # number of boosting rounds
LEARNING_RATE = 0.05    # smaller = slower but better
MAX_DEPTH     = 6       # tree depth
SAVE_DIR      = 'outputs_xgboost'
os.makedirs(SAVE_DIR, exist_ok=True)

INPUT_FEATURES = [
    'DP', 'altitude', 'mach_no', 'IaS',
    'Nx', 'Ny', 'Nz', 'alpha',
    'beta', 'roll_rate', 'pitch_rate', 'yaw_rate'
]

TARGETS = {
    'temp4_stn5': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn5_targets.csv',
        's2_target': 'data/s2_stn5_targets.csv',
        'col'      : 'temp4'
    },
    'temp4_stn6': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn6_targets.csv',
        's2_target': 'data/s2_stn6_targets.csv',
        'col'      : 'temp4'
    },
    'temp9_stn5': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn5_targets.csv',
        's2_target': 'data/s2_stn5_targets.csv',
        'col'      : 'temp9'
    },
    'temp9_stn6': {
        's1_input' : 'data/s1_inputs.csv',
        's2_input' : 'data/s2_inputs.csv',
        's1_target': 'data/s1_stn6_targets.csv',
        's2_target': 'data/s2_stn6_targets.csv',
        'col'      : 'temp9'
    },
}


# ─────────────────────────────────────────
#  DATA LOADING
# ─────────────────────────────────────────
def load_data(cfg):
    s1_inputs  = pd.read_csv(cfg['s1_input'])
    s2_inputs  = pd.read_csv(cfg['s2_input'])
    s1_targets = pd.read_csv(cfg['s1_target'])
    s2_targets = pd.read_csv(cfg['s2_target'])

    s1_inputs = s1_inputs.sort_values('timestamp').reset_index(drop=True)
    s2_inputs = s2_inputs.sort_values('timestamp').reset_index(drop=True)

    s1_inputs = s1_inputs.drop(columns=['timestamp']).fillna(method='ffill')
    s2_inputs = s2_inputs.drop(columns=['timestamp']).fillna(method='ffill')

    s1_y = s1_targets[cfg['col']].fillna(method='ffill').values
    s2_y = s2_targets[cfg['col']].fillna(method='ffill').values

    return s1_inputs, s2_inputs, s1_y, s2_y


# ─────────────────────────────────────────
#  SCALING
# ─────────────────────────────────────────
def scale_data(target_name, s1_inputs, s2_inputs):
    combined = pd.concat([s1_inputs, s2_inputs], axis=0)
    scaler   = MinMaxScaler()
    scaler.fit(combined[INPUT_FEATURES])

    s1_scaled = scaler.transform(s1_inputs[INPUT_FEATURES])
    s2_scaled = scaler.transform(s2_inputs[INPUT_FEATURES])

    path = f'{SAVE_DIR}/scaler_{target_name}.pkl'
    joblib.dump(scaler, path)
    print(f"  Scaler saved → {path}")

    return s1_scaled, s2_scaled, scaler


# ─────────────────────────────────────────
#  CLIP OUTLIERS
# ─────────────────────────────────────────
def clip_outliers(df):
    df = df.copy()
    for col in ['pitch_rate', 'yaw_rate', 'beta', 'roll_rate']:
        if col in df.columns:
            q_low  = df[col].quantile(0.01)
            q_high = df[col].quantile(0.99)
            df[col] = df[col].clip(q_low, q_high)
    return df


# ─────────────────────────────────────────
#  TRAIN / TEST SPLIT
# ─────────────────────────────────────────
def split_data(s1_scaled, s2_scaled, s1_y, s2_y):
    X_all = np.concatenate([s1_scaled, s2_scaled], axis=0)
    y_all = np.concatenate([s1_y, s2_y],           axis=0)

    split   = int(len(X_all) * TRAIN_RATIO)
    X_train = X_all[:split]
    X_test  = X_all[split:]
    y_train = y_all[:split]
    y_test  = y_all[split:]

    return X_train, X_test, y_train, y_test


# ─────────────────────────────────────────
#  TRAINING
# ─────────────────────────────────────────
def train_model(X_train, y_train, X_test, y_test):
    model = xgb.XGBRegressor(
        n_estimators  = N_ESTIMATORS,
        learning_rate = LEARNING_RATE,
        max_depth     = MAX_DEPTH,
        random_state  = 42,
        verbosity     = 0
    )
    # XGBoost can track val loss during training
    model.fit(
        X_train, y_train,
        eval_set          = [(X_train, y_train), (X_test, y_test)],
        verbose           = False
    )
    return model


# ─────────────────────────────────────────
#  EVALUATION
# ─────────────────────────────────────────
def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)

    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)

    print(f"  MAE  : {mae:.4f}")
    print(f"  RMSE : {rmse:.4f}")
    print(f"  R2   : {r2:.4f}")

    return y_pred, mae, rmse, r2


# ─────────────────────────────────────────
#  LOSS PLOT (train vs val)
# ─────────────────────────────────────────
def save_loss_plot(target_name, model):
    results   = model.evals_result()
    train_loss = results['validation_0']['rmse']
    val_loss   = results['validation_1']['rmse']

    plt.figure(figsize=(10, 4))
    plt.plot(train_loss, color='#2E86AB', label='Train RMSE')
    plt.plot(val_loss,   color='#E84855', label='Val RMSE')
    plt.title(f'Train vs Val Loss — XGBoost — {target_name}')
    plt.xlabel('Rounds')
    plt.ylabel('RMSE')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/loss_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Loss plot saved → {path}")


# ─────────────────────────────────────────
#  FEATURE IMPORTANCE PLOT
# ─────────────────────────────────────────
def save_feature_importance_plot(target_name, model):
    importance = model.feature_importances_
    indices    = np.argsort(importance)[::-1]
    features   = [INPUT_FEATURES[i] for i in indices]
    values     = importance[indices]

    plt.figure(figsize=(10, 5))
    plt.bar(features, values, color='#F39C12')
    plt.title(f'Feature Importance — XGBoost — {target_name}')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    path = f'{SAVE_DIR}/feature_importance_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Feature importance saved → {path}")


# ─────────────────────────────────────────
#  PLOTS
# ─────────────────────────────────────────
def save_prediction_plot(target_name, y_true, y_pred):
    x = np.arange(len(y_true))
    plt.figure(figsize=(14, 5))
    plt.plot(x, y_true, color='black',   linewidth=1.2, label='Actual')
    plt.plot(x, y_pred, color='#E84855', linewidth=1.0, alpha=0.8, label='Predicted')
    plt.title(f'Actual vs Predicted — XGBoost — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/pred_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Prediction plot saved → {path}")


def save_residual_plot(target_name, y_true, y_pred):
    residuals = y_true - y_pred
    plt.figure(figsize=(14, 4))
    plt.plot(residuals, color='#F4A261', linewidth=0.8)
    plt.axhline(0, color='black', linewidth=1, linestyle='--')
    plt.title(f'Residuals — XGBoost — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Error')
    plt.tight_layout()
    path = f'{SAVE_DIR}/residual_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Residual plot saved → {path}")


# ─────────────────────────────────────────
#  SAVE MODEL
# ─────────────────────────────────────────
def save_model(target_name, model):
    path = f'{SAVE_DIR}/model_{target_name}.pkl'
    joblib.dump(model, path)
    print(f"  Model saved → {path}")


# ─────────────────────────────────────────
#  SINGLE TARGET PIPELINE
# ─────────────────────────────────────────
def run_one(target_name):
    print(f"\n{'='*50}")
    print(f"  XGBoost | {target_name}")
    print(f"{'='*50}")

    cfg = TARGETS[target_name]

    print("\n[1] Loading data...")
    s1_X, s2_X, s1_y, s2_y = load_data(cfg)

    print("\n[2] Clipping outliers...")
    s1_X = clip_outliers(s1_X)
    s2_X = clip_outliers(s2_X)

    print("\n[3] Scaling...")
    s1_scaled, s2_scaled, scaler = scale_data(target_name, s1_X, s2_X)

    print("\n[4] Splitting...")
    X_train, X_test, y_train, y_test = split_data(s1_scaled, s2_scaled, s1_y, s2_y)
    print(f"  Train: {X_train.shape} | Test: {X_test.shape}")

    print("\n[5] Training...")
    model = train_model(X_train, y_train, X_test, y_test)

    print("\n[6] Evaluating...")
    y_pred, mae, rmse, r2 = evaluate_model(model, X_test, y_test)

    print("\n[7] Saving plots...")
    save_loss_plot(target_name, model)
    save_prediction_plot(target_name, y_test, y_pred)
    save_residual_plot(target_name, y_test, y_pred)
    save_feature_importance_plot(target_name, model)

    print("\n[8] Saving model...")
    save_model(target_name, model)

    print(f"\n✅ Done → {SAVE_DIR}/")
    return model, scaler


# ─────────────────────────────────────────
#  ALL TARGETS PIPELINE
# ─────────────────────────────────────────
def run_all():
    print("\n" + "="*50)
    print("  Training ALL targets — XGBoost")
    print("="*50)

    results = {}
    for target_name in TARGETS:
        model, scaler = run_one(target_name)
        results[target_name] = model

    print("\n\n" + "="*50)
    print("  ALL MODELS TRAINED")
    print("="*50)
    for name in results:
        print(f"  ✅ {name}")


# ─────────────────────────────────────────
#  INFERENCE ON UNSEEN DATA
# ─────────────────────────────────────────
def run_inference(target_name, unseen_input_path):
    print(f"\n{'='*50}")
    print(f"  Inference — XGBoost | {target_name}")
    print(f"{'='*50}")

    model  = joblib.load(f'{SAVE_DIR}/model_{target_name}.pkl')
    scaler = joblib.load(f'{SAVE_DIR}/scaler_{target_name}.pkl')

    df = pd.read_csv(unseen_input_path)
    df = df.sort_values('timestamp').reset_index(drop=True)
    df = df.drop(columns=['timestamp']).fillna(method='ffill')
    df = clip_outliers(df)

    X_scaled    = scaler.transform(df[INPUT_FEATURES])
    predictions = model.predict(X_scaled)

    print(f"  Predictions shape : {predictions.shape}")
    print(f"  Min  : {predictions.min():.3f}")
    print(f"  Max  : {predictions.max():.3f}")
    print(f"  Mean : {predictions.mean():.3f}")

    plt.figure(figsize=(14, 5))
    plt.plot(predictions, color='#F39C12', linewidth=1.0, label='Predicted')
    plt.title(f'Inference — XGBoost — {target_name}')
    plt.xlabel('Time Steps')
    plt.ylabel('Temperature')
    plt.legend()
    plt.tight_layout()
    path = f'{SAVE_DIR}/inference_{target_name}.png'
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Plot saved → {path}")

    out_df = pd.DataFrame({f'predicted_{target_name}': predictions})
    csv_path = f'{SAVE_DIR}/inference_{target_name}.csv'
    out_df.to_csv(csv_path, index=False)
    print(f"  CSV saved  → {csv_path}")

    return predictions


# ─────────────────────────────────────────
#  RUN
# ─────────────────────────────────────────
if __name__ == '__main__':

    # ── Train ALL targets ──────────────────
    run_all()

    # ── Train ONE target ───────────────────
    # run_one('temp9_stn5')

    # ── Inference on unseen ────────────────
    # run_inference('temp9_stn5', 'data/unseen_inputs.csv')
