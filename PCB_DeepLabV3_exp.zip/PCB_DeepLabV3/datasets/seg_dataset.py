"""
Dataset loader for PCB-DeepLabV3 training.

Expects this folder layout:
    dataset_root/
    ├── images/          raw X-ray images  (.png / .jpg)
    ├── masks/           segmentation masks (.png, same stem as image)
    ├── train.txt        one filename stem per line  (no extension)
    └── val.txt

Mask pixel values accepted (auto-detected):
  • CVAT grayscale index:  0 = background,  1  = void
  • CVAT binary white:     0 = background,  255 = void
  • RGB colour mask:       any non-black pixel → void

Run  preprocessing/check_masks.py  first to confirm your mask format.
"""

import os
import numpy as np
from PIL import Image

import torch
from torch.utils.data import Dataset
import torchvision.transforms.functional as TF
import random


# ── Augmentation helpers ──────────────────────────────────────────────────────

def _random_hflip(image, mask):
    if random.random() > 0.5:
        image = TF.hflip(image)
        mask  = TF.hflip(mask)
    return image, mask


def _random_vflip(image, mask):
    if random.random() > 0.5:
        image = TF.vflip(image)
        mask  = TF.vflip(mask)
    return image, mask


def _random_rotate(image, mask, degrees=10):
    angle = random.uniform(-degrees, degrees)
    image = TF.rotate(image, angle)
    mask  = TF.rotate(mask,  angle)
    return image, mask


def _random_crop(image, mask, base_size, crop_size):
    """Scale slightly then crop to crop_size."""
    scale = random.uniform(0.5, 2.0)
    new_h = int(base_size * scale)
    new_w = int(base_size * scale)
    image = TF.resize(image, (new_h, new_w), interpolation=Image.BILINEAR)
    mask  = TF.resize(mask,  (new_h, new_w), interpolation=Image.NEAREST)

    # Pad if smaller than crop_size
    pad_h = max(crop_size - new_h, 0)
    pad_w = max(crop_size - new_w, 0)
    if pad_h > 0 or pad_w > 0:
        image = TF.pad(image, (0, 0, pad_w, pad_h), fill=0)
        mask  = TF.pad(mask,  (0, 0, pad_w, pad_h), fill=0)

    # Random crop
    i, j, h, w = torch.randint(0, new_h + pad_h - crop_size + 1, (1,)).item(), \
                  torch.randint(0, new_w + pad_w - crop_size + 1, (1,)).item(), \
                  crop_size, crop_size
    image = TF.crop(image, i, j, h, w)
    mask  = TF.crop(mask,  i, j, h, w)
    return image, mask


# ── Mask normalisation ────────────────────────────────────────────────────────

def load_mask(path):
    """
    Load a mask PNG and return a numpy array of class indices (dtype uint8).
    Handles:
      - Single-channel index masks (values 0, 1)
      - Single-channel binary masks (values 0, 255) → converted to 0/1
      - RGB/RGBA masks → non-black pixels become class 1
    """
    mask_img = Image.open(path)

    # Convert RGBA to RGB first if needed
    if mask_img.mode == 'RGBA':
        mask_img = mask_img.convert('RGB')

    if mask_img.mode == 'RGB':
        arr = np.array(mask_img)
        # Any non-black pixel = void (class 1)
        mask = (arr.sum(axis=2) > 0).astype(np.uint8)
    else:
        # Grayscale / palette
        arr = np.array(mask_img.convert('L'))
        if arr.max() > 1:
            # Treat 128+ as foreground (handles 255-based binary masks)
            mask = (arr >= 128).astype(np.uint8)
        else:
            mask = arr.astype(np.uint8)

    return mask          # shape [H, W], values in {0, 1}


# ── Main Dataset class ────────────────────────────────────────────────────────

class VOCSegDataset(Dataset):
    """
    Parameters
    ----------
    root        : path to dataset root (contains images/, masks/, train.txt, val.txt)
    split       : 'train' or 'val'
    input_size  : (H, W) tuple to resize all images/masks to
    augment     : apply random flips + rotation (only for 'train')
    """

    MEAN = [0.485, 0.456, 0.406]
    STD  = [0.229, 0.224, 0.225]

    def __init__(self, root, split='train', input_size=(512, 512), augment=True):
        super().__init__()
        self.root       = root
        self.split      = split
        self.input_size = input_size
        self.augment    = augment and (split == 'train')

        split_file = os.path.join(root, f'{split}.txt')
        if not os.path.exists(split_file):
            raise FileNotFoundError(
                f"Split file not found: {split_file}\n"
                f"Run  python preprocessing/prepare_splits.py  first."
            )

        with open(split_file) as f:
            self.ids = [line.strip() for line in f if line.strip()]

        if len(self.ids) == 0:
            raise ValueError(f"{split_file} is empty.")

        self.img_dir  = os.path.join(root, 'images')
        self.mask_dir = os.path.join(root, 'masks')

    def __len__(self):
        return len(self.ids)

    def _find_image(self, stem):
        """Find image file regardless of extension."""
        for ext in ('.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp'):
            p = os.path.join(self.img_dir, stem + ext)
            if os.path.exists(p):
                return p
        raise FileNotFoundError(
            f"No image found for stem '{stem}' in {self.img_dir}"
        )

    def _find_mask(self, stem):
        for ext in ('.png', '.jpg', '.jpeg'):
            p = os.path.join(self.mask_dir, stem + ext)
            if os.path.exists(p):
                return p
        raise FileNotFoundError(
            f"No mask found for stem '{stem}' in {self.mask_dir}"
        )

    def __getitem__(self, idx):
        stem = self.ids[idx]

        # ── Load image ────────────────────────────────────────────────────
        img_path = self._find_image(stem)
        image = Image.open(img_path).convert('RGB')

        # ── Load mask ─────────────────────────────────────────────────────
        mask_path = self._find_mask(stem)
        mask_arr  = load_mask(mask_path)                  # numpy [H, W], {0,1}
        mask_pil  = Image.fromarray(mask_arr, mode='L')   # PIL for transforms

        # ── Resize ────────────────────────────────────────────────────────
        image = image.resize(self.input_size[::-1], Image.BILINEAR)   # (W, H)
        mask_pil = mask_pil.resize(self.input_size[::-1], Image.NEAREST)

        # ── Augmentation (training only) ──────────────────────────────────
        if self.augment:
            image, mask_pil = _random_hflip(image, mask_pil)
            image, mask_pil = _random_vflip(image, mask_pil)
            image, mask_pil = _random_rotate(image, mask_pil, degrees=15)

        # ── To tensor + normalise image ────────────────────────────────────
        image_tensor = TF.to_tensor(image)                # [3, H, W] float32 0-1
        image_tensor = TF.normalize(image_tensor, self.MEAN, self.STD)

        mask_tensor = torch.from_numpy(
            np.array(mask_pil, dtype=np.int64)
        )                                                  # [H, W] int64 {0,1}

        return image_tensor, mask_tensor, stem
