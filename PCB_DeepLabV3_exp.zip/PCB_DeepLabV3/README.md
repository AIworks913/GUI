# PCB-DeepLabV3 — Complete Training Pipeline

Void defect segmentation in X-ray images of chip solder joints.  
Based on the paper: **"Segmentation of void defects in X-ray images of chip solder joints based on PCB-DeepLabV3 algorithm"** (Scientific Reports, 2024).

---

## What is in this package

| File / Folder | Purpose |
|---|---|
| `nets/deeplabv3_plus.py` | **Full PCB-DeepLabV3 model** (MobileNetV2 + AMTPNet + ASPP + Decoder). This is the paper's published code with two bugs fixed — see below. |
| `nets/mobilenetv2.py` | MobileNetV2 backbone wrapper (uses torchvision pretrained weights) |
| `preprocessing/cut_images.py` | Paper's original image cropping script, enhanced to also crop masks |
| `preprocessing/prepare_splits.py` | Splits your dataset into train.txt / val.txt |
| `preprocessing/check_masks.py` | Inspect your CVAT masks before training |
| `datasets/seg_dataset.py` | PyTorch Dataset — reads images + PNG masks from CVAT |
| `utils/metrics.py` | mIOU, MPA, CPA, Recall (paper's 4 evaluation metrics) |
| `utils/losses.py` | CrossEntropy / Dice / Combined loss |
| `train.py` | Training script with exact Table 1 hyperparameters |
| `evaluate.py` | Full evaluation on val set |
| `predict.py` | Inference on single image or folder, saves overlay visualisation |

---

## Bugs fixed in the paper's published code

The paper's GitHub repo (`jackong180/...`) only contained partial code with two issues that would crash at runtime:

**Bug 1 — `high_feature_attetion` called but never defined**  
In `forward()`, the code called `x = self.high_feature_attetion(x)` but this attribute was never created in `__init__`. Fixed by removing that line — the ASPP output is fed directly to the decoder, matching the architecture diagram in Figure 2.

**Bug 2 — Channel dimension mismatch in SEblock**  
The shortcut convolutions output 48 channels each (1x1, 3x3, 5x5), giving 3×48=144 per branch, but `SEblock` was initialised with `96`. This would crash with a shape error. Fixed: each shortcut conv now outputs `low_level_channels = 32`, giving 3×32=96 per branch, matching `SEblock(96)`. Three branches concatenated = 288, matching `low_conv_cat(288→48)`.

---

## Step-by-step: how to run training

### 0. Install dependencies

```bash
pip install -r requirements.txt
```

Needs Python 3.8+ and PyTorch with CUDA if training on GPU.  
The paper used: NVIDIA RTX 3070 (8GB), Windows 10, PyTorch.

---

### 1. Organise your dataset

Your dataset must follow this exact folder structure:

```
your_dataset/
├── images/          ← X-ray images  (.png or .jpg)
└── masks/           ← Segmentation masks from CVAT (.png, same filename stem)
```

**Your mask PNG files** (from CVAT) can be any of these formats — the loader handles all automatically:
- Grayscale index: pixel = 0 (background) or 1 (void)
- Binary white: pixel = 0 (background) or 255 (void)
- RGB: non-black pixels = void

To verify your masks are being read correctly, run:

```bash
python preprocessing/check_masks.py --masks /path/to/your_dataset/masks --n 10
```

---

### 2. (Optional) Crop large board-level images

**Only do this step if your images are large full-board X-ray scans** (like the Kaggle hellastudy dataset). If your images are already cropped to individual chip regions, skip directly to Step 3.

The paper crops each image into a 3×2 grid (6 tiles), discards tiles with no void pixels, and discards tiles where voids < 5% of the tile area. This expanded the original 450 images to 4128 training tiles.

```bash
python preprocessing/cut_images.py \
    --images    /path/to/original/images \
    --masks     /path/to/original/masks \
    --out_images /path/to/cropped/images \
    --out_masks  /path/to/cropped/masks \
    --rows 3 --cols 2 --threshold 0.05
```

If your images have a clear non-chip border, also add crop coordinates to remove the edge region:
```bash
    --crop_left 10 --crop_top 10 --crop_right 990 --crop_bottom 990
```
(Adjust these pixel values to match your actual image dimensions.)

After this step, point all subsequent commands at the **cropped** dataset directory.

---

### 3. Create train/val split

```bash
python preprocessing/prepare_splits.py \
    --dataset /path/to/your_dataset \
    --val_ratio 0.2 \
    --seed 42
```

This creates `train.txt` and `val.txt` in your dataset root. An 80/20 split is recommended. The paper trained on the full dataset so no exact split ratio was specified.

---

### 4. Train the model

```bash
python train.py --dataset /path/to/your_dataset
```

This uses **exactly the hyperparameters from Table 1 of the paper**:

| Parameter | Value |
|---|---|
| Epochs | 100 |
| Batch size | 4 |
| Initial LR | 0.007 |
| Min LR | 0.0001 |
| Optimizer | SGD |
| Momentum | 0.9 |
| Weight decay | 0.0001 |
| LR decay | Cosine |
| Early stop patience | 3 epochs |

Checkpoints are saved to `./checkpoints/`:
- `best.pth` — best validation loss model
- `last.pth` — most recent epoch

**Additional options:**

```bash
# Resume from a checkpoint
python train.py --dataset /path/to/dataset --resume ./checkpoints/last.pth

# Use combined CE+Dice loss if class imbalance is a problem
python train.py --dataset /path/to/dataset --loss combined

# Up-weight void class in CE loss (try 2.0-5.0 if recall is low)
python train.py --dataset /path/to/dataset --void_weight 3.0

# Specify GPU device explicitly
python train.py --dataset /path/to/dataset --device cuda:0

# Change input image size (default 512)
python train.py --dataset /path/to/dataset --input_size 416
```

---

### 5. Evaluate

```bash
python evaluate.py \
    --dataset    /path/to/your_dataset \
    --checkpoint ./checkpoints/best.pth
```

Output (matching the paper's Table 3 format):
```
── Evaluation Results ──────────────────
  mPA  (%): 85.88
  mIOU (%): 81.69
  CPA  (%): 90.09
  Recall(%): 85.96
────────────────────────────────────────
```

---

### 6. Run inference / prediction

```bash
# Single image
python predict.py \
    --input    /path/to/image.png \
    --checkpoint ./checkpoints/best.pth

# Folder of images
python predict.py \
    --input    /path/to/test_images/ \
    --checkpoint ./checkpoints/best.pth \
    --output   ./predictions
```

Saves for each image:
- `stem_result.png` — 3-panel side-by-side: Original | Red overlay | Binary mask
- `stem_mask.png` — Raw binary segmentation mask (white = void)

---

## Expected results (from paper, Table 3)

| Model | mIOU (%) | FPS |
|---|---|---|
| U-net | 68.19 | 70.65 |
| SegNet | 74.36 | 64.26 |
| PSPNet | 79.58 | 74.34 |
| DeepLabV3 | 62.47 | 68.42 |
| **PCB-DeepLabV3 (ours)** | **81.69** | **78.81** |

Your results may vary depending on dataset size, annotation quality, and train/val split.

---

## Architecture summary

```
Input [B, 3, H, W]
    │
    ▼
MobileNetV2 backbone (dilated, downsample_factor=16)
    ├── Bottleneck-3 rep 1  →  low_feat1 [B, 32, H/8, W/8]
    ├── Bottleneck-3 rep 2  →  low_feat2 [B, 32, H/8, W/8]
    ├── Bottleneck-3 rep 3  →  low_feat3 [B, 32, H/8, W/8]
    └── Backbone output     →  high_feat [B, 320, H/16, W/16]
                                    │
                                   ASPP
                                    │
                              [B, 256, H/16, W/16]

AMTPNet (applied to each of low_feat1/2/3):
    For each branch:
        1×1 conv + 3×3 conv + 5×5 conv  →  each 32 channels
        Concat  →  [B, 96, H/8, W/8]
        SE channel attention  →  [B, 96, H/8, W/8]
    Concat 3 branches  →  [B, 288, H/8, W/8]
    1×1 conv  →  [B, 48, H/8, W/8]

Decoder:
    Upsample ASPP output to H/8
    Concat [256 + 48]  →  [B, 304, H/8, W/8]
    3×3 conv × 2  →  [B, 256, H/8, W/8]
    1×1 conv  →  [B, num_classes, H/8, W/8]
    Bilinear upsample  →  [B, num_classes, H, W]
```

---

## Troubleshooting

**CUDA out of memory**  
Reduce `--batch_size` to 2 or 1. If still OOM, also reduce `--input_size` to 384 or 320.

**mIOU is very low (< 50%)**  
This usually means a mask value issue. Run `check_masks.py` first. Also try `--loss combined` or `--void_weight 3.0` if void regions are rare in your images.

**FileNotFoundError for train.txt**  
Run `prepare_splits.py` before `train.py`.

**No improvement from the start (loss stays flat)**  
Check that your masks contain non-zero void pixels. Also confirm images and masks have matching filenames.

**Training is slow without GPU**  
On CPU, reduce `--num_workers` to 0 and `--input_size` to 256 for testing.

---

## Citation

```bibtex
@article{kong2024segmentation,
  title={Segmentation of void defects in X-ray images of chip solder joints based on PCB-DeepLabV3 algorithm},
  author={Kong, Defeng and Hu, Xinyu and Gong, Ziang and Zhang, Daode},
  journal={Scientific Reports},
  volume={14},
  pages={11925},
  year={2024},
  doi={10.1038/s41598-024-61643-w}
}
```
