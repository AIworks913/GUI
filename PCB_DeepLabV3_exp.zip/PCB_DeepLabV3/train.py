"""
train.py — PCB-DeepLabV3 training script.

Hyperparameters match Table 1 of the paper exactly:
  Iterations   : 100 epochs
  Batch size   : 4
  Initial LR   : 0.007
  Min LR       : 0.0001
  Optimizer    : SGD  (momentum=0.9, weight_decay=0.0001)
  LR decay     : Cosine
  Early stop   : patience=3  (stop if val loss does not improve for 3 epochs)

Usage:
    python train.py --dataset /path/to/dataset --save_dir ./checkpoints

Quick start with defaults:
    python train.py --dataset ./dataset
"""

import os
import sys
import time
import argparse
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import CosineAnnealingLR

from nets.deeplabv3_plus import DeepLab
from datasets.seg_dataset import VOCSegDataset
from utils.metrics import SegMetrics
from utils.losses  import build_loss


# ── Argument parsing ──────────────────────────────────────────────────────────

def get_args():
    p = argparse.ArgumentParser(description='Train PCB-DeepLabV3')

    # Required
    p.add_argument('--dataset',   required=True,
                   help='Path to dataset root (must contain images/, masks/, train.txt, val.txt)')

    # Optional — model
    p.add_argument('--num_classes',       type=int,   default=2,
                   help='Number of classes incl. background (default: 2 → background + void)')
    p.add_argument('--input_size',        type=int,   default=512,
                   help='Square input size in pixels (default: 512)')
    p.add_argument('--downsample_factor', type=int,   default=16, choices=[8, 16])
    p.add_argument('--pretrained',        action='store_true', default=True,
                   help='Use ImageNet-pretrained MobileNetV2 backbone (default: True)')
    p.add_argument('--no_pretrained',     action='store_false', dest='pretrained')

    # Optional — training
    p.add_argument('--epochs',        type=int,   default=100)
    p.add_argument('--batch_size',    type=int,   default=4)
    p.add_argument('--lr',            type=float, default=0.007)
    p.add_argument('--min_lr',        type=float, default=0.0001)
    p.add_argument('--momentum',      type=float, default=0.9)
    p.add_argument('--weight_decay',  type=float, default=0.0001)
    p.add_argument('--num_workers',   type=int,   default=4)
    p.add_argument('--patience',      type=int,   default=3,
                   help='Early-stop patience: stop after N epochs without val improvement')

    # Optional — loss
    p.add_argument('--loss',         default='ce', choices=['ce', 'dice', 'combined'],
                   help="Loss function: 'ce' (paper default), 'dice', or 'combined' CE+Dice")
    p.add_argument('--void_weight',  type=float, default=None,
                   help='Up-weight the void class in CE loss (e.g. 3.0). None = equal weights.')

    # Optional — I/O
    p.add_argument('--save_dir',     default='./checkpoints')
    p.add_argument('--resume',       default=None,
                   help='Path to checkpoint to resume from')
    p.add_argument('--device',       default='auto',
                   help="'auto', 'cuda', 'cpu'")

    return p.parse_args()


# ── Device setup ──────────────────────────────────────────────────────────────

def get_device(choice):
    if choice == 'auto':
        return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    return torch.device(choice)


# ── Training epoch ────────────────────────────────────────────────────────────

def train_one_epoch(model, loader, optimizer, criterion, device, epoch, total_epochs):
    model.train()
    total_loss = 0.0
    n_batches  = len(loader)

    for i, (images, masks, _) in enumerate(loader):
        images = images.to(device)
        masks  = masks.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss    = criterion(outputs, masks)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        if (i + 1) % max(1, n_batches // 5) == 0 or (i + 1) == n_batches:
            pct = 100.0 * (i + 1) / n_batches
            print(f"  Epoch [{epoch}/{total_epochs}]  "
                  f"Batch [{i+1}/{n_batches}] ({pct:.0f}%)  "
                  f"Loss: {loss.item():.4f}")

    return total_loss / n_batches


# ── Validation epoch ──────────────────────────────────────────────────────────

def validate(model, loader, criterion, device, metrics):
    model.eval()
    total_loss = 0.0
    metrics.reset()

    with torch.no_grad():
        for images, masks, _ in loader:
            images = images.to(device)
            masks  = masks.to(device)

            outputs = model(images)
            loss    = criterion(outputs, masks)
            total_loss += loss.item()

            preds = outputs.argmax(dim=1)
            metrics.update(preds, masks)

    return total_loss / len(loader), metrics.compute()


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    args   = get_args()
    device = get_device(args.device)
    print(f"\n{'='*60}")
    print(f"  PCB-DeepLabV3 Training")
    print(f"{'='*60}")
    print(f"  Dataset   : {args.dataset}")
    print(f"  Device    : {device}")
    print(f"  Epochs    : {args.epochs}")
    print(f"  Batch size: {args.batch_size}")
    print(f"  LR        : {args.lr}  →  {args.min_lr}  (cosine)")
    print(f"  Loss      : {args.loss}")
    print(f"{'='*60}\n")

    os.makedirs(args.save_dir, exist_ok=True)
    input_size = (args.input_size, args.input_size)

    # ── Datasets & loaders ────────────────────────────────────────────────
    train_ds = VOCSegDataset(args.dataset, split='train',
                             input_size=input_size, augment=True)
    val_ds   = VOCSegDataset(args.dataset, split='val',
                             input_size=input_size, augment=False)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              shuffle=True,  num_workers=args.num_workers,
                              pin_memory=True, drop_last=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size,
                              shuffle=False, num_workers=args.num_workers,
                              pin_memory=True)

    print(f"  Train samples : {len(train_ds)}")
    print(f"  Val samples   : {len(val_ds)}\n")

    # ── Model ─────────────────────────────────────────────────────────────
    model = DeepLab(
        num_classes       = args.num_classes,
        backbone          = 'mobilenet',
        pretrained        = args.pretrained,
        downsample_factor = args.downsample_factor,
    ).to(device)

    # Multi-GPU support
    if torch.cuda.device_count() > 1:
        print(f"  Using {torch.cuda.device_count()} GPUs\n")
        model = nn.DataParallel(model)

    # ── Loss, Optimizer, Scheduler ────────────────────────────────────────
    criterion = build_loss(args.loss, args.num_classes, args.void_weight).to(device)

    optimizer = torch.optim.SGD(
        model.parameters(),
        lr           = args.lr,
        momentum     = args.momentum,
        weight_decay = args.weight_decay,
    )

    scheduler = CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=args.min_lr
    )

    # ── Resume ────────────────────────────────────────────────────────────
    start_epoch   = 1
    best_val_loss = float('inf')
    no_improve    = 0

    if args.resume and os.path.exists(args.resume):
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt['model_state'])
        optimizer.load_state_dict(ckpt['optimizer_state'])
        scheduler.load_state_dict(ckpt['scheduler_state'])
        start_epoch   = ckpt['epoch'] + 1
        best_val_loss = ckpt.get('best_val_loss', float('inf'))
        no_improve    = ckpt.get('no_improve', 0)
        print(f"  Resumed from epoch {ckpt['epoch']}  (best val loss: {best_val_loss:.4f})\n")

    # ── Training loop ─────────────────────────────────────────────────────
    metrics   = SegMetrics(num_classes=args.num_classes)
    train_log = []

    for epoch in range(start_epoch, args.epochs + 1):
        t0 = time.time()

        # Train
        train_loss = train_one_epoch(
            model, train_loader, optimizer, criterion, device, epoch, args.epochs
        )

        # Validate
        val_loss, val_metrics = validate(model, val_loader, criterion, device, metrics)

        # LR step
        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']

        elapsed = time.time() - t0
        print(f"\n── Epoch {epoch}/{args.epochs}  ({elapsed:.1f}s) ──────────────────────────")
        print(f"  Train Loss : {train_loss:.4f}")
        print(f"  Val   Loss : {val_loss:.4f}")
        for k, v in val_metrics.items():
            print(f"  {k}: {v:.2f}")
        print(f"  LR         : {current_lr:.6f}")

        # Log
        train_log.append({
            'epoch': epoch,
            'train_loss': train_loss,
            'val_loss':   val_loss,
            **val_metrics,
            'lr': current_lr,
        })

        # ── Checkpoint: always save latest ────────────────────────────────
        ckpt = {
            'epoch':           epoch,
            'model_state':     model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'scheduler_state': scheduler.state_dict(),
            'val_metrics':     val_metrics,
            'best_val_loss':   best_val_loss,
            'no_improve':      no_improve,
        }
        torch.save(ckpt, os.path.join(args.save_dir, 'last.pth'))

        # ── Checkpoint: save best model ───────────────────────────────────
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            no_improve    = 0
            torch.save(ckpt, os.path.join(args.save_dir, 'best.pth'))
            print(f"  ✓ New best model saved  (val loss {best_val_loss:.4f})")
        else:
            no_improve += 1
            print(f"  No improvement for {no_improve} epoch(s)  "
                  f"(best: {best_val_loss:.4f})")

        # ── Early stopping ────────────────────────────────────────────────
        if no_improve >= args.patience:
            print(f"\n  Early stopping triggered after {no_improve} epochs without improvement.")
            break

        print()

    # ── Save training log ─────────────────────────────────────────────────
    log_path = os.path.join(args.save_dir, 'training_log.csv')
    import csv
    if train_log:
        with open(log_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=train_log[0].keys())
            writer.writeheader()
            writer.writerows(train_log)
        print(f"\nTraining log saved to {log_path}")

    print(f"\nTraining complete.  Best val loss: {best_val_loss:.4f}")
    print(f"Best model saved to: {os.path.join(args.save_dir, 'best.pth')}")


if __name__ == '__main__':
    main()
