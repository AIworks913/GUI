"""
PCB-DeepLabV3: Complete model integrating MobileNetV2 backbone + AMTPNet + ASPP Decoder.

Source: Based on the paper's published code (jackong180/X-ray-Void-Defect-Detection...)
        with two bugs fixed:
        Bug 1 - self.high_feature_attetion was called in forward() but never defined.
                Fixed by removing that call (ASPP output is used directly, no separate
                high-level attention in the paper's architecture diagram).
        Bug 2 - shortcut_conv layers output 48 channels but SEblock was initialized
                with 96. Fixed by setting conv output = low_level_channels (32),
                giving concat dim = 3*32 = 96, which matches SEblock(96).
                Three branches then give 3*96 = 288, matching low_conv_cat(288->48).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
from nets.mobilenetv2 import mobilenetv2


# ─────────────────────────────────────────────
# MobileNetV2 backbone (dilated, 3 low-level outputs)
# ─────────────────────────────────────────────
class MobileNetV2(nn.Module):
    def __init__(self, downsample_factor=16, pretrained=True):
        super(MobileNetV2, self).__init__()
        model = mobilenetv2(pretrained)
        self.features = model.features[:-1]          # Drop classifier conv
        self.total_idx = len(self.features)
        self.down_idx = [2, 4, 7, 14]                # Stride-2 layer indices

        if downsample_factor == 8:
            for i in range(self.down_idx[-2], self.down_idx[-1]):
                self.features[i].apply(partial(self._nostride_dilate, dilate=2))
            for i in range(self.down_idx[-1], self.total_idx):
                self.features[i].apply(partial(self._nostride_dilate, dilate=4))
        elif downsample_factor == 16:
            for i in range(self.down_idx[-1], self.total_idx):
                self.features[i].apply(partial(self._nostride_dilate, dilate=2))

    def _nostride_dilate(self, m, dilate):
        classname = m.__class__.__name__
        if classname.find('Conv') != -1:
            if m.stride == (2, 2):
                m.stride = (1, 1)
                if m.kernel_size == (3, 3):
                    m.dilation = (dilate // 2, dilate // 2)
                    m.padding  = (dilate // 2, dilate // 2)
            else:
                if m.kernel_size == (3, 3):
                    m.dilation = (dilate, dilate)
                    m.padding  = (dilate, dilate)

    def forward(self, x):
        # Three outputs from bottleneck-3 repetitions (all 32-channel feature maps)
        low_level_features1 = self.features[:5](x)   # 32-ch
        low_level_features2 = self.features[:6](x)   # 32-ch
        low_level_features3 = self.features[:7](x)   # 32-ch
        x = self.features[7:](low_level_features3)   # 320-ch (high-level)
        return low_level_features1, low_level_features2, low_level_features3, x


# ─────────────────────────────────────────────
# SE (Squeeze-and-Excitation) channel attention
# ─────────────────────────────────────────────
class SEblock(nn.Module):
    def __init__(self, channels, ratio=16):
        super(SEblock, self).__init__()
        hidden_channels = max(channels // ratio, 1)
        self.attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, hidden_channels, 1, 1, 0),
            nn.ReLU(),
            nn.Conv2d(hidden_channels, channels, 1, 1, 0),
            nn.Sigmoid()
        )

    def forward(self, x):
        weights = self.attn(x)
        return weights * x


# ─────────────────────────────────────────────
# ASPP module (Atrous Spatial Pyramid Pooling)
# ─────────────────────────────────────────────
class ASPP(nn.Module):
    def __init__(self, dim_in, dim_out, rate=1, bn_mom=0.1):
        super(ASPP, self).__init__()
        self.branch1 = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, 1, 1, padding=0, dilation=rate, bias=True),
            nn.BatchNorm2d(dim_out, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )
        self.branch2 = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, 3, 1, padding=6*rate,  dilation=6*rate,  bias=True),
            nn.BatchNorm2d(dim_out, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )
        self.branch3 = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, 3, 1, padding=12*rate, dilation=12*rate, bias=True),
            nn.BatchNorm2d(dim_out, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )
        self.branch4 = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, 3, 1, padding=18*rate, dilation=18*rate, bias=True),
            nn.BatchNorm2d(dim_out, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )
        self.branch5_conv = nn.Conv2d(dim_in, dim_out, 1, 1, 0, bias=True)
        self.branch5_bn   = nn.BatchNorm2d(dim_out, momentum=bn_mom)
        self.branch5_relu = nn.ReLU(inplace=True)
        self.conv_cat = nn.Sequential(
            nn.Conv2d(dim_out * 5, dim_out, 1, 1, padding=0, bias=True),
            nn.BatchNorm2d(dim_out, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        b, c, row, col = x.size()
        conv1x1   = self.branch1(x)
        conv3x3_1 = self.branch2(x)
        conv3x3_2 = self.branch3(x)
        conv3x3_3 = self.branch4(x)
        # Global average pooling branch
        gf = torch.mean(x, 2, True)
        gf = torch.mean(gf, 3, True)
        gf = self.branch5_relu(self.branch5_bn(self.branch5_conv(gf)))
        gf = F.interpolate(gf, (row, col), mode='bilinear', align_corners=True)
        result = self.conv_cat(torch.cat([conv1x1, conv3x3_1, conv3x3_2, conv3x3_3, gf], dim=1))
        return result


# ─────────────────────────────────────────────
# Full PCB-DeepLabV3 model  (AMTPNet embedded)
# ─────────────────────────────────────────────
class DeepLab(nn.Module):
    """
    PCB-DeepLabV3:  MobileNetV2 backbone  +  AMTPNet low-level fusion  +  ASPP  +  Decoder.

    Channel flow (MobileNetV2 path, downsample_factor=16):
      Input          : [B, 3, H, W]
      Low-level x3   : [B, 32, H/8,  W/8]     (bottleneck-3 repetitions)
      High-level     : [B, 320, H/16, W/16]   (after backbone)
      ASPP out       : [B, 256, H/16, W/16]
      Per-branch AMTPNet:
        1x1+3x3+5x5 each 32->32  → cat 96 → SEblock(96) → 96 ch
        3 branches   → cat 288   → Conv(288->48) → 48 ch  (low-level repr)
      Decoder concat : [B, 48+256, H/8, W/8]
      After 3x3 convs: [B, 256, H/8, W/8]
      Final upsample : [B, num_classes, H, W]
    """

    def __init__(self, num_classes=2, backbone="mobilenet", pretrained=True,
                 downsample_factor=16, bn_mom=0.1):
        super(DeepLab, self).__init__()

        if backbone == "mobilenet":
            self.backbone = MobileNetV2(downsample_factor=downsample_factor, pretrained=pretrained)
            in_channels       = 320
            low_level_channels = 32
        else:
            raise ValueError(f"Unsupported backbone '{backbone}'. Use 'mobilenet'.")

        # ASPP on high-level features
        self.aspp = ASPP(dim_in=in_channels, dim_out=256, rate=16 // downsample_factor)

        # ── AMTPNet: multi-scale low-level feature extraction ──────────────────
        # Each branch: three convs (1x1, 3x3, 5x5) on the same feature map
        # Output per conv  = low_level_channels (32)
        # Output per branch = 3 * 32 = 96
        # Channel attention applied per branch via SEblock(96)
        # Three branches concatenated → 3 * 96 = 288 → conv down to 48

        self.shortcut_conv_1x1 = nn.Sequential(
            nn.Conv2d(low_level_channels, low_level_channels, 1, padding=0),
            nn.BatchNorm2d(low_level_channels),
            nn.ReLU(inplace=True)
        )
        self.shortcut_conv_3x3 = nn.Sequential(
            nn.Conv2d(low_level_channels, low_level_channels, 3, padding=1),
            nn.BatchNorm2d(low_level_channels),
            nn.ReLU(inplace=True)
        )
        self.shortcut_conv_5x5 = nn.Sequential(
            nn.Conv2d(low_level_channels, low_level_channels, 5, padding=2),
            nn.BatchNorm2d(low_level_channels),
            nn.ReLU(inplace=True)
        )
        # SE attention on each branch concat (96 = 3 * 32)
        self.low_feature_attetion = SEblock(low_level_channels * 3)   # SEblock(96)

        # Merge all three branches (3 * 96 = 288) → 48 channels
        self.low_conv_cat = nn.Sequential(
            nn.Conv2d(low_level_channels * 3 * 3, 48, 1, 1, padding=0, bias=True),
            nn.BatchNorm2d(48, momentum=bn_mom),
            nn.ReLU(inplace=True)
        )

        # ── Decoder ────────────────────────────────────────────────────────────
        self.cat_conv = nn.Sequential(
            nn.Conv2d(48 + 256, 256, 3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Conv2d(256, 256, 3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
        )
        self.cls_conv = nn.Conv2d(256, num_classes, 1, stride=1)

    def _branch_amtp(self, feat):
        """Apply 1x1 + 3x3 + 5x5 convolutions, concat, then SE attention."""
        f1 = self.shortcut_conv_1x1(feat)
        f3 = self.shortcut_conv_3x3(feat)
        f5 = self.shortcut_conv_5x5(feat)
        cat = torch.cat([f1, f3, f5], dim=1)        # [B, 96, H, W]
        return self.low_feature_attetion(cat)        # [B, 96, H, W]  after SE

    def forward(self, x):
        H, W = x.size(2), x.size(3)

        # Backbone: 3 low-level feature maps + 1 high-level feature map
        ll1, ll2, ll3, x_high = self.backbone(x)

        # ASPP on high-level features
        x_high = self.aspp(x_high)                  # [B, 256, H/16, W/16]

        # AMTPNet: per-branch multi-scale attention
        b1 = self._branch_amtp(ll1)                 # [B, 96, H/8, W/8]
        b2 = self._branch_amtp(ll2)                 # [B, 96, H/8, W/8]
        b3 = self._branch_amtp(ll3)                 # [B, 96, H/8, W/8]

        # Longitudinal fusion of all three branches
        low_cat = torch.cat([b1, b2, b3], dim=1)   # [B, 288, H/8, W/8]
        low_feat = self.low_conv_cat(low_cat)        # [B, 48, H/8, W/8]

        # Upsample high-level to match low-level spatial size
        x_high = F.interpolate(x_high,
                               size=(low_feat.size(2), low_feat.size(3)),
                               mode='bilinear', align_corners=True)

        # Decoder: concat low + high, 3x3 convs, upsample to input size
        x = self.cat_conv(torch.cat([x_high, low_feat], dim=1))
        x = self.cls_conv(x)
        x = F.interpolate(x, size=(H, W), mode='bilinear', align_corners=True)
        return x


if __name__ == "__main__":
    # Quick shape-check
    model = DeepLab(num_classes=2, pretrained=False)
    model.eval()
    dummy = torch.randn(2, 3, 512, 512)
    with torch.no_grad():
        out = model(dummy)
    print(f"Input:  {dummy.shape}")
    print(f"Output: {out.shape}")   # Expected: [2, 2, 512, 512]
