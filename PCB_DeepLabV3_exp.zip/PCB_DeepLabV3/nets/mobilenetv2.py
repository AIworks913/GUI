"""
MobileNetV2 backbone for PCB-DeepLabV3.
Uses torchvision's pretrained MobileNetV2 weights.
"""
import torch
import torch.nn as nn

try:
    from torchvision.models import mobilenet_v2, MobileNet_V2_Weights

    def mobilenetv2(pretrained=True):
        if pretrained:
            model = mobilenet_v2(weights=MobileNet_V2_Weights.IMAGENET1K_V1)
        else:
            model = mobilenet_v2(weights=None)
        return model

except ImportError:
    # Fallback for older torchvision
    from torchvision.models import mobilenet_v2

    def mobilenetv2(pretrained=True):
        return mobilenet_v2(pretrained=pretrained)
