"""
================================================================================
AIRCRAFT TEMPERATURE PREDICTION - COMPLETE PYTORCH LSTM PIPELINE
Single File Implementation with PyTorch

All code in one file for easy use:
- Data preparation
- Model architecture
- Training
- Evaluation
- Prediction

Model saved in .pth format (PyTorch native)
================================================================================
"""

import os
import sys
import torch
import torch.nn as nn
import torch.utils.data as data
import numpy as np
import pandas as pd
import pickle
import json
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from typing import Tuple, Dict, List
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# ============================================================================
#                          CONFIGURATION SECTION
#                          (Modify these values)
# ============================================================================
# ============================================================================

class Config:
    """
    Configuration for Aircraft Temperature Prediction Model
    Modify these parameters to tune performance
    """
    
    # ========================================================================
    # DATA CONFIGURATION
    # ========================================================================
    
    # Sequence configuration
    LOOKBACK = 30                          # Number of past timesteps to use
    FORECAST_HORIZON = 1                   # Steps ahead to predict
    
    # File paths
    TRAINING_SORTIES = [
        'data/sortie_1.csv',
        'data/sortie_2.csv',
        'data/sortie_3.csv',
        'data/sortie_4.csv'
    ]
    TESTING_SORTIES = [
        'data/sortie_5.csv',
        'data/sortie_6.csv'
    ]
    
    # Column names
    TEMPERATURE_COLUMNS = [
        'temperature_1', 'temperature_2', 'temperature_3',
        'temperature_4', 'temperature_5'
    ]
    
    # ========================================================================
    # MODEL ARCHITECTURE CONFIGURATION
    # ========================================================================
    
    # LSTM dimensions
    HIDDEN_DIM_1 = 64          # First bidirectional LSTM: 64 forward + 64 backward = 128 output
    HIDDEN_DIM_2 = 32          # Second bidirectional LSTM: 32 forward + 32 backward = 64 output
    
    # Dense layer dimensions
    DENSE_DIM_1 = 128          # First dense layer
    DENSE_DIM_2 = 64           # Second dense layer
    
    # Dropout rates
    DROPOUT_RATE_1 = 0.2       # After first dense layer
    DROPOUT_RATE_2 = 0.15      # After second dense layer
    
    # Regularization
    L2_REGULARIZATION = 0.001   # L2 weight decay
    
    # LSTM activation
    LSTM_ACTIVATION = 'tanh'    # LSTM activation (tanh is standard)
    DENSE_ACTIVATION = 'relu'   # Dense layer activation
    
    # ========================================================================
    # TRAINING CONFIGURATION
    # ========================================================================
    
    # Batch and learning
    BATCH_SIZE = 64             # Samples per batch
    LEARNING_RATE = 0.001       # Initial learning rate
    NUM_EPOCHS = 200            # Maximum number of epochs
    VALIDATION_SPLIT = 0.1      # 10% of training data for validation
    
    # Early stopping
    PATIENCE = 25               # Number of epochs to wait for improvement
    MIN_IMPROVEMENT = 1e-4      # Minimum improvement in validation loss
    
    # Learning rate scheduler
    LR_FACTOR = 0.5            # Multiply learning rate by this factor
    LR_PATIENCE = 10           # Wait this many epochs before reducing LR
    MIN_LR = 1e-6              # Minimum learning rate
    
    # ========================================================================
    # DEVICE CONFIGURATION
    # ========================================================================
    
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    GPU_DEVICE_ID = 0           # Which GPU to use (0 is first GPU)
    
    # ========================================================================
    # OUTPUT CONFIGURATION
    # ========================================================================
    
    OUTPUT_DIR = 'outputs'
    
    # Save paths (.pth for PyTorch models)
    MODEL_PATH = f'{OUTPUT_DIR}/model.pth'
    SCALER_X_PATH = f'{OUTPUT_DIR}/scaler_X.pkl'
    SCALER_Y_PATH = f'{OUTPUT_DIR}/scaler_y.pkl'
    HISTORY_PATH = f'{OUTPUT_DIR}/training_history.json'
    PLOT_PATH = f'{OUTPUT_DIR}/training_curves.png'
    PREDICTIONS_PATH = f'{OUTPUT_DIR}/predictions.csv'
    
    # ========================================================================
    # LOGGING CONFIGURATION
    # ========================================================================
    
    PRINT_EVERY = 1             # Print stats every N epochs
    VERBOSE = True              # Print training progress
    SAVE_PLOTS = True           # Save training visualization
    
    # ========================================================================
    # RANDOM SEED (for reproducibility)
    # ========================================================================
    
    RANDOM_SEED = 42


# ============================================================================
# ============================================================================
#                          DATA PREPARATION
# ============================================================================
# ============================================================================

class DataPreparation:
    """Data loading, preprocessing, and sequence creation"""
    
    @staticmethod
    def load_sorties(sortie_files: List[str], verbose: bool = True) -> pd.DataFrame:
        """Load and combine multiple sortie CSV files"""
        if verbose:
            print("=" * 70)
            print("LOADING SORTIE DATA")
            print("=" * 70)
        
        data_list = []
        total_samples = 0
        
        for sortie_file in sortie_files:
            if not os.path.exists(sortie_file):
                raise FileNotFoundError(f"File not found: {sortie_file}")
            
            df = pd.read_csv(sortie_file)
            data_list.append(df)
            total_samples += len(df)
            
            if verbose:
                print(f"✓ {sortie_file:30} → {len(df):6} samples")
        
        combined_df = pd.concat(data_list, ignore_index=True)
        
        if verbose:
            print(f"\nTotal combined samples: {total_samples}")
            print(f"Columns: {list(combined_df.columns)}")
        
        return combined_df
    
    @staticmethod
    def extract_features_and_targets(
        df: pd.DataFrame,
        temperature_columns: List[str],
        verbose: bool = True
    ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Extract FDR sensor features and temperature targets"""
        
        if verbose:
            print("\n" + "=" * 70)
            print("EXTRACTING FEATURES AND TARGETS")
            print("=" * 70)
        
        # Extract FDR sensor columns
        fdr_columns = [col for col in df.columns 
                       if col not in temperature_columns + ['timestamp']]
        
        # Extract data
        X = df[fdr_columns].values
        y = df[temperature_columns].values
        
        if verbose:
            print(f"\nFDR Sensor Features ({len(fdr_columns)}):")
            for i, col in enumerate(fdr_columns[:5], 1):
                print(f"  {i}. {col}")
            if len(fdr_columns) > 5:
                print(f"  ... and {len(fdr_columns) - 5} more")
            
            print(f"\nTemperature Targets (5):")
            for i, col in enumerate(temperature_columns, 1):
                print(f"  {i}. {col}")
            
            print(f"\nData shapes:")
            print(f"  X (sensors): {X.shape}")
            print(f"  y (temperatures): {y.shape}")
        
        return X, y, fdr_columns
    
    @staticmethod
    def normalize_data(
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        verbose: bool = True
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, StandardScaler, StandardScaler]:
        """Normalize data using StandardScaler"""
        
        if verbose:
            print("\n" + "=" * 70)
            print("NORMALIZING DATA")
            print("=" * 70)
        
        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        
        if verbose:
            print("\nFitting scalers on training data...")
        
        X_train_scaled = scaler_X.fit_transform(X_train)
        y_train_scaled = scaler_y.fit_transform(y_train)
        
        if verbose:
            print("Transforming test data with training scalers...")
        
        X_test_scaled = scaler_X.transform(X_test)
        y_test_scaled = scaler_y.transform(y_test)
        
        if verbose:
            print(f"\n✓ Normalization complete (no data leakage)")
            print(f"  X_train: mean={X_train_scaled.mean():.4f}, std={X_train_scaled.std():.4f}")
            print(f"  y_train: mean={y_train_scaled.mean():.4f}, std={y_train_scaled.std():.4f}")
        
        return X_train_scaled, y_train_scaled, X_test_scaled, y_test_scaled, scaler_X, scaler_y
    
    @staticmethod
    def create_sequences(
        X: np.ndarray,
        y: np.ndarray,
        lookback: int = 30,
        forecast_horizon: int = 1,
        verbose: bool = True
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Create overlapping sequences for LSTM training"""
        
        if verbose:
            print("\n" + "=" * 70)
            print("CREATING LSTM SEQUENCES")
            print("=" * 70)
            print(f"\nParameters:")
            print(f"  Lookback window: {lookback} timesteps")
            print(f"  Forecast horizon: {forecast_horizon} step(s)")
        
        X_seq, y_seq = [], []
        
        for i in range(len(X) - lookback - forecast_horizon + 1):
            X_seq.append(X[i:i+lookback])
            y_seq.append(y[i+lookback+forecast_horizon-1])
        
        X_seq = np.array(X_seq)
        y_seq = np.array(y_seq)
        
        if verbose:
            print(f"\nSequences created:")
            print(f"  X_sequences shape: {X_seq.shape}")
            print(f"  y_sequences shape: {y_seq.shape}")
        
        return X_seq, y_seq
    
    @staticmethod
    def prepare_data(config: 'Config') -> dict:
        """Complete data preparation pipeline"""
        
        # Load data
        train_df = DataPreparation.load_sorties(config.TRAINING_SORTIES, verbose=config.VERBOSE)
        test_df = DataPreparation.load_sorties(config.TESTING_SORTIES, verbose=config.VERBOSE)
        
        # Extract features
        X_train_raw, y_train_raw, fdr_columns = DataPreparation.extract_features_and_targets(
            train_df, config.TEMPERATURE_COLUMNS, verbose=config.VERBOSE)
        X_test_raw, y_test_raw, _ = DataPreparation.extract_features_and_targets(
            test_df, config.TEMPERATURE_COLUMNS, verbose=config.VERBOSE)
        
        # Normalize
        X_train_scaled, y_train_scaled, X_test_scaled, y_test_scaled, scaler_X, scaler_y = \
            DataPreparation.normalize_data(X_train_raw, y_train_raw, X_test_raw, y_test_raw, 
                                          verbose=config.VERBOSE)
        
        # Create sequences
        if config.VERBOSE:
            print("\nCreating training sequences...")
        X_train_seq, y_train_seq = DataPreparation.create_sequences(
            X_train_scaled, y_train_scaled, config.LOOKBACK, config.FORECAST_HORIZON, 
            verbose=False)
        
        if config.VERBOSE:
            print(f"  X_train_seq shape: {X_train_seq.shape}")
            print(f"  y_train_seq shape: {y_train_seq.shape}")
            print("\nCreating testing sequences...")
        
        X_test_seq, y_test_seq = DataPreparation.create_sequences(
            X_test_scaled, y_test_scaled, config.LOOKBACK, config.FORECAST_HORIZON, 
            verbose=False)
        
        if config.VERBOSE:
            print(f"  X_test_seq shape: {X_test_seq.shape}")
            print(f"  y_test_seq shape: {y_test_seq.shape}")
            print("\n" + "=" * 70)
            print("DATA PREPARATION COMPLETE")
            print("=" * 70)
            print(f"\nTraining sequences: {X_train_seq.shape[0]:,}")
            print(f"Testing sequences: {X_test_seq.shape[0]:,}")
            print(f"Input features (FDR sensors): {len(fdr_columns)}")
            print(f"Output targets (Temperatures): 5")
            print(f"Sequence length (timesteps): {config.LOOKBACK}")
        
        return {
            'X_train': X_train_seq,
            'y_train': y_train_seq,
            'X_test': X_test_seq,
            'y_test': y_test_seq,
            'scaler_X': scaler_X,
            'scaler_y': scaler_y,
            'fdr_columns': fdr_columns,
            'n_features': X_train_seq.shape[2],
            'n_outputs': y_train_seq.shape[1]
        }


# ============================================================================
# ============================================================================
#                          LSTM MODEL ARCHITECTURE
# ============================================================================
# ============================================================================

class TemperatureLSTM(nn.Module):
    """Bidirectional LSTM model for temperature prediction"""
    
    def __init__(
        self,
        input_size: int,
        hidden_dim_1: int = 64,
        hidden_dim_2: int = 32,
        dense_dim_1: int = 128,
        dense_dim_2: int = 64,
        output_size: int = 5,
        dropout_rate_1: float = 0.2,
        dropout_rate_2: float = 0.15,
        l2_lambda: float = 0.001,
        device: str = 'cpu'
    ):
        """
        Initialize LSTM model
        
        Architecture:
        - BiLSTM(64) + LayerNorm
        - BiLSTM(32) + LayerNorm
        - Dense(128) + Dropout(0.2)
        - Dense(64) + Dropout(0.15)
        - Dense(5, linear)
        """
        super(TemperatureLSTM, self).__init__()
        
        self.input_size = input_size
        self.hidden_dim_1 = hidden_dim_1
        self.hidden_dim_2 = hidden_dim_2
        self.device = device
        
        # LSTM Layers
        self.lstm1 = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_dim_1,
            batch_first=True,
            bidirectional=True,
            dropout=0.15
        )
        self.layer_norm1 = nn.LayerNorm(2 * hidden_dim_1)
        
        self.lstm2 = nn.LSTM(
            input_size=2 * hidden_dim_1,
            hidden_size=hidden_dim_2,
            batch_first=True,
            bidirectional=True,
            dropout=0.15
        )
        self.layer_norm2 = nn.LayerNorm(2 * hidden_dim_2)
        
        # Dense Layers
        self.dense1 = nn.Linear(2 * hidden_dim_2, dense_dim_1)
        self.dropout1 = nn.Dropout(dropout_rate_1)
        
        self.dense2 = nn.Linear(dense_dim_1, dense_dim_2)
        self.dropout2 = nn.Dropout(dropout_rate_2)
        
        self.output_layer = nn.Linear(dense_dim_2, output_size)
        
        # Activation
        self.relu = nn.ReLU()
        
        self.to(device)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass"""
        # LSTM 1
        lstm1_out, _ = self.lstm1(x)
        lstm1_norm = self.layer_norm1(lstm1_out)
        
        # LSTM 2
        lstm2_out, _ = self.lstm2(lstm1_norm)
        lstm2_norm = self.layer_norm2(lstm2_out)
        
        # Take final timestep
        lstm_final = lstm2_norm[:, -1, :]
        
        # Dense layers
        dense1_out = self.dense1(lstm_final)
        dense1_relu = self.relu(dense1_out)
        dropout1_out = self.dropout1(dense1_relu)
        
        dense2_out = self.dense2(dropout1_out)
        dense2_relu = self.relu(dense2_out)
        dropout2_out = self.dropout2(dense2_relu)
        
        # Output
        output = self.output_layer(dropout2_out)
        
        return output
    
    def count_parameters(self) -> dict:
        """Count model parameters"""
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {'total': total, 'trainable': trainable}


# ============================================================================
# ============================================================================
#                          TRAINING UTILITIES
# ============================================================================
# ============================================================================

class EarlyStopping:
    """Early stopping to prevent overfitting"""
    
    def __init__(self, patience: int = 25, min_delta: float = 1e-4, verbose: bool = True):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        self.verbose = verbose
    
    def __call__(self, val_loss: float) -> bool:
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.verbose and self.counter == 1:
                print(f"    EarlyStopping counter: {self.counter}/{self.patience}")
            elif self.verbose and self.counter % 5 == 0:
                print(f"    EarlyStopping counter: {self.counter}/{self.patience}")
            
            if self.counter >= self.patience:
                self.early_stop = True
                if self.verbose:
                    print(f"    Early stopping triggered")
                return True
        
        return False


class LearningRateScheduler:
    """Learning rate scheduler with plateau reduction"""
    
    def __init__(self, optimizer: torch.optim.Optimizer, factor: float = 0.5, 
                 patience: int = 10, min_lr: float = 1e-6, verbose: bool = True):
        self.optimizer = optimizer
        self.factor = factor
        self.patience = patience
        self.min_lr = min_lr
        self.counter = 0
        self.best_loss = None
        self.verbose = verbose
    
    def step(self, val_loss: float):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self._reduce_lr()
                self.counter = 0
    
    def _reduce_lr(self):
        for param_group in self.optimizer.param_groups:
            old_lr = param_group['lr']
            new_lr = max(old_lr * self.factor, self.min_lr)
            param_group['lr'] = new_lr
            if self.verbose:
                print(f"    Reducing learning rate: {old_lr:.6f} → {new_lr:.6f}")


class Trainer:
    """Main trainer class"""
    
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        criterion: nn.Module,
        device: str,
        patience: int = 25,
        lr_factor: float = 0.5,
        min_lr: float = 1e-6,
        verbose: bool = True
    ):
        self.model = model
        self.optimizer = optimizer
        self.criterion = criterion
        self.device = device
        self.verbose = verbose
        
        self.early_stopping = EarlyStopping(patience=patience, verbose=verbose)
        self.lr_scheduler = LearningRateScheduler(
            optimizer, factor=lr_factor, patience=10, min_lr=min_lr, verbose=verbose)
        
        self.history = {
            'epoch': [],
            'train_loss': [],
            'val_loss': [],
            'train_mae': [],
            'val_mae': [],
            'learning_rate': []
        }
        
        self.best_val_loss = float('inf')
        self.best_epoch = 0
    
    def train_epoch(self, train_loader: data.DataLoader) -> Tuple[float, float]:
        """Train for one epoch"""
        self.model.train()
        
        total_loss = 0.0
        total_mae = 0.0
        num_batches = 0
        
        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(self.device)
            y_batch = y_batch.to(self.device)
            
            predictions = self.model(X_batch)
            loss = self.criterion(predictions, y_batch)
            
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            mae = torch.mean(torch.abs(predictions - y_batch))
            
            total_loss += loss.item()
            total_mae += mae.item()
            num_batches += 1
        
        return total_loss / num_batches, total_mae / num_batches
    
    def validate(self, val_loader: data.DataLoader) -> Tuple[float, float]:
        """Validate on validation set"""
        self.model.eval()
        
        total_loss = 0.0
        total_mae = 0.0
        num_batches = 0
        
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch = X_batch.to(self.device)
                y_batch = y_batch.to(self.device)
                
                predictions = self.model(X_batch)
                loss = self.criterion(predictions, y_batch)
                mae = torch.mean(torch.abs(predictions - y_batch))
                
                total_loss += loss.item()
                total_mae += mae.item()
                num_batches += 1
        
        return total_loss / num_batches, total_mae / num_batches
    
    def fit(
        self,
        train_loader: data.DataLoader,
        val_loader: data.DataLoader,
        num_epochs: int = 200,
        print_every: int = 1
    ) -> Dict:
        """Train model for multiple epochs"""
        print("\n" + "=" * 70)
        print("TRAINING MODEL")
        print("=" * 70)
        
        for epoch in range(1, num_epochs + 1):
            train_loss, train_mae = self.train_epoch(train_loader)
            val_loss, val_mae = self.validate(val_loader)
            current_lr = self.optimizer.param_groups[0]['lr']
            
            self.history['epoch'].append(epoch)
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['train_mae'].append(train_mae)
            self.history['val_mae'].append(val_mae)
            self.history['learning_rate'].append(current_lr)
            
            if epoch % print_every == 0:
                print(f"Epoch {epoch:3d}/{num_epochs} | "
                      f"Train Loss: {train_loss:.4f} | Train MAE: {train_mae:.4f} | "
                      f"Val Loss: {val_loss:.4f} | Val MAE: {val_mae:.4f} | "
                      f"LR: {current_lr:.6f}")
            
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.best_epoch = epoch
            
            self.lr_scheduler.step(val_loss)
            
            if self.early_stopping(val_loss):
                print(f"\nEarly stopping at epoch {epoch}")
                break
        
        print(f"\n✓ Training complete!")
        print(f"  Best epoch: {self.best_epoch}")
        print(f"  Best validation loss: {self.best_val_loss:.6f}")
        
        return self.history
    
    def save_history(self, path: str):
        """Save training history"""
        with open(path, 'w') as f:
            json.dump(self.history, f, indent=2)
        print(f"✓ Training history saved: {path}")


# ============================================================================
# ============================================================================
#                          EVALUATION & PREDICTION
# ============================================================================
# ============================================================================

def evaluate_model(
    model: nn.Module,
    test_loader: data.DataLoader,
    device: str,
    scaler_y = None,
    verbose: bool = True
) -> Dict:
    """Evaluate model on test set"""
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            
            predictions = model(X_batch)
            
            all_predictions.append(predictions.cpu().numpy())
            all_targets.append(y_batch.cpu().numpy())
    
    predictions = np.concatenate(all_predictions, axis=0)
    targets = np.concatenate(all_targets, axis=0)
    
    # Inverse transform
    if scaler_y is not None:
        predictions = scaler_y.inverse_transform(predictions)
        targets = scaler_y.inverse_transform(targets)
    
    # Calculate metrics
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - targets))
    
    # Per-temperature metrics
    per_temp_metrics = {}
    for i in range(predictions.shape[1]):
        mse_i = np.mean((predictions[:, i] - targets[:, i]) ** 2)
        rmse_i = np.sqrt(mse_i)
        mae_i = np.mean(np.abs(predictions[:, i] - targets[:, i]))
        
        per_temp_metrics[f'temp_{i+1}'] = {
            'mse': mse_i,
            'rmse': rmse_i,
            'mae': mae_i
        }
    
    results = {
        'mse': mse,
        'rmse': rmse,
        'mae': mae,
        'per_temperature': per_temp_metrics,
        'predictions': predictions,
        'targets': targets
    }
    
    if verbose:
        print("\n" + "=" * 70)
        print("TEST SET EVALUATION")
        print("=" * 70)
        print(f"\nOverall Metrics:")
        print(f"  MSE: {mse:.6f}")
        print(f"  RMSE: {rmse:.6f}°C")
        print(f"  MAE: {mae:.6f}°C")
        
        print(f"\nPer-Temperature Metrics:")
        for i in range(predictions.shape[1]):
            metrics = per_temp_metrics[f'temp_{i+1}']
            print(f"  Temperature {i+1}:")
            print(f"    RMSE: {metrics['rmse']:.6f}°C")
            print(f"    MAE: {metrics['mae']:.6f}°C")
    
    return results


def plot_training_history(history: dict, save_path: str = None):
    """Plot training and validation losses"""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    axes[0].plot(history['epoch'], history['train_loss'], label='Training Loss', linewidth=2)
    axes[0].plot(history['epoch'], history['val_loss'], label='Validation Loss', linewidth=2)
    axes[0].set_xlabel('Epoch', fontsize=12)
    axes[0].set_ylabel('Loss (MSE)', fontsize=12)
    axes[0].set_title('Model Loss During Training', fontsize=14, fontweight='bold')
    axes[0].legend(fontsize=11)
    axes[0].grid(True, alpha=0.3)
    
    axes[1].plot(history['epoch'], history['train_mae'], label='Training MAE', linewidth=2)
    axes[1].plot(history['epoch'], history['val_mae'], label='Validation MAE', linewidth=2)
    axes[1].set_xlabel('Epoch', fontsize=12)
    axes[1].set_ylabel('MAE (°C)', fontsize=12)
    axes[1].set_title('Model MAE During Training', fontsize=14, fontweight='bold')
    axes[1].legend(fontsize=11)
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Training curves saved: {save_path}")
    
    plt.show()


def save_predictions(predictions: np.ndarray, targets: np.ndarray, save_path: str = None):
    """Save predictions and targets to CSV"""
    errors = np.abs(predictions - targets)
    mae_per_sample = np.mean(errors, axis=1)
    
    data_dict = {}
    for i in range(targets.shape[1]):
        data_dict[f'actual_temp_{i+1}'] = targets[:, i]
        data_dict[f'pred_temp_{i+1}'] = predictions[:, i]
    
    data_dict['mae'] = mae_per_sample
    
    df = pd.DataFrame(data_dict)
    
    if save_path:
        df.to_csv(save_path, index=False)
        print(f"✓ Predictions saved: {save_path}")
    
    return df


def create_data_loaders(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    batch_size: int,
    validation_split: float = 0.1,
    verbose: bool = True
) -> tuple:
    """Create PyTorch data loaders"""
    if verbose:
        print("\n" + "=" * 70)
        print("CREATING DATA LOADERS")
        print("=" * 70)
    
    X_train_tensor = torch.from_numpy(X_train).float()
    y_train_tensor = torch.from_numpy(y_train).float()
    X_test_tensor = torch.from_numpy(X_test).float()
    y_test_tensor = torch.from_numpy(y_test).float()
    
    n_train = len(X_train_tensor)
    val_size = int(n_train * validation_split)
    train_size = n_train - val_size
    
    train_dataset, val_dataset = data.random_split(
        data.TensorDataset(X_train_tensor, y_train_tensor),
        [train_size, val_size]
    )
    
    test_dataset = data.TensorDataset(X_test_tensor, y_test_tensor)
    
    train_loader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    if verbose:
        print(f"\nTraining set: {train_size} samples")
        print(f"Validation set: {val_size} samples")
        print(f"Test set: {len(test_dataset)} samples")
        print(f"Batch size: {batch_size}")
    
    return train_loader, val_loader, test_loader


def set_seed(seed: int = 42):
    """Set random seed for reproducibility"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


# ============================================================================
# ============================================================================
#                          MAIN PIPELINE
# ============================================================================
# ============================================================================

def main_train(config: Config = None):
    """Main training pipeline"""
    
    if config is None:
        config = Config()
    
    print("\n" + "=" * 70)
    print("AIRCRAFT TEMPERATURE PREDICTION - LSTM MODEL")
    print("=" * 70)
    
    # Set seed
    set_seed(config.RANDOM_SEED)
    
    # Create output directory
    Path(config.OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
    
    # ====================================================================
    # STEP 1: LOAD AND PREPARE DATA
    # ====================================================================
    
    print("\n[Step 1] Loading and preparing data...")
    
    data_dict = DataPreparation.prepare_data(config)
    
    X_train = data_dict['X_train']
    y_train = data_dict['y_train']
    X_test = data_dict['X_test']
    y_test = data_dict['y_test']
    scaler_X = data_dict['scaler_X']
    scaler_y = data_dict['scaler_y']
    n_features = data_dict['n_features']
    
    # ====================================================================
    # STEP 2: CREATE DATA LOADERS
    # ====================================================================
    
    print("\n[Step 2] Creating data loaders...")
    
    train_loader, val_loader, test_loader = create_data_loaders(
        X_train, y_train, X_test, y_test,
        batch_size=config.BATCH_SIZE,
        validation_split=config.VALIDATION_SPLIT,
        verbose=config.VERBOSE
    )
    
    # ====================================================================
    # STEP 3: BUILD MODEL
    # ====================================================================
    
    print("\n[Step 3] Building LSTM model...")
    
    model = TemperatureLSTM(
        input_size=n_features,
        hidden_dim_1=config.HIDDEN_DIM_1,
        hidden_dim_2=config.HIDDEN_DIM_2,
        dense_dim_1=config.DENSE_DIM_1,
        dense_dim_2=config.DENSE_DIM_2,
        output_size=5,
        dropout_rate_1=config.DROPOUT_RATE_1,
        dropout_rate_2=config.DROPOUT_RATE_2,
        l2_lambda=config.L2_REGULARIZATION,
        device=config.DEVICE
    )
    
    param_count = model.count_parameters()
    
    if config.VERBOSE:
        print(f"\nModel Statistics:")
        print(f"  Total Parameters: {param_count['total']:,}")
        print(f"  Trainable Parameters: {param_count['trainable']:,}")
        print(f"  Device: {config.DEVICE}")
    
    # ====================================================================
    # STEP 4: SETUP TRAINING
    # ====================================================================
    
    print("\n[Step 4] Setting up training...")
    
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=config.LEARNING_RATE,
        weight_decay=config.L2_REGULARIZATION
    )
    
    criterion = nn.MSELoss()
    
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        criterion=criterion,
        device=config.DEVICE,
        patience=config.PATIENCE,
        lr_factor=config.LR_FACTOR,
        min_lr=config.MIN_LR,
        verbose=config.VERBOSE
    )
    
    if config.VERBOSE:
        print(f"  Optimizer: Adam (lr={config.LEARNING_RATE})")
        print(f"  Loss Function: MSE")
        print(f"  Early Stopping Patience: {config.PATIENCE} epochs")
    
    # ====================================================================
    # STEP 5: TRAIN MODEL
    # ====================================================================
    
    print("\n[Step 5] Training model...")
    
    history = trainer.fit(
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=config.NUM_EPOCHS,
        print_every=config.PRINT_EVERY
    )
    
    # ====================================================================
    # STEP 6: EVALUATE ON TEST SET
    # ====================================================================
    
    print("\n[Step 6] Evaluating on test set...")
    
    eval_results = evaluate_model(
        model=model,
        test_loader=test_loader,
        device=config.DEVICE,
        scaler_y=scaler_y,
        verbose=config.VERBOSE
    )
    
    # ====================================================================
    # STEP 7: SAVE MODEL AND RESULTS
    # ====================================================================
    
    print("\n[Step 7] Saving model and results...")
    
    # Save model (.pth format)
    torch.save(model.state_dict(), config.MODEL_PATH)
    print(f"✓ Model saved: {config.MODEL_PATH}")
    
    # Save scalers
    with open(config.SCALER_X_PATH, 'wb') as f:
        pickle.dump(scaler_X, f)
    print(f"✓ Input scaler saved: {config.SCALER_X_PATH}")
    
    with open(config.SCALER_Y_PATH, 'wb') as f:
        pickle.dump(scaler_y, f)
    print(f"✓ Output scaler saved: {config.SCALER_Y_PATH}")
    
    # Save training history
    trainer.save_history(config.HISTORY_PATH)
    
    # Save predictions
    save_predictions(eval_results['predictions'], eval_results['targets'], 
                     save_path=config.PREDICTIONS_PATH)
    
    # ====================================================================
    # STEP 8: VISUALIZATION
    # ====================================================================
    
    if config.SAVE_PLOTS:
        print("\n[Step 8] Generating visualizations...")
        plot_training_history(history, save_path=config.PLOT_PATH)
    
    # ====================================================================
    # SUMMARY
    # ====================================================================
    
    print("\n" + "=" * 70)
    print("TRAINING SUMMARY")
    print("=" * 70)
    
    print(f"\nModel Information:")
    print(f"  Architecture: Bidirectional LSTM")
    print(f"  Total Parameters: {param_count['total']:,}")
    
    print(f"\nTraining Information:")
    print(f"  Training Epochs: {len(history['epoch'])}")
    print(f"  Best Epoch: {trainer.best_epoch}")
    print(f"  Best Validation Loss: {trainer.best_val_loss:.6f}")
    
    print(f"\nTest Set Performance:")
    print(f"  MSE: {eval_results['mse']:.6f}")
    print(f"  RMSE: {eval_results['rmse']:.6f}°C")
    print(f"  MAE: {eval_results['mae']:.6f}°C")
    
    print(f"\nOutput Files:")
    print(f"  Model: {config.MODEL_PATH}")
    print(f"  Input Scaler: {config.SCALER_X_PATH}")
    print(f"  Output Scaler: {config.SCALER_Y_PATH}")
    print(f"  Training History: {config.HISTORY_PATH}")
    if config.SAVE_PLOTS:
        print(f"  Training Plot: {config.PLOT_PATH}")
    print(f"  Predictions: {config.PREDICTIONS_PATH}")
    
    print("\n" + "=" * 70)
    print("✓ TRAINING COMPLETE!")
    print("=" * 70)
    
    return model, trainer, eval_results


def main_predict(model: nn.Module, config: Config = None, input_csv: str = None):
    """Make predictions on new data"""
    
    if config is None:
        config = Config()
    
    if input_csv is None:
        raise ValueError("input_csv path is required")
    
    if not os.path.exists(input_csv):
        raise FileNotFoundError(f"Input file not found: {input_csv}")
    
    print("\n" + "=" * 70)
    print("MAKING PREDICTIONS")
    print("=" * 70)
    
    # Load data
    df = pd.read_csv(input_csv)
    print(f"\n✓ Loaded data: {df.shape[0]} samples, {df.shape[1]} columns")
    
    # Extract features
    temp_columns = config.TEMPERATURE_COLUMNS
    fdr_columns = [col for col in df.columns 
                   if col not in temp_columns + ['timestamp']]
    
    X = df[fdr_columns].values
    print(f"✓ Extracted {len(fdr_columns)} FDR sensor features")
    
    # Load scalers
    with open(config.SCALER_X_PATH, 'rb') as f:
        scaler_X = pickle.load(f)
    with open(config.SCALER_Y_PATH, 'rb') as f:
        scaler_y = pickle.load(f)
    
    print(f"✓ Loaded scalers")
    
    # Scale and create sequences
    X_scaled = scaler_X.transform(X)
    X_seq = []
    for i in range(len(X_scaled) - config.LOOKBACK + 1):
        X_seq.append(X_scaled[i:i+config.LOOKBACK])
    X_seq = np.array(X_seq)
    
    X_tensor = torch.from_numpy(X_seq).float().to(config.DEVICE)
    
    # Make predictions
    model.eval()
    all_predictions = []
    
    with torch.no_grad():
        for i in range(0, len(X_tensor), 128):
            batch = X_tensor[i:i+128]
            pred_batch = model(batch)
            all_predictions.append(pred_batch.cpu().numpy())
    
    predictions_scaled = np.concatenate(all_predictions, axis=0)
    predictions = scaler_y.inverse_transform(predictions_scaled)
    
    print(f"✓ Generated {len(predictions)} predictions")
    
    return predictions


# ============================================================================
# ============================================================================
#                          SCRIPT EXECUTION
# ============================================================================
# ============================================================================

if __name__ == '__main__':
    
    # Create config instance
    config = Config()
    
    print(f"\n{'='*70}")
    print(f"Configuration Summary:")
    print(f"{'='*70}")
    print(f"\nData:")
    print(f"  Lookback: {config.LOOKBACK}")
    print(f"  Batch Size: {config.BATCH_SIZE}")
    print(f"  Learning Rate: {config.LEARNING_RATE}")
    
    print(f"\nModel:")
    print(f"  LSTM 1: {config.HIDDEN_DIM_1} (forward) + {config.HIDDEN_DIM_1} (backward)")
    print(f"  LSTM 2: {config.HIDDEN_DIM_2} (forward) + {config.HIDDEN_DIM_2} (backward)")
    print(f"  Dense: {config.DENSE_DIM_1} → {config.DENSE_DIM_2}")
    
    print(f"\nTraining:")
    print(f"  Epochs: {config.NUM_EPOCHS}")
    print(f"  Early Stopping Patience: {config.PATIENCE}")
    print(f"  Device: {config.DEVICE}")
    print(f"{'='*70}\n")
    
    # Train model
    model, trainer, results = main_train(config)
    
    # Optionally make predictions on new data
    # predictions = main_predict(model, config, 'data/new_sortie.csv')
